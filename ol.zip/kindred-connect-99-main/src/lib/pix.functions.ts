import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { checkoutTotals, validCpf } from "@/lib/checkout";
import { selectTrackingData, type TrackingData } from "@/lib/tracking";
import { kit } from "@/data/campaign";

const API = "https://app.pingupag.com/gateway/v1";

function apiKey(): string {
  const key = process.env["PINGUPAG_API_KEY"];
  if (!key) throw new Error("Pagamento Pix ainda não configurado.");
  return key;
}

const createSchema = z.object({
  tracking: z
    .record(z.string().max(68), z.string().max(1000).nullable())
    .transform(selectTrackingData)
    .optional(),
  offers: z.record(z.string().max(20), z.string().max(20)),
  shipping: z.enum(["free", "express"]),
  customer: z.object({
    name: z.string().trim().min(5).max(120),
    email: z.string().trim().email().max(160),
    phone: z.string().regex(/^\d{10,11}$/),
    document: z
      .string()
      .regex(/^\d{11}$/)
      .refine(validCpf),
  }),
  address: z.object({
    street: z.string().max(160),
    number: z.string().max(20),
    complement: z.string().max(80),
    neighborhood: z.string().max(80),
    city: z.string().max(80),
    state: z.string().length(2),
    zipcode: z.string().regex(/^\d{8}$/),
  }),
});

export type PixCharge = {
  id: string;
  qrCode: string;
  qrImage: string;
  amount: number;
  expiresAt: string;
  trackingAccess?: string;
  tracking?: TrackingData;
};

export const createPixCharge = createServerFn({ method: "POST" })
  .inputValidator((data) => createSchema.parse(data))
  .handler(async ({ data }): Promise<PixCharge> => {
    // Total is recalculated on the server so the price cannot be tampered with.
    const { total } = checkoutTotals(data.offers, data.shipping);
    const amount = Math.round(total * 100);
    const reference = "CORRE-ROSA-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
    const res = await fetch(API + "/transaction", {
      method: "POST",
      headers: { "X-API-Key": apiKey(), "Content-Type": "application/json" },
      body: JSON.stringify({
        amount,
        description: kit.title,
        reference,
        source: "api_externa",
        customer: data.customer,
        address: data.address,
      }),
    });
    const body = (await res.json().catch(() => null)) as Record<string, unknown> | null;
    if (!res.ok || !body || typeof body["qr_code"] !== "string") {
      console.error("Pingupag create error", res.status);
      throw new Error("Não foi possível gerar o Pix. Tente novamente.");
    }
    const id = String(body["transaction_id"] ?? reference);
    if (process.env["UTMIFY_DIRECT_ENABLED"] === "true") {
      try {
        const { buildUtmifyOrder } = await import("./utmify-order");
        const { enqueueUtmifyOrder } = await import("./utmify-queue.server");
        await enqueueUtmifyOrder(
          buildUtmifyOrder({
            id,
            amount,
            customer: { ...data.customer, country: "BR" },
            offers: data.offers,
            tracking: data.tracking ?? {},
            created: new Date(),
          }),
        );
      } catch {
        // Never invalidate a real Pix or log customer details when analytics fails.
        console.error("UTMify queue registration failed", { orderId: id });
      }
    }
    let trackingAccess: string | undefined;
    try {
      const { sealTrackingAccess } = await import("./tracking-access.server");
      trackingAccess = await sealTrackingAccess({
        chargeId: id,
        customer: data.customer,
        address: data.address,
        tracking: data.tracking ?? {},
      });
    } catch {
      // An unavailable optional offer must never invalidate an already-created Pix.
      console.error("Tracking handoff unavailable");
    }
    return {
      id,
      qrCode: body["qr_code"],
      qrImage: typeof body["qr_code_base64"] === "string" ? body["qr_code_base64"] : "",
      amount,
      expiresAt: String(body["expires_at"] ?? ""),
      tracking: data.tracking ?? {},
      ...(trackingAccess ? { trackingAccess } : {}),
    };
  });

export const getPixStatus = createServerFn({ method: "GET" })
  .inputValidator((data) => z.object({ id: z.string().regex(/^[\w-]{1,64}$/) }).parse(data))
  .handler(async ({ data }): Promise<{ status: string }> => {
    const res = await fetch(
      API + "/query?action=get_transaction&id=" + encodeURIComponent(data.id),
      { headers: { "X-API-Key": apiKey() } },
    );
    const body = (await res.json().catch(() => null)) as {
      status?: string;
    } | null;
    return { status: res.ok && body?.status ? body.status : "pending" };
  });
