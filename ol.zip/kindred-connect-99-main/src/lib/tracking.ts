// Attribution values are opaque identifiers, never JSON or numbers.
export const trackingKeys = [
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_content",
  "utm_term",
  "utm_id",
  "fbclid",
  "gclid",
  "ttclid",
  "src",
  "sck",
  "xcod",
] as const;
export type TrackingKey = (typeof trackingKeys)[number] | `utm_${string}`;
export type TrackingParameters = Partial<Record<TrackingKey, string | undefined>>;
export type TrackingData = TrackingParameters;
export const trackingStorageKey = "corre-rosa-tracking-v2";
export const trackingCookieKey = "corre_rosa_tracking_v2";
export const trackingLifetime = 30 * 24 * 60 * 60 * 1000;
const legacySessionKey = "corre-rosa-attribution-session-v1";

export function isTrackingKey(key: string): key is TrackingKey {
  return trackingKeys.some((known) => known === key) || /^utm_[a-zA-Z0-9_]{1,64}$/.test(key);
}

export function selectTrackingData(input: Record<string, unknown>): TrackingData {
  const result: TrackingData = {};
  for (const [key, value] of Object.entries(input))
    if (
      isTrackingKey(key) &&
      typeof value === "string" &&
      value.length > 0 &&
      value.length <= 1000
    )
      result[key] = value;
  return result;
}

export function selectTrackingParameters(input: Record<string, unknown>): TrackingParameters {
  return Object.fromEntries(
    Object.entries(selectTrackingData(input)).filter(([key]) => isTrackingKey(key)),
  );
}

export function trackingFromSearch(search: string): TrackingParameters {
  const query = new URLSearchParams(search);
  return selectTrackingParameters(
    Object.fromEntries([...query].filter(([key]) => query.getAll(key).length === 1)),
  );
}

type Snapshot = { values: TrackingData; expiresAt: number; updatedAt: number };

// Self-contained so attribution can be restored before client-side hydration.
function browserTracking(
  keys: readonly string[],
  storageKey: string,
  cookieKey: string,
  legacyKey: string,
  lifetime: number,
  search: string | null,
  restoreUrl: boolean,
): { received: TrackingData; saved: TrackingData } {
  if (typeof window === "undefined") return { received: {}, saved: {} };
  const now = Date.now();
  const validKey = (key: string) => keys.includes(key) || /^utm_[a-zA-Z0-9_]{1,64}$/.test(key);
  const clean = (input: unknown): TrackingData => {
    if (!input || typeof input !== "object" || Array.isArray(input)) return {};
    return Object.fromEntries(
      Object.entries(input).filter(
        ([key, value]) =>
          validKey(key) &&
          typeof value === "string" &&
          value.length > 0 &&
          value.length <= 1000,
      ),
    );
  };
  const parse = (raw: string | null): Snapshot | null => {
    try {
      const data = JSON.parse(raw ?? "null");
      if (!data || typeof data.expiresAt !== "number" || data.expiresAt <= now) return null;
      const values = clean(data.values);
      return Object.keys(values).length
        ? {
            values,
            expiresAt: data.expiresAt,
            updatedAt:
              typeof data.updatedAt === "number" ? data.updatedAt : data.expiresAt - lifetime,
          }
        : null;
    } catch {
      return null;
    }
  };
  let cookies: Record<string, string> = {};
  try {
    cookies = Object.fromEntries(
      document.cookie.split(";").map((part) => {
        const index = part.indexOf("=");
        return [part.slice(0, index).trim(), part.slice(index + 1)];
      }),
    );
  } catch {
    /* A denied cookie API must not interrupt the funnel. */
  }
  let snapshot: Snapshot | null = null;
  try {
    snapshot = parse(window.localStorage.getItem(storageKey));
  } catch {
    /* Use the cookie backup. */
  }
  {
    const count = Number(cookies[cookieKey]);
    if (Number.isInteger(count) && count > 0 && count <= 64) {
      try {
        const parts = Array.from({ length: count }, (_, index) => cookies[cookieKey + "_" + index]);
        if (parts.every((part) => typeof part === "string")) {
          const backup = parse(decodeURIComponent(parts.join("")));
          if (backup && (!snapshot || backup.updatedAt > snapshot.updatedAt)) snapshot = backup;
        }
      } catch {
        /* Ignore a corrupted or incomplete backup. */
      }
    }
  }
  if (!snapshot && search !== null) {
    try {
      const values = clean(JSON.parse(window.sessionStorage.getItem(legacyKey) ?? "null"));
      if (Object.keys(values).length)
        snapshot = { values, expiresAt: now + lifetime, updatedAt: now };
    } catch {
      /* Migration is optional. */
    }
  }
  if (search === null) return { received: {}, saved: snapshot?.values ?? {} };

  const query = new URLSearchParams(search);
  const received: TrackingData = {};
  for (const [key, value] of query) {
    if (validKey(key) && value && value.length <= 1000 && query.getAll(key).length === 1)
      received[key as TrackingKey] = value;
  }
  const saved = snapshot?.values ?? {};
  // A new campaign replaces the campaign as a whole, preventing an old creative
  // or click ID from being attributed to a different ad. Empty URLs retain it.
  const changed = Object.entries(received).some(
    ([key, value]) => saved[key as TrackingKey] !== value,
  );
  const values: TrackingData = changed ? received : { ...saved, ...received };
  if (Object.keys(values).length) {
    const next = {
      values,
      expiresAt: changed || !snapshot ? now + lifetime : snapshot.expiresAt,
      updatedAt:
        !snapshot || JSON.stringify(values) !== JSON.stringify(saved)
          ? Math.max(now, (snapshot?.updatedAt ?? 0) + 1)
          : snapshot.updatedAt,
    };
    const encoded = JSON.stringify(next);
    try {
      if (window.localStorage.getItem(storageKey) !== encoded)
        window.localStorage.setItem(storageKey, encoded);
    } catch {
      /* The URL and cookies still preserve attribution. */
    }
    try {
      // Split the backup to respect the browser's per-cookie size limit.
      const backup = encodeURIComponent(encoded);
      const parts = backup.match(/.{1,3000}/g) ?? [];
      const previousCount = Number(cookies[cookieKey]) || 0;
      const attributes =
        "; Path=/; SameSite=Lax; Expires=" +
        new Date(next.expiresAt).toUTCString() +
        (window.location.protocol === "https:" ? "; Secure" : "");
      if (parts.length <= 64) {
        parts.forEach((part, index) => {
          const name = cookieKey + "_" + index;
          if (cookies[name] !== part || changed) document.cookie = name + "=" + part + attributes;
        });
        document.cookie = cookieKey + "=" + parts.length + attributes;
        for (let index = parts.length; index < Math.min(previousCount, 64); index++)
          document.cookie = cookieKey + "_" + index + "=; Path=/; Max-Age=0";
      }
    } catch {
      /* Restricted cookies do not affect payment. */
    }
    try {
      window.sessionStorage.removeItem(legacyKey);
    } catch {
      /* Best-effort migration. */
    }
  }
  if (restoreUrl) {
    try {
      const url = new URL(window.location.href);
      let restored = false;
      for (const [key, value] of Object.entries(values)) {
        if (validKey(key) && typeof value === "string" && !url.searchParams.has(key)) {
          url.searchParams.set(key, value);
          restored = true;
        }
      }
      if (restored) window.history.replaceState(window.history.state, "", url.href);
      Reflect.set(window, "__correRosaTrackingEntry", {
        pathname: url.pathname,
        received,
        saved: values,
      });
    } catch {
      /* Attribution recovery must never interrupt page loading. */
    }
  }
  return { received, saved: values };
}

export function captureTracking(search?: string): TrackingData {
  return browserTracking(
    trackingKeys,
    trackingStorageKey,
    trackingCookieKey,
    legacySessionKey,
    trackingLifetime,
    search ?? (typeof window === "undefined" ? "" : window.location.search),
    false,
  ).saved;
}

export function getStoredTrackingParameters(): TrackingParameters {
  const { saved } = browserTracking(
    trackingKeys,
    trackingStorageKey,
    trackingCookieKey,
    legacySessionKey,
    trackingLifetime,
    null,
    false,
  );
  return selectTrackingParameters(saved);
}

// A reducer for every TanStack Link/navigate, retaining only attribution fields.
export function trackingSearch(previous: Record<string, unknown>): TrackingParameters {
  return { ...getStoredTrackingParameters(), ...selectTrackingParameters(previous) };
}

// Supports relative paths and external HTTPS checkouts, preserving query and hash.
export function buildUrlWithTracking(path: string, tracking = captureTracking()): string {
  if (/^(?:#|mailto:|tel:|javascript:|data:)/i.test(path)) return path;
  try {
    const base = typeof window === "undefined" ? "https://tracking.invalid/" : window.location.href;
    const url = new URL(path, base);
    if (url.protocol !== "http:" && url.protocol !== "https:") return path;
    for (const [key, value] of Object.entries(selectTrackingParameters(tracking)))
      if (typeof value === "string" && !url.searchParams.has(key)) url.searchParams.set(key, value);
    return /^(?:https?:)?\/\//i.test(path) ? url.href : url.pathname + url.search + url.hash;
  } catch {
    return path;
  }
}

// Temporary diagnostics requested for this funnel. No payer data or credentials.
export function debugTracking(stage: string, search?: string, snapshot?: TrackingData) {
  if (typeof window === "undefined") return;
  const entry = Reflect.get(window, "__correRosaTrackingEntry") as
    { pathname: string; received: TrackingData } | undefined;
  const received =
    search === undefined && entry?.pathname === stage
      ? entry.received
      : trackingFromSearch(search ?? window.location.search);
  if (entry?.pathname === stage) Reflect.deleteProperty(window, "__correRosaTrackingEntry");
  console.log("[Corre Rosa tracking]", {
    stage,
    received,
    saved: snapshot ?? captureTracking(search),
  });
}

export const trackingBootstrap = `(${browserTracking.toString()})(${JSON.stringify(trackingKeys)},${JSON.stringify(trackingStorageKey)},${JSON.stringify(trackingCookieKey)},${JSON.stringify(legacySessionKey)},${trackingLifetime},window.location.search,true);`;
