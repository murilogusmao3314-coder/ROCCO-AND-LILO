import { selectTrackingData } from "@/lib/tracking";
import { z } from "zod";

const contextSchema = z.object({
  tracking: z
    .record(z.string().max(68), z.string().max(1000).nullable())
    .transform(selectTrackingData)
    .optional(),
  chargeId: z.string().regex(/^[\w-]{1,64}$/),
  expiresAt: z.number().int(),
  customer: z.object({
    name: z.string().min(5).max(120),
    email: z.string().email().max(160),
    phone: z.string().regex(/^\d{10,11}$/),
    document: z.string().regex(/^\d{11}$/),
  }),
  address: z.object({
    street: z.string().max(160),
    number: z.string().max(20),
    complement: z.string().max(80),
    neighborhood: z.string().max(80),
    city: z.string().max(80),
    state: z.string().length(2),
    zipcode: z.string().regex(/^\d{8}$/),
  }),
});
type TrackingContext = z.infer<typeof contextSchema>;

async function encryptionKey() {
  const secret = process.env["PINGUPAG_API_KEY"];
  if (!secret) throw new Error("Pagamento Pix ainda não configurado.");
  const hash = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode("corre-rosa:tracking:v1:" + secret),
  );
  return crypto.subtle.importKey("raw", hash, "AES-GCM", false, ["encrypt", "decrypt"]);
}

function encode(bytes: Uint8Array) {
  return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}
function decode(value: string) {
  return Uint8Array.from(atob(value.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));
}

export async function sealTrackingAccess(context: Omit<TrackingContext, "expiresAt">) {
  const data = contextSchema.parse({ ...context, expiresAt: Date.now() + 24 * 60 * 60 * 1000 });
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    await encryptionKey(),
    new TextEncoder().encode(JSON.stringify(data)),
  );
  return "v1." + encode(iv) + "." + encode(new Uint8Array(encrypted));
}

export async function openTrackingAccess(token: string): Promise<TrackingContext> {
  try {
    const [, iv, encrypted] = token.split(".");
    if (!token.startsWith("v1.") || !iv || !encrypted) throw new Error("Invalid token");
    const plain = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: decode(iv) },
      await encryptionKey(),
      decode(encrypted),
    );
    const data = contextSchema.parse(JSON.parse(new TextDecoder().decode(plain)));
    if (data.expiresAt <= Date.now()) throw new Error("Expired token");
    return data;
  } catch {
    throw new Error("Acesso ao rastreamento indisponível.");
  }
}
