import { z } from "zod";
import { kit, offers } from "../data/campaign";

export const utmifyTrackingKeys = [
  "src",
  "sck",
  "utm_source",
  "utm_campaign",
  "utm_medium",
  "utm_content",
  "utm_term",
] as const;
export const utmifyTrackingSchema = z.object(
  Object.fromEntries(utmifyTrackingKeys.map((key) => [key, z.string().min(1).max(1000).nullish()])),
);

export function checkoutTracking(search: string): Record<string, string | null> {
  const query = new URLSearchParams(search);
  return Object.fromEntries(
    utmifyTrackingKeys.map((key) => {
      const value = query.get(key);
      return [key, query.getAll(key).length === 1 && value && value.length <= 1000 ? value : null];
    }),
  );
}

export const orderSchema = z.object({
  orderId: z.string().regex(/^[\w-]{1,64}$/),
  platform: z.literal("CorreRosa"),
  paymentMethod: z.literal("pix"),
  status: z.enum(["waiting_payment", "paid"]),
  createdAt: z.string().regex(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/),
  approvedDate: z.string().nullable(),
  refundedAt: z.null(),
  customer: z.object({
    name: z.string(),
    email: z.string().email(),
    phone: z.string(),
    document: z.string(),
    country: z.literal("BR"),
  }),
  products: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      planId: z.null(),
      planName: z.null(),
      quantity: z.number().int().positive(),
      priceInCents: z.number().int().nonnegative(),
    }),
  ),
  trackingParameters: utmifyTrackingSchema,
  commission: z.object({
    totalPriceInCents: z.number().int().positive(),
    gatewayFeeInCents: z.number().int().nonnegative(),
    userCommissionInCents: z.number().int().nonnegative(),
    currency: z.literal("BRL"),
  }),
});
export type UtmifyOrder = z.infer<typeof orderSchema>;
export const utcDate = (date: Date) => date.toISOString().slice(0, 19).replace("T", " ");

export function buildUtmifyOrder(input: {
  id: string;
  amount: number;
  customer: UtmifyOrder["customer"];
  offers: Record<string, string>;
  products?: UtmifyOrder["products"];
  tracking: Record<string, unknown>;
  created: Date;
}): UtmifyOrder {
  const products = input.products ?? [
    {
      id: "corre-rosa-kit",
      name: kit.title,
      planId: null,
      planName: null,
      quantity: 1,
      priceInCents: Math.round(kit.price * 100),
    },
    ...offers
      .filter((offer) => Object.hasOwn(input.offers, offer.id))
      .map((offer) => ({
        id: offer.id,
        name: offer.title,
        planId: null,
        planName: null,
        quantity: 1,
        priceInCents: Math.round(offer.price * 100),
      })),
  ];
  const trackingParameters = Object.fromEntries(
    utmifyTrackingKeys.map((key) => [
      key,
      typeof input.tracking[key] === "string" &&
      (input.tracking[key] as string).length <= 1000 &&
      input.tracking[key]
        ? input.tracking[key]
        : null,
    ]),
  );
  return orderSchema.parse({
    orderId: input.id,
    platform: "CorreRosa",
    paymentMethod: "pix",
    status: "waiting_payment",
    createdAt: utcDate(input.created),
    approvedDate: null,
    refundedAt: null,
    customer: input.customer,
    products,
    trackingParameters,
    commission: {
      totalPriceInCents: input.amount,
      gatewayFeeInCents: 0,
      userCommissionInCents: input.amount,
      currency: "BRL",
    },
  });
}
