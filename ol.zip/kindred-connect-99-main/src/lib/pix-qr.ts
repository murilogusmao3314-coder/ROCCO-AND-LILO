/** Encode the exact Pix payload without sending it to an image service. */
export async function pixQrSource(code: string): Promise<string> {
  if (!code.trim()) throw new Error("Código Pix indisponível.");
  const { default: createQr } = await import("qrcode-generator");
  createQr.stringToBytes = (text) => Array.from(new TextEncoder().encode(text));
  const qr = createQr(0, "M");
  qr.addData(code, "Byte");
  qr.make();
  const svg = qr.createSvgTag({ cellSize: 4, margin: 16, scalable: true });
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}
