import type { TrackingData } from "@/lib/tracking";
import { z } from "zod";
import type { PixCharge } from "./pix.functions";

type ChargeInput = {
  tracking?: TrackingData;
  customer: { name: string; email: string; phone: string; document: string };
  address?: {
    street: string;
    number: string;
    complement: string;
    neighborhood: string;
    city: string;
    state: string;
    zipcode: string;
  };
  description: string;
  referencePrefix: "RASTREIO" | "TESTE-RASTREIO";
};

export type TrackingPixResult = { ok: true; charge: PixCharge } | { ok: false; error: string };

export async function createTrackingCharge(input: ChargeInput): Promise<TrackingPixResult> {
  const key = process.env["PINGUPAG_API_KEY"];
  if (!key)
    return {
      ok: false,
      error: "Pagamento Pix ainda não configurado. Entre em contato com o atendimento.",
    };
  const amount = 2930;
  const reference =
    input.referencePrefix + "-" + Date.now() + "-" + crypto.randomUUID().slice(0, 8);
  let response: Response;
  try {
    response = await fetch("https://app.pingupag.com/gateway/v1/transaction", {
      method: "POST",
      headers: { "X-API-Key": key, "Content-Type": "application/json" },
      body: JSON.stringify({
        amount,
        description: input.description,
        reference,
        source: "api_externa",
        customer: input.customer,
        ...(input.address ? { address: input.address } : {}),
      }),
    });
  } catch {
    console.error("Tracking Pix gateway network error");
    return { ok: false, error: "O gateway Pix está indisponível no momento. Tente novamente." };
  }
  const body: unknown = await response.json().catch(() => null);
  const parsed = z
    .object({
      transaction_id: z.union([z.string().min(1), z.number()]),
      qr_code: z.string().min(1),
      qr_code_base64: z.string().nullish(),
      expires_at: z.string().nullish(),
    })
    .safeParse(body);
  if (!response.ok || !parsed.success) {
    // Do not log the gateway body: it can contain customer data or credentials.
    console.error("Tracking Pix gateway response error", {
      status: response.status,
      invalidResponse: !parsed.success,
    });
    const error =
      response.status === 401 || response.status === 403
        ? "O gateway recusou a configuração do Pix. Entre em contato com o atendimento."
        : response.status === 400 || response.status === 422
          ? "O gateway não aceitou os dados da cobrança. Confira seus dados e tente novamente."
          : response.status === 429
            ? "Aguarde alguns instantes antes de gerar outro Pix."
            : !response.ok
              ? "O gateway Pix está indisponível no momento. Tente novamente."
              : "O gateway não retornou um código Pix válido. Tente novamente.";
    return { ok: false, error };
  }
  const id = String(parsed.data.transaction_id);
  if (
    input.referencePrefix !== "TESTE-RASTREIO" &&
    process.env["UTMIFY_DIRECT_ENABLED"] === "true"
  ) {
    try {
      const { buildUtmifyOrder } = await import("./utmify-order");
      const { enqueueUtmifyOrder } = await import("./utmify-queue.server");
      await enqueueUtmifyOrder(
        buildUtmifyOrder({
          id,
          amount,
          customer: { ...input.customer, country: "BR" },
          offers: {},
          tracking: input.tracking ?? {},
          created: new Date(),
          products: [
            {
              id: "rastreamento-opcional",
              name: "Serviço opcional de rastreamento",
              planId: null,
              planName: null,
              quantity: 1,
              priceInCents: amount,
            },
          ],
        }),
      );
    } catch {
      console.error("UTMify queue registration failed", { orderId: id });
    }
  }
  return {
    ok: true,
    charge: {
      id,
      qrCode: parsed.data.qr_code,
      qrImage: parsed.data.qr_code_base64 ?? "",
      amount,
      expiresAt: parsed.data.expires_at ?? "",
      tracking: input.tracking ?? {},
    },
  };
}
