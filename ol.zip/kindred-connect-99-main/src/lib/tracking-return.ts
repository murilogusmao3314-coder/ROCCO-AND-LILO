import { selectTrackingData, type TrackingData } from "@/lib/tracking";
import { offers } from "@/data/campaign";
import type { OfferSelection } from "@/lib/checkout";

// Attribution and totals contain no payer details. Storage is never proof of payment.
export const trackingReturnKey = "corre-rosa-tracking-return-v1";
export type PurchaseSnapshot = {
  amount: number;
  tracking: TrackingData;
  offers?: OfferSelection;
  shipping?: string;
};
export type TrackingReturnRecord = {
  orderId: string;
  serviceId?: string;
  orderPurchase?: PurchaseSnapshot;
  servicePurchase?: PurchaseSnapshot;
};
export type TrackingReturnDecision = "tracking" | "completed" | "failed" | "none";
const validId = (value: unknown): value is string =>
  typeof value === "string" && /^[\w-]{1,64}$/.test(value);

function purchaseSnapshot(input: unknown): PurchaseSnapshot | null {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const value = input as Record<string, unknown>;
  const amount = value["amount"];
  if (typeof amount !== "number" || !Number.isSafeInteger(amount) || amount <= 0) return null;
  const attribution = value["tracking"];
  const tracking =
    attribution && typeof attribution === "object" && !Array.isArray(attribution)
      ? selectTrackingData(attribution as Record<string, unknown>)
      : {};
  const selection = value["offers"];
  const selected: OfferSelection = {};
  if (selection && typeof selection === "object") {
    for (const offer of offers) {
      const size = (selection as Record<string, unknown>)[offer.id];
      if (typeof size === "string" && size.length <= 20) selected[offer.id] = size;
    }
  }
  return {
    amount,
    tracking,
    ...(selection ? { offers: selected } : {}),
    ...(value["shipping"] === "free" || value["shipping"] === "express"
      ? { shipping: value["shipping"] }
      : {}),
  };
}

export function readTrackingReturn(): TrackingReturnRecord | null {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(trackingReturnKey) ?? "null");
    if (!value || typeof value !== "object") return null;
    const record = value as Record<string, unknown>;
    if (!validId(record["orderId"])) return null;
    if (record["serviceId"] !== undefined && !validId(record["serviceId"])) return null;
    const orderPurchase = purchaseSnapshot(record["orderPurchase"]);
    const servicePurchase = purchaseSnapshot(record["servicePurchase"]);
    return {
      orderId: record["orderId"],
      ...(record["serviceId"] ? { serviceId: record["serviceId"] } : {}),
      ...(orderPurchase ? { orderPurchase } : {}),
      ...(servicePurchase ? { servicePurchase } : {}),
    };
  } catch {
    return null;
  }
}

function save(record: TrackingReturnRecord) {
  try {
    localStorage.setItem(trackingReturnKey, JSON.stringify(record));
  } catch {
    // Restricted storage must not interrupt checkout or the existing live redirect.
  }
}

export function rememberTrackingOrder(orderId: string, purchase?: PurchaseSnapshot) {
  if (!validId(orderId)) return;
  const current = readTrackingReturn();
  save({
    ...(current?.orderId === orderId ? current : { orderId }),
    ...(purchase ? { orderPurchase: purchaseSnapshot(purchase)! } : {}),
  });
}

export function rememberTrackingService(serviceId: string, purchase?: PurchaseSnapshot) {
  if (!validId(serviceId)) return;
  const current = readTrackingReturn();
  if (current)
    save({
      ...current,
      serviceId,
      ...(purchase ? { servicePurchase: purchaseSnapshot(purchase)! } : {}),
    });
}

export function clearTrackingReturn(expected: TrackingReturnRecord) {
  const current = readTrackingReturn();
  if (current?.orderId !== expected.orderId || current.serviceId !== expected.serviceId) return;
  try {
    localStorage.removeItem(trackingReturnKey);
  } catch {
    // The next visit can verify the completed service again if storage cannot be cleared.
  }
}

export function completeTrackingService(serviceId: string) {
  const current = readTrackingReturn();
  if (current?.serviceId === serviceId) clearTrackingReturn(current);
}

export async function checkTrackingReturn(
  record: TrackingReturnRecord,
  status: (id: string) => Promise<{ status: string }>,
): Promise<TrackingReturnDecision> {
  try {
    if (record.serviceId && (await status(record.serviceId)).status === "approved")
      return "completed";
    const order = await status(record.orderId);
    return order.status === "approved" ? "tracking" : order.status === "failed" ? "failed" : "none";
  } catch {
    // A network failure is not confirmation. Leave the visit and saved entry intact.
    return "none";
  }
}
