import { createServerFn } from "@tanstack/react-start";
import { selectTrackingData } from "@/lib/tracking";
import { z } from "zod";
import { getPixStatus } from "@/lib/pix.functions";
import type { TrackingPixResult } from "./tracking-pix.server";
import { validCpf } from "@/lib/checkout";

const customerSchema = z.object({
  name: z
    .string()
    .trim()
    .min(5)
    .max(120)
    .refine((value) => value.split(/\s+/).length >= 2),
  email: z.string().trim().email().max(160),
  phone: z.string().regex(/^\d{10,11}$/),
  document: z
    .string()
    .regex(/^\d{11}$/)
    .refine(validCpf),
});
type TrackingCustomer = z.infer<typeof customerSchema>;

const trackingSchema = z
  .record(z.string().max(68), z.string().max(1000).nullable())
  .transform(selectTrackingData)
  .optional();

const accessSchema = z.object({
  token: z
    .string()
    .max(64000)
    .regex(/^v1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/),
});

async function approvedOrder(token: string) {
  const { openTrackingAccess } = await import("./tracking-access.server");
  const order = await openTrackingAccess(token);
  const result = await getPixStatus({ data: { id: order.chargeId } });
  if (result.status !== "approved")
    throw new Error("O pagamento do pedido ainda não foi confirmado.");
  return order;
}

export const getTrackingOffer = createServerFn({ method: "POST" })
  .inputValidator((data) => accessSchema.parse(data))
  .handler(async ({ data }): Promise<{ customer: TrackingCustomer }> => {
    const order = await approvedOrder(data.token);
    return { customer: order.customer };
  });

export const createTrackingPix = createServerFn({ method: "POST" })
  .inputValidator((data) =>
    accessSchema.extend({ customer: customerSchema, tracking: trackingSchema }).parse(data),
  )
  .handler(async ({ data }): Promise<TrackingPixResult> => {
    const order = await approvedOrder(data.token);
    const { createTrackingCharge } = await import("./tracking-pix.server");
    return createTrackingCharge({
      description: "Rastreamento opcional — pedido " + order.chargeId,
      referencePrefix: "RASTREIO",
      customer: data.customer,
      address: order.address,
      tracking: order.tracking ?? data.tracking ?? {},
    });
  });

const publicChargeSchema = z.object({
  tracking: trackingSchema,
  confirmRealCharge: z.literal(true),
  mode: z.enum(["service", "test"]),
  customer: customerSchema,
});

export const createTrackingPublicPix = createServerFn({ method: "POST" })
  .inputValidator((data) => publicChargeSchema.parse(data))
  .handler(async ({ data }): Promise<TrackingPixResult> => {
    const { createTrackingCharge } = await import("./tracking-pix.server");
    return createTrackingCharge({
      description:
        data.mode === "test"
          ? "TESTE de geração Pix — rastreamento (sem pedido)"
          : "Rastreamento opcional — solicitação pelo site",
      referencePrefix: data.mode === "test" ? "TESTE-RASTREIO" : "RASTREIO",
      customer: data.customer,
      tracking: data.tracking ?? {},
    });
  });
