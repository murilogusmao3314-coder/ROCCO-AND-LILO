import { clothingSizes, offers, shippingOptions, shoeSizes, kit } from "@/data/campaign";

export const selectionStorageKey = "corre-rosa-kit-selection-v1";
export type KitSelection = { shoe: string; shirt: string; shorts: string };
export type PersonalDetails = { name: string; phone: string; email: string; cpf: string };
export type Address = {
  cep: string;
  street: string;
  number: string;
  complement: string;
  district: string;
  city: string;
  state: string;
};
export type OfferSelection = Record<string, string>;
export const states = [
  "AC",
  "AL",
  "AP",
  "AM",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MT",
  "MS",
  "MG",
  "PA",
  "PB",
  "PR",
  "PE",
  "PI",
  "RJ",
  "RN",
  "RS",
  "RO",
  "RR",
  "SC",
  "SP",
  "SE",
  "TO",
];
export const digits = (value: string) => value.replace(/\D/g, "");
export const formatCpf = (value: string) =>
  digits(value)
    .slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
export const formatCep = (value: string) =>
  digits(value)
    .slice(0, 8)
    .replace(/(\d{5})(\d)/, "$1-$2");
export const formatPhone = (value: string) => {
  const number = digits(value).slice(0, 11);
  if (number.length <= 2) return number;
  const local = number.slice(2);
  const split = local.length > 8 ? 5 : 4;
  return (
    "(" +
    number.slice(0, 2) +
    ") " +
    local.slice(0, split) +
    (local.length > split ? "-" + local.slice(split) : "")
  );
};
export function validCpf(value: string) {
  const cpf = digits(value);
  if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
  for (const size of [9, 10]) {
    const sum = [...cpf.slice(0, size)].reduce(
      (total, char, index) => total + Number(char) * (size + 1 - index),
      0,
    );
    const digit = (sum * 10) % 11;
    if ((digit === 10 ? 0 : digit) !== Number(cpf[size])) return false;
  }
  return true;
}
export function validSelection(selection: unknown): selection is KitSelection {
  if (!selection || typeof selection !== "object") return false;
  const value = selection as KitSelection;
  return (
    shoeSizes.includes(value.shoe) &&
    clothingSizes.some((size) => size === value.shirt) &&
    clothingSizes.some((size) => size === value.shorts)
  );
}
export function readSelection(): KitSelection | null {
  try {
    const value: unknown = JSON.parse(sessionStorage.getItem(selectionStorageKey) || "null");
    return validSelection(value) ? value : null;
  } catch {
    return null;
  }
}
export function validateDetails(value: PersonalDetails): Record<string, string> {
  const errors: Record<string, string> = {};
  if (value.name.trim().split(/\s+/).length < 2 || value.name.trim().length < 5)
    errors["name"] = "Informe nome e sobrenome.";
  if (![10, 11].includes(digits(value.phone).length))
    errors["phone"] = "Confira o telefone com DDD.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.email.trim()))
    errors["email"] = "Informe um e-mail válido.";
  if (!validCpf(value.cpf)) errors["cpf"] = "Confira os dígitos do CPF.";
  return errors;
}
export function validateAddress(value: Address): Record<string, string> {
  const errors: Record<string, string> = {};
  if (digits(value.cep).length !== 8) errors["cep"] = "Informe um CEP com 8 dígitos.";
  for (const field of ["street", "number", "district", "city"] as const)
    if (!value[field].trim()) errors[field] = "Preencha este campo.";
  if (!states.includes(value.state)) errors["state"] = "Selecione o estado.";
  return errors;
}
export function checkoutTotals(selected: OfferSelection, shipping: string) {
  const extras = offers.filter((offer) => Object.hasOwn(selected, offer.id));
  const subtotal =
    Math.round((kit.price + extras.reduce((total, offer) => total + offer.price, 0)) * 100) / 100;
  const freight = shippingOptions.find((option) => option.id === shipping)?.price ?? 0;
  return { extras, subtotal, freight, total: Math.round((subtotal + freight) * 100) / 100 };
}
