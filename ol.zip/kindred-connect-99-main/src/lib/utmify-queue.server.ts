import type { UtmifyOrder } from "./utmify-order";

export async function enqueueUtmifyOrder(order: UtmifyOrder): Promise<void> {
  if (process.env["UTMIFY_DIRECT_ENABLED"] !== "true") return;
  const { createHmac } = await import("node:crypto");
  const key = process.env["PINGUPAG_API_KEY"];
  if (!key) throw new Error("Missing gateway configuration");
  // Only configured server-side origins are allowed; never trust a client Host header.
  // Netlify's read-only URL belongs to this deployed site. An old custom override
  // must not forward new orders into the previous account's queue.
  const origin = process.env["URL"] || process.env["UTMIFY_QUEUE_ORIGIN"];
  if (!origin) throw new Error("Missing UTMify queue origin");
  const url = new URL("/.netlify/functions/utmify-order", origin);
  if (url.protocol !== "https:" || url.username || url.password)
    throw new Error("Invalid queue origin");
  const body = JSON.stringify({ order, timestamp: Date.now() });
  const signature = createHmac("sha256", "corre-rosa:utmify-queue:v1:" + key)
    .update(body)
    .digest("hex");
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Order-Signature": signature,
    },
    body,
    signal: AbortSignal.timeout(10000),
  });
  // Only this function's 202 proves the authenticated order entered the queue.
  // A 200 SPA/HTML fallback on an incorrectly deployed Netlify site is not success.
  if (response.status !== 202) throw new Error("Utmify queue unavailable: " + response.status);
}
