// A short, one-time handoff from the live payment screen, never a site-wide redirect.
const storageKey = "corre-rosa-tracking-handoff-v1";
const handoffLifetime = 60_000;
let memoryHandoff: { token: string; expiresAt: number } | null = null;

export function handOffTrackingAccess(token: string) {
  const handoff = { token, expiresAt: Date.now() + handoffLifetime };
  memoryHandoff = handoff;
  try {
    sessionStorage.setItem(storageKey, JSON.stringify(handoff));
  } catch {
    // SPA navigation still works with restricted browser storage.
  }
}

export function takeTrackingAccess(): string | null {
  let handoff: unknown = memoryHandoff;
  memoryHandoff = null;
  try {
    const stored = sessionStorage.getItem(storageKey);
    sessionStorage.removeItem(storageKey);
    if (stored) handoff = JSON.parse(stored);
  } catch {
    // Fall back to the one-time in-memory handoff.
  }
  if (!handoff || typeof handoff !== "object") return null;
  const value = handoff as Record<string, unknown>;
  return typeof value["token"] === "string" &&
    typeof value["expiresAt"] === "number" &&
    value["expiresAt"] > Date.now()
    ? value["token"]
    : null;
}
