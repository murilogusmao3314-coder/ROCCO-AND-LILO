import { kit } from "@/data/campaign";
import { checkoutTotals, type OfferSelection } from "@/lib/checkout";
import { captureTracking, selectTrackingParameters, type TrackingData } from "@/lib/tracking";

export const metaPixelId = "1418898839713148";

// Init and initial PageView happen before hydration, in the common HTML shell.
export const metaPixelBootstrap = `(function(f,b,e,v,n,t,s){
  if(f.__correRosaMetaPixel === '1418898839713148')return;
  f.__correRosaMetaPixel='1418898839713148';
  if(!f.fbq){
    n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=true;n.version='2.0';n.queue=[];
    t=b.createElement(e);t.async=true;t.src=v;
    s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s);
  }
  f.fbq('init','1418898839713148');
  f.fbq('trackSingle','1418898839713148','PageView');
})(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');`;

type Fbq = (...args: unknown[]) => void;
declare global { interface Window { fbq?: Fbq; } }
type EventName = "PageView" | "ViewContent" | "AddToCart" | "AddToWishlist"
  | "InitiateCheckout" | "AddPaymentInfo" | "Purchase";
type Charge = { id: string; amount: number; tracking?: TrackingData };
const sent = new Set<string>();

function emit(name: EventName, details: Record<string, unknown> = {},
              chargeId?: string, source?: TrackingData): boolean {
  if (typeof window === "undefined" || typeof window.fbq !== "function") return false;
  const key = chargeId ? "corre-rosa-meta:" + metaPixelId + ":" + name + ":" + chargeId : null;
  if (key) {
    if (sent.has(key)) return false;
    try { if (localStorage.getItem(key) === "sent") return false; }
    catch { /* Storage denied; in-memory deduplication remains. */ }
  }
  try {
    const params = { ...selectTrackingParameters(source ?? captureTracking()), ...details };
    if (chargeId)
      window.fbq("trackSingle", metaPixelId, name, params,
        { eventID: "corre-rosa:" + name + ":" + chargeId });
    else window.fbq("trackSingle", metaPixelId, name, params);
  } catch {
    // A pixel failure must never block the checkout.
    return false;
  }
  if (key) {
    sent.add(key);
    try { localStorage.setItem(key, "sent"); }
    catch { /* In-memory deduplication remains. */ }
  }
  return true;
}

export function orderEventParameters(selected: OfferSelection = {}, shipping = "free") {
  const totals = checkoutTotals(selected, shipping);
  const contents = [
    { id: "kit-corre-rosa", quantity: 1, item_price: kit.price },
    ...totals.extras.map((offer) => ({ id: offer.id, quantity: 1, item_price: offer.price })),
  ];
  return {
    value: totals.total, currency: "BRL", content_type: "product", content_name: kit.title,
    content_ids: contents.map(item => item.id), contents, num_items: contents.length,
  };
}

export const trackMetaPageView = () => emit("PageView");
export const trackMetaViewContent = () => emit("ViewContent", orderEventParameters());
export const trackMetaCheckout = () => emit("InitiateCheckout", orderEventParameters());
export const trackMetaCart = () => emit("AddToCart", orderEventParameters());
export const trackMetaWishlist = () => emit("AddToWishlist", orderEventParameters());

export function trackMetaOrderPayment(name: "AddPaymentInfo" | "Purchase",
     charge: Charge, selected: OfferSelection, shipping: string) {
  return emit(name, {
    ...orderEventParameters(selected, shipping),
    value: charge.amount / 100, payment_method: "pix",
  }, charge.id, charge.tracking);
}

export function trackMetaServicePayment(name: "AddPaymentInfo" | "Purchase", charge: Charge) {
  const value = charge.amount / 100;
  return emit(name, {
    value, currency: "BRL", content_type: "product",
    content_name: "Serviço opcional de rastreamento",
    content_ids: ["rastreamento-opcional"],
    contents: [{ id: "rastreamento-opcional", quantity: 1, item_price: value }],
    num_items: 1, payment_method: "pix",
  }, charge.id, charge.tracking);
}
