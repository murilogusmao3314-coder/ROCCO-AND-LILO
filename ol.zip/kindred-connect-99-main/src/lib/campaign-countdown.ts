export const countdownStorageKey = "corre-rosa-countdown-deadline-v1";
export const countdownDuration = 10 * 60 * 1000;
let fallbackDeadline: number | null = null;

export function countdownDeadline(now = Date.now()): number {
  try {
    const stored = Number(sessionStorage.getItem(countdownStorageKey));
    if (Number.isFinite(stored) && stored > now && stored <= now + countdownDuration) return stored;
    const deadline = now + countdownDuration;
    sessionStorage.setItem(countdownStorageKey, String(deadline));
    fallbackDeadline = deadline;
    return deadline;
  } catch {
    if (fallbackDeadline === null || fallbackDeadline <= now) {
      fallbackDeadline = now + countdownDuration;
    }
    return fallbackDeadline;
  }
}

export function countdownSeconds(deadline: number, now = Date.now()): number {
  return Math.max(0, Math.ceil((deadline - now) / 1000));
}

export function countdownLabel(seconds: number): string {
  return (
    String(Math.floor(seconds / 60)).padStart(2, "0") + ":" + String(seconds % 60).padStart(2, "0")
  );
}
