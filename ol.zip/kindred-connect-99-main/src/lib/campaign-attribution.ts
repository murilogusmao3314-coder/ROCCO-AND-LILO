import {
  defaultParseSearch,
  defaultStringifySearch,
  type SearchMiddleware,
} from "@tanstack/react-router";

import {
  trackingKeys,
  isTrackingKey,
  selectTrackingParameters,
  getStoredTrackingParameters,
  trackingBootstrap,
  type TrackingParameters,
} from "@/lib/tracking";

export const attributionKeys = trackingKeys;
export type AttributionSearch = TrackingParameters;
const isAttributionKey = isTrackingKey;
export const validateAttributionSearch = selectTrackingParameters;

export const retainAttributionSearch: SearchMiddleware<AttributionSearch> = ({ search, next }) => ({
  ...getStoredTrackingParameters(),
  ...validateAttributionSearch(search),
  ...next(search),
});

// Campaign IDs are opaque strings. JSON parsing can round large numbers or drop "false"/"null".
export function parseAttributionSearch(searchStr: string): Record<string, unknown> {
  const parsed: Record<string, unknown> = defaultParseSearch(searchStr);
  const query = new URLSearchParams(searchStr);
  for (const [key, value] of query) {
    if (isAttributionKey(key) && query.getAll(key).length === 1) parsed[key] = value;
  }
  return parsed;
}

export function stringifyAttributionSearch(search: Record<string, unknown>): string {
  const remaining = Object.fromEntries(
    Object.entries(search).filter(([key]) => !isAttributionKey(key)),
  );
  const query = new URLSearchParams(defaultStringifySearch(remaining));
  for (const [key, value] of Object.entries(validateAttributionSearch(search)))
    if (typeof value === "string") query.set(key, value);
  const encoded = query.toString();
  return encoded ? `?${encoded}` : "";
}

// Kept for migrating visitors with the previous session-only implementation.
export const attributionSessionKey = "corre-rosa-attribution-session-v1";
export const attributionSessionBootstrap = trackingBootstrap;
