import { trackingSearch } from "@/lib/tracking";
import { useEffect, useRef, useState, type FormEvent, type InputHTMLAttributes } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { createPixCharge, type PixCharge } from "@/lib/pix.functions";
import { PixPayment } from "@/components/pix-payment";
import { handOffTrackingAccess } from "@/lib/tracking-access";
import { rememberTrackingOrder } from "@/lib/tracking-return";
import { captureTracking } from "@/lib/tracking";
import { trackMetaCheckout, trackMetaOrderPayment } from "@/lib/meta-pixel";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Info,
  LoaderCircle,
  LockKeyhole,
  Truck,
} from "lucide-react";
import { KitSizePicker } from "@/components/kit-size-picker";
import { CampaignModal } from "@/components/campaign-modal";
import { CampaignCountdown } from "@/components/campaign-countdown";
import {
  campaignImages,
  currency,
  kit,
  offers,
  productImages,
  shippingOptions,
} from "@/data/campaign";
import {
  checkoutTotals,
  digits,
  formatCep,
  formatCpf,
  formatPhone,
  readSelection,
  states,
  validateAddress,
  validateDetails,
  type Address,
  type KitSelection,
  type OfferSelection,
  type PersonalDetails,
} from "@/lib/checkout";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Checkout | Kit Corre Rosa" }] }),
  component: Checkout,
});
const steps = ["Dados", "Entrega", "Ofertas", "Pagamento"];
const emptyDetails: PersonalDetails = {
  name: "",
  phone: "",
  email: "",
  cpf: "",
};
const emptyAddress: Address = {
  cep: "",
  street: "",
  number: "",
  complement: "",
  district: "",
  city: "",
  state: "",
};

function Field({
  label,
  error,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  error?: string | undefined;
}) {
  return (
    <label className="checkout-field">
      <span id={props.id + "-label"}>{label}</span>
      <input
        {...props}
        aria-labelledby={props.id + "-label"}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? props.id + "-error" : undefined}
      />
      {error && (
        <span className="checkout-field-error" id={props.id + "-error"}>
          {error}
        </span>
      )}
    </label>
  );
}

function Checkout() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [details, setDetails] = useState<PersonalDetails>(emptyDetails);
  const [address, setAddress] = useState<Address>(emptyAddress);
  const [selection, setSelection] = useState<KitSelection | null>(null);
  const [sizesOpen, setSizesOpen] = useState(false);
  const [offerSizeOpen, setOfferSizeOpen] = useState(false);
  const [sizeOfferId, setSizeOfferId] = useState("socks");
  const [leaving, setLeaving] = useState(false);
  const [direction, setDirection] = useState("forward");
  const stageTimer = useRef<number | null>(null);
  const [selectedOffers, setSelectedOffers] = useState<OfferSelection>({});
  const [shipping, setShipping] = useState("free");
  const [correiosImageFailed, setCorreiosImageFailed] = useState(false);
  const [loggiImageFailed, setLoggiImageFailed] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [cepStatus, setCepStatus] = useState({ loading: false, error: "" });
  const heading = useRef<HTMLHeadingElement>(null);
  const totals = checkoutTotals(selectedOffers, shipping);
  const createPix = useServerFn(createPixCharge);
  const [pix, setPix] = useState<PixCharge | null>(null);
  const [pixLoading, setPixLoading] = useState(false);
  const [pixError, setPixError] = useState("");
  const checkoutEventSent = useRef(false);

  // The checkout owns its IC event, including direct entries and restored sessions.
  // Retry briefly if the Meta bootstrap is not yet ready; never block payment.
  useEffect(() => {
    let active = true;
    let retryTimer: number | undefined;
    let retries = 0;

    function reportCheckoutEntry() {
      if (!active || checkoutEventSent.current) return;
      let sent = false;
      try {
        sent = trackMetaCheckout();
      } catch {
        // Analytics must never prevent a buyer from opening the checkout.
      }
      if (sent) {
        checkoutEventSent.current = true;
      } else if (retries < 10) {
        retries += 1;
        retryTimer = window.setTimeout(reportCheckoutEntry, 500);
      }
    }

    reportCheckoutEntry();
    return () => {
      active = false;
      if (retryTimer !== undefined) window.clearTimeout(retryTimer);
    };
  }, []);
  async function generatePix() {
    setPixLoading(true);
    setPixError("");
    try {
      const tracking = captureTracking();
      const charge = await createPix({
        data: {
          tracking,
          offers: selectedOffers,
          shipping: shipping === "express" ? "express" : "free",
          customer: {
            name: details.name.trim(),
            email: details.email.trim(),
            phone: digits(details.phone),
            document: digits(details.cpf),
          },
          address: {
            street: address.street,
            number: address.number,
            complement: address.complement,
            neighborhood: address.district,
            city: address.city,
            state: address.state,
            zipcode: digits(address.cep),
          },
        },
      });
      // Keep the attribution of this transaction even if another ad is opened later.
      charge.tracking ??= tracking;
      rememberTrackingOrder(charge.id, {
        amount: charge.amount,
        offers: selectedOffers,
        shipping,
        tracking: charge.tracking,
      });
      setPix(charge);
      trackMetaOrderPayment("AddPaymentInfo", charge, selectedOffers, shipping);
    } catch {
      setPixError("Não foi possível gerar o Pix agora. Tente novamente em instantes.");
    } finally {
      setPixLoading(false);
    }
  }
  const sizeOffer = offers.find((offer) => offer.id === sizeOfferId) ?? offers[0];

  useEffect(
    () => () => {
      if (stageTimer.current !== null) window.clearTimeout(stageTimer.current);
    },
    [],
  );

  useEffect(() => {
    const saved = readSelection();
    setSelection(saved);
    if (!saved) setSizesOpen(true);
  }, []);
  useEffect(() => {
    heading.current?.focus({ preventScroll: true });
  }, [step, pix?.id]);
  useEffect(() => {
    const cep = digits(address.cep);
    if (step !== 1 || cep.length !== 8) {
      setCepStatus({ loading: false, error: "" });
      return;
    }
    const controller = new AbortController();
    let active = true;
    const timeout = window.setTimeout(() => controller.abort(), 7000);
    setCepStatus({ loading: true, error: "" });
    void fetch("https://viacep.com.br/ws/" + cep + "/json/", {
      signal: controller.signal,
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("CEP não encontrado");
        const data: unknown = await response.json();
        if (!data || typeof data !== "object" || "erro" in data)
          throw new Error("CEP não encontrado");
        const result = data as Record<string, unknown>;
        if (!active) return;
        setAddress((previous) => ({
          ...previous,
          street:
            typeof result["logradouro"] === "string" && result["logradouro"]
              ? result["logradouro"]
              : previous.street,
          district:
            typeof result["bairro"] === "string" && result["bairro"]
              ? result["bairro"]
              : previous.district,
          city: typeof result["localidade"] === "string" ? result["localidade"] : previous.city,
          state: typeof result["uf"] === "string" ? result["uf"] : previous.state,
        }));
        setCepStatus({ loading: false, error: "" });
      })
      .catch(() => {
        if (active)
          setCepStatus({
            loading: false,
            error: "Não foi possível consultar o CEP. Preencha o endereço manualmente.",
          });
      })
      .finally(() => window.clearTimeout(timeout));
    return () => {
      active = false;
      controller.abort();
      window.clearTimeout(timeout);
    };
  }, [address.cep, step]);

  const updateDetails = (field: keyof PersonalDetails, value: string) => {
    setDetails((previous) => ({ ...previous, [field]: value }));
    setErrors((previous) => ({ ...previous, [field]: "" }));
  };
  const updateAddress = (field: keyof Address, value: string) => {
    setAddress((previous) => ({ ...previous, [field]: value }));
    setErrors((previous) => ({ ...previous, [field]: "" }));
  };
  const goTo = (next: number) => {
    if (stageTimer.current !== null || next === step) return;
    setErrors({});
    setDirection(next > step ? "forward" : "backward");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const finish = () => {
      setStep(next);
      setSummaryOpen(false);
      setLeaving(false);
      stageTimer.current = null;
      window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" });
    };
    if (reducedMotion) finish();
    else {
      setLeaving(true);
      stageTimer.current = window.setTimeout(finish, 180);
    }
  };
  const next = (event: FormEvent) => {
    event.preventDefault();
    if (!selection) {
      setSizesOpen(true);
      return;
    }
    const result =
      step === 0 ? validateDetails(details) : step === 1 ? validateAddress(address) : {};
    if (step === 2)
      for (const offer of totals.extras)
        if (offer.needsSize && !selectedOffers[offer.id])
          result[offer.id] = "Escolha o tamanho das meias.";
    setErrors(result);
    if (Object.keys(result).length) {
      requestAnimationFrame(() =>
        document.querySelector<HTMLInputElement>(".checkout-form [aria-invalid=true]")?.focus(),
      );
      return;
    }
    if (step < 3) goTo(step + 1);
  };
  const openOfferSizes = (id: string) => {
    setSizeOfferId(id);
    setOfferSizeOpen(true);
  };
  const toggleOffer = (id: string, checked: boolean) => {
    if (checked && offers.find((offer) => offer.id === id)?.needsSize) {
      openOfferSizes(id);
      return;
    }
    setSelectedOffers((previous) => {
      const next = { ...previous };
      if (checked) next[id] = "";
      else delete next[id];
      return next;
    });
    setErrors((previous) => ({ ...previous, [id]: "" }));
  };

  return (
    <div className="campaign-shell checkout-shell">
      <a className="campaign-skip" href="#checkout-content">
        Pular para o conteúdo
      </a>
      <header className="checkout-header">
        <Link to="/loja" search={trackingSearch} aria-label="Voltar à loja">
          <img src={campaignImages.logo} alt="Olympikus" width="120" height="60" />
        </Link>
        <span>
          <LockKeyhole size={15} aria-hidden="true" /> Compra segura
        </span>
      </header>
      <CampaignCountdown />
      <div className="checkout-order-summary">
        <button
          type="button"
          className="checkout-summary-toggle"
          aria-expanded={summaryOpen}
          aria-controls="checkout-summary"
          onClick={() => setSummaryOpen((previous) => !previous)}
        >
          <span>
            Resumo do pedido <ChevronDown size={16} aria-hidden="true" />
          </span>
          <strong>{currency(totals.total)}</strong>
        </button>
        <div
          className={"checkout-summary-collapse" + (summaryOpen ? " is-open" : "")}
          aria-hidden={!summaryOpen}
          inert={!summaryOpen}
        >
          <div className="checkout-summary-inner">
            <section
              className="checkout-summary"
              id="checkout-summary"
              aria-label="Resumo do pedido"
            >
              <div className="checkout-summary-kit">
                <img
                  src={productImages[0]!.src}
                  alt="Kit Corre Rosa completo"
                  width="64"
                  height="64"
                />
                <div className="checkout-summary-item">
                  <strong>{kit.title}</strong>
                  <div className="checkout-summary-item-meta">
                    <div>
                      <small>Qtd: 1</small>
                      <p>
                        {selection
                          ? "Tênis " +
                            selection.shoe +
                            " · Regata " +
                            selection.shirt +
                            " · Shorts " +
                            selection.shorts
                          : "Tamanhos ainda não selecionados"}
                      </p>
                    </div>
                    <div className="checkout-summary-item-price">
                      <del>{currency(kit.originalPrice)}</del>
                      <strong>{currency(kit.price)}</strong>
                    </div>
                  </div>
                  {!pix && (
                    <button type="button" onClick={() => setSizesOpen(true)}>
                      Alterar tamanhos
                    </button>
                  )}
                </div>
              </div>
              {totals.extras.map((offer) => (
                <p className="checkout-price-line" key={offer.id}>
                  <span>
                    {offer.title}
                    {selectedOffers[offer.id] ? " · " + selectedOffers[offer.id] : ""}
                  </span>
                  <span>{currency(offer.price)}</span>
                </p>
              ))}
              <p className="checkout-price-line">
                <span>Subtotal</span>
                <span>{currency(totals.subtotal)}</span>
              </p>
              <p className="checkout-price-line">
                <span>Frete</span>
                <span>{totals.freight ? currency(totals.freight) : "Grátis"}</span>
              </p>
              <p className="checkout-price-line is-total">
                <span>Total</span>
                <strong>{currency(totals.total)}</strong>
              </p>
            </section>
          </div>
        </div>
      </div>
      <ol className="checkout-steps" aria-label="Etapas do checkout">
        {steps.map((name, index) => (
          <li
            key={name}
            className={index === step ? "is-active" : index < step ? "is-complete" : ""}
            aria-current={index === step ? "step" : undefined}
          >
            <span>{index < step ? <Check size={14} /> : index + 1}</span>
            <small>{name}</small>
          </li>
        ))}
      </ol>
      <main id="checkout-content" className="checkout-content">
        <form className="checkout-form" onSubmit={next} noValidate>
          <div className="checkout-title-row">
            <h1 ref={heading} tabIndex={-1}>
              {step === 0
                ? "SEUS DADOS"
                : step === 1
                  ? "ENDEREÇO DE ENTREGA"
                  : step === 2
                    ? "OFERTAS PARA SEU CORRE"
                    : pix
                      ? "PAGUE COM PIX"
                      : "PAGAMENTO"}
            </h1>
            {step === 0 && (
              <Link to="/loja" search={trackingSearch}>
                <ArrowLeft size={15} /> Voltar à loja
              </Link>
            )}
          </div>
          <div
            className={"checkout-stage" + (leaving ? " is-leaving" : "")}
            data-direction={direction}
            key={step}
            inert={leaving}
          >
            {step === 0 && (
              <>
                <Field
                  id="customer-name"
                  label="NOME COMPLETO"
                  value={details.name}
                  onChange={(event) => updateDetails("name", event.target.value)}
                  autoComplete="name"
                  maxLength={100}
                  error={errors["name"]}
                />
                <Field
                  id="customer-phone"
                  label="TELEFONE"
                  value={details.phone}
                  onChange={(event) => updateDetails("phone", formatPhone(event.target.value))}
                  autoComplete="tel"
                  inputMode="tel"
                  placeholder="(00) 00000-0000"
                  maxLength={16}
                  error={errors["phone"]}
                />
                <Field
                  id="customer-email"
                  label="E-MAIL"
                  value={details.email}
                  onChange={(event) => updateDetails("email", event.target.value)}
                  autoComplete="email"
                  type="email"
                  maxLength={150}
                  error={errors["email"]}
                />
                <Field
                  id="customer-cpf"
                  label="CPF"
                  value={details.cpf}
                  onChange={(event) => updateDetails("cpf", formatCpf(event.target.value))}
                  autoComplete="off"
                  inputMode="numeric"
                  placeholder="000.000.000-00"
                  maxLength={14}
                  error={errors["cpf"]}
                />
              </>
            )}
            {step === 1 && (
              <>
                <Field
                  id="address-cep"
                  label="CEP"
                  value={address.cep}
                  onChange={(event) => updateAddress("cep", formatCep(event.target.value))}
                  autoComplete="postal-code"
                  inputMode="numeric"
                  placeholder="00000-000"
                  maxLength={9}
                  error={errors["cep"]}
                />
                <div className="checkout-cep-status" role="status">
                  {cepStatus.loading ? (
                    <>
                      <LoaderCircle size={15} className="checkout-spinner" /> Buscando endereço…
                    </>
                  ) : (
                    cepStatus.error
                  )}
                </div>
                <Field
                  id="address-street"
                  label="RUA / AVENIDA"
                  value={address.street}
                  onChange={(event) => updateAddress("street", event.target.value)}
                  autoComplete="address-line1"
                  maxLength={150}
                  error={errors["street"]}
                />
                <div className="checkout-field-grid">
                  <Field
                    id="address-number"
                    label="NÚMERO"
                    value={address.number}
                    onChange={(event) => updateAddress("number", event.target.value)}
                    maxLength={10}
                    error={errors["number"]}
                  />
                  <Field
                    id="address-complement"
                    label="COMPLEMENTO"
                    value={address.complement}
                    onChange={(event) => updateAddress("complement", event.target.value)}
                    autoComplete="address-line2"
                    placeholder="Opcional"
                    maxLength={80}
                  />
                </div>
                <Field
                  id="address-district"
                  label="BAIRRO"
                  value={address.district}
                  onChange={(event) => updateAddress("district", event.target.value)}
                  maxLength={80}
                  error={errors["district"]}
                />
                <div className="checkout-city-grid">
                  <Field
                    id="address-city"
                    label="CIDADE"
                    value={address.city}
                    onChange={(event) => updateAddress("city", event.target.value)}
                    autoComplete="address-level2"
                    maxLength={80}
                    error={errors["city"]}
                  />
                  <label className="checkout-field">
                    <span id="address-state-label">UF</span>
                    <select
                      id="address-state"
                      aria-labelledby="address-state-label"
                      aria-describedby={errors["state"] ? "address-state-error" : undefined}
                      aria-invalid={Boolean(errors["state"])}
                      value={address.state}
                      onChange={(event) => updateAddress("state", event.target.value)}
                      autoComplete="address-level1"
                    >
                      <option value="">UF</option>
                      {states.map((state) => (
                        <option key={state}>{state}</option>
                      ))}
                    </select>
                    {errors["state"] && (
                      <span id="address-state-error" className="checkout-field-error">
                        {errors["state"]}
                      </span>
                    )}
                  </label>
                </div>
                <fieldset className="checkout-shipping">
                  <legend>FRETE</legend>
                  {shippingOptions.map((option) => (
                    <label key={option.id} className={shipping === option.id ? "is-selected" : ""}>
                      <input
                        type="radio"
                        name="shipping"
                        value={option.id}
                        checked={shipping === option.id}
                        onChange={() => setShipping(option.id)}
                      />
                      {(option.id === "express" && !correiosImageFailed) ||
                      (option.id === "free" && !loggiImageFailed) ? (
                        <img
                          className="checkout-shipping-logo"
                          src={
                            option.id === "free" ? "/campaign/loggi.png" : "/campaign/correios.webp"
                          }
                          alt={option.id === "free" ? "Loggi" : ""}
                          width="48"
                          height="33"
                          decoding="async"
                          onError={() =>
                            option.id === "free"
                              ? setLoggiImageFailed(true)
                              : setCorreiosImageFailed(true)
                          }
                        />
                      ) : (
                        <Truck size={22} aria-hidden="true" />
                      )}
                      <span>
                        <strong>{option.title}</strong>
                        <small>{option.description}</small>
                      </span>
                      <b>{option.price ? currency(option.price) : "Grátis"}</b>
                    </label>
                  ))}
                </fieldset>
              </>
            )}
            {step === 2 && (
              <>
                <p className="checkout-stage-intro">
                  Complete seu kit se quiser. Os adicionais são opcionais.
                </p>
                {offers.map((offer) => {
                  const selected = Object.hasOwn(selectedOffers, offer.id);
                  return (
                    <section
                      className={"checkout-offer" + (selected ? " is-selected" : "")}
                      key={offer.id}
                    >
                      <div className="checkout-offer-body">
                        <img
                          src={offer.image}
                          alt={offer.title}
                          width="110"
                          height="110"
                          loading="lazy"
                        />
                        <div>
                          <h2>{offer.title}</h2>
                          <del>{currency(offer.originalPrice)}</del>
                          <strong>{currency(offer.price)}</strong>
                        </div>
                      </div>
                      <label className="checkout-offer-check">
                        <input
                          type="checkbox"
                          checked={selected}
                          onChange={(event) => toggleOffer(offer.id, event.target.checked)}
                        />
                        <span>Adicionar ao meu pedido</span>
                      </label>
                      {offer.needsSize && (
                        <div className="checkout-field checkout-offer-size">
                          <span id={offer.id + "-size-label"}>TAMANHO DAS MEIAS</span>
                          <button
                            type="button"
                            className="checkout-size-trigger"
                            aria-label={"Selecionar tamanho: " + offer.title}
                            aria-haspopup="dialog"
                            aria-expanded={offerSizeOpen && sizeOfferId === offer.id}
                            aria-describedby={
                              errors[offer.id] ? offer.id + "-size-error" : undefined
                            }
                            aria-invalid={Boolean(errors[offer.id])}
                            onClick={() => openOfferSizes(offer.id)}
                          >
                            <span>{selectedOffers[offer.id] || "Selecionar tamanho"}</span>
                            <ChevronDown size={20} aria-hidden="true" />
                          </button>
                          {errors[offer.id] && (
                            <span id={offer.id + "-size-error"} className="checkout-field-error">
                              {errors[offer.id]}
                            </span>
                          )}
                        </div>
                      )}
                    </section>
                  );
                })}
                <p className="checkout-caption">Para seguir sem adicionais, basta continuar.</p>
              </>
            )}
            {step === 3 &&
              (pix ? (
                <PixPayment
                  key={pix.id}
                  charge={pix}
                  onApproved={(charge) => {
                    rememberTrackingOrder(charge.id);
                    trackMetaOrderPayment("Purchase", charge, selectedOffers, shipping);
                    if (charge.trackingAccess) {
                      handOffTrackingAccess(charge.trackingAccess);
                    }
                    void navigate({ to: "/rastreamento", search: trackingSearch, replace: true });
                  }}
                  onRetry={() => {
                    setPix(null);
                    setPixError("");
                  }}
                />
              ) : (
                <>
                  <div className="checkout-payment-methods">
                    <div className="is-selected">
                      <span className="checkout-pix-symbol" aria-hidden="true">
                        ❖
                      </span>
                      <strong>PIX</strong>
                    </div>
                  </div>
                  {pixError && (
                    <div className="checkout-config-notice" role="alert">
                      <Info size={21} aria-hidden="true" />
                      <div>
                        <strong>Erro no pagamento</strong>
                        <p>{pixError}</p>
                      </div>
                    </div>
                  )}
                  <section
                    className="checkout-review checkout-review--details"
                    aria-label="Dados e entrega"
                  >
                    <div className="checkout-review-section">
                      <h2>
                        Seus dados
                        <button type="button" aria-label="Editar dados" onClick={() => goTo(0)}>
                          Editar
                        </button>
                      </h2>
                      <p>
                        <span>{details.name}</span>
                        <span>{details.email}</span>
                      </p>
                    </div>
                    <div className="checkout-review-section">
                      <h2>
                        Entrega
                        <button type="button" aria-label="Editar endereço" onClick={() => goTo(1)}>
                          Editar
                        </button>
                      </h2>
                      <p>
                        <span>
                          {address.street}, {address.number}
                          {address.complement ? " · " + address.complement : ""}
                        </span>
                        <span>
                          {address.city}/{address.state} · CEP {address.cep}
                        </span>
                      </p>
                    </div>
                  </section>
                </>
              ))}
          </div>
          {!pix && (
            <div className="checkout-actions">
              {step < 3 ? (
                <button className="campaign-button" type="submit" disabled={leaving}>
                  CONTINUAR
                </button>
              ) : (
                <button
                  className="campaign-button"
                  type="button"
                  disabled={pixLoading}
                  onClick={() => void generatePix()}
                >
                  {pixLoading ? "GERANDO PIX…" : "GERAR PIX"}
                </button>
              )}
              {step > 0 && (
                <button
                  type="button"
                  className="campaign-text-button"
                  disabled={leaving}
                  onClick={() => goTo(step - 1)}
                >
                  <ArrowLeft size={16} /> Voltar
                </button>
              )}
            </div>
          )}
        </form>
      </main>
      <footer className="checkout-footer">
        <LockKeyhole size={14} aria-hidden="true" />{" "}
        {pix
          ? "Acompanhe a confirmação do pagamento nesta página."
          : "Revise seu pedido antes de concluir."}
      </footer>
      <CampaignModal
        open={offerSizeOpen}
        onClose={() => setOfferSizeOpen(false)}
        title="ESCOLHA O TAMANHO DAS MEIAS"
        description="Toque no tamanho para adicionar ao seu pedido."
        className="offer-size-dialog campaign-modal--sheet"
      >
        <div className="offer-size-preview">
          <img src={sizeOffer.image} alt="" width="80" height="80" />
          <div>
            <strong>{sizeOffer.title}</strong>
            <span>{currency(sizeOffer.price)}</span>
          </div>
        </div>
        <div className="offer-size-options" role="group" aria-label="Tamanhos disponíveis">
          {["34 a 38", "39 a 44"].map((size) => (
            <button
              type="button"
              key={size}
              aria-pressed={selectedOffers[sizeOffer.id] === size}
              onClick={() => {
                setSelectedOffers((previous) => ({
                  ...previous,
                  [sizeOffer.id]: size,
                }));
                setErrors((previous) => ({ ...previous, [sizeOffer.id]: "" }));
                setOfferSizeOpen(false);
              }}
            >
              <span>{size}</span>
              <span className="offer-size-check" aria-hidden="true">
                <Check size={18} />
              </span>
            </button>
          ))}
        </div>
      </CampaignModal>
      <KitSizePicker
        open={sizesOpen}
        initial={selection}
        onClose={() => setSizesOpen(false)}
        onComplete={(value) => {
          setSelection(value);
          setSizesOpen(false);
        }}
      />
    </div>
  );
}
