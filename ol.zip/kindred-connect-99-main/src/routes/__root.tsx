import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import { buildUrlWithTracking, trackingSearch } from "@/lib/tracking";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { CampaignTracking } from "@/components/campaign-tracking";
import { metaPixelBootstrap, metaPixelId } from "@/lib/meta-pixel";
import { TrackingReturn } from "@/components/tracking-return";
import {
  attributionSessionBootstrap,
  retainAttributionSearch,
  validateAttributionSearch,
} from "@/lib/campaign-attribution";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            search={trackingSearch}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href={buildUrlWithTracking("/")}
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  validateSearch: validateAttributionSearch,
  search: { middlewares: [retainAttributionSearch] },
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Um corre por todas | Outubro Rosa" },
      {
        name: "description",
        content: "Um desafio sobre conscientização, cuidado e a campanha Outubro Rosa.",
      },
      { name: "author", content: "Olympikus" },
      { property: "og:title", content: "Um corre por todas | Outubro Rosa" },
      {
        property: "og:description",
        content: "Um desafio sobre conscientização, cuidado e a campanha Outubro Rosa.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "preload",
        as: "font",
        href: "/fonts/inter-latin-variable.woff2",
        type: "font/woff2",
        crossOrigin: "anonymous",
      },
      { rel: "preload", as: "image", href: "/campaign/pergunta1-outubro-rosa.webp" },
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/campaign-icon.svg", type: "image/svg+xml" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
        <script
          id="campaign-attribution-persistent"
          dangerouslySetInnerHTML={{ __html: attributionSessionBootstrap }}
        />
        <script id="meta-pixel-bootstrap" dangerouslySetInnerHTML={{ __html: metaPixelBootstrap }} />
        {/* Load UTMify only after pixelId is defined (avoid async-script hoisting). */}
        <script
          id="utmify-pixel-config"
          dangerouslySetInnerHTML={{ __html: 'window.pixelId = "6ace976f8708e36bd87c56a5";' }}
        />
        <script
          id="utmify-pixel-loader"
          src="https://cdn.utmify.com.br/scripts/pixel/pixel.js"
          defer
        />
        {/* Keep the independent UTMify attribution script enabled. */}
        <script
          id="utmify-utm-script"
          src="https://cdn.utmify.com.br/scripts/utms/latest.js"
          data-utmify-prevent-xcod-sck
          data-utmify-prevent-subids
          defer
        />
      </head>
      <body>
        <noscript>
          <img height="1" width="1" alt="" style={{ display: "none" }}
               src={`https://www.facebook.com/tr?id=${metaPixelId}&ev=PageView&noscript=1`} />
        </noscript>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <CampaignTracking />
      <TrackingReturn />
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
    </QueryClientProvider>
  );
}
