import { trackingSearch } from "@/lib/tracking";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { CampaignFrame } from "@/components/campaign-frame";
import { campaignImages } from "@/data/campaign";

export const Route = createFileRoute("/")({ component: Index });

function Index() {
  return (
    <CampaignFrame>
      <section className="campaign-intro">
        <img
          className="campaign-challenge"
          src={campaignImages.challenge}
          alt="Desafio Outubro Rosa"
          width="577"
          height="433"
          fetchPriority="high"
        />
        <h1>
          <img
            className="campaign-headline"
            src={campaignImages.headline}
            alt="Um corre por todas"
            width="1000"
            height="333"
          />
        </h1>
        <p>
          Um passo também pode ser um gesto de cuidado. Neste <strong>Outubro Rosa</strong>, entre
          no movimento e teste seus conhecimentos sobre a causa.
        </p>
        <p>
          São <strong>5 perguntas</strong> sobre conscientização, hábitos saudáveis e a campanha.
          Vamos juntas?
        </p>
        <Link
          className="campaign-button campaign-button--pulse"
          to="/quiz"
          search={trackingSearch}
          preload="render"
          onClick={() => {
            try {
              sessionStorage.removeItem("outubro-rosa-quiz-v1");
            } catch {
              /* Storage is optional. */
            }
          }}
        >
          INICIAR QUIZ <ArrowRight size={18} aria-hidden="true" />
        </Link>
        <span className="campaign-caption">Leva cerca de 2 minutos</span>
      </section>
      <div className="campaign-ribbon" aria-hidden="true">
        <img src={campaignImages.ribbon} alt="" width="240" height="240" />
      </div>
    </CampaignFrame>
  );
}
