import { trackingSearch } from "@/lib/tracking";
import { useCallback, useEffect, useRef, useState } from "react";
import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import useEmblaCarousel from "embla-carousel-react";
import { ChevronLeft, ChevronRight, Heart, Pause, Play, RefreshCw, Ruler } from "lucide-react";
import { CampaignFrame } from "@/components/campaign-frame";
import { CampaignCountdown } from "@/components/campaign-countdown";
import { CustomerReviews } from "@/components/customer-reviews";
import { KitSizePicker, SizeGuide } from "@/components/kit-size-picker";
import { StoreFooter } from "@/components/store-footer";
import { currency, kit, productImages } from "@/data/campaign";
import { readSelection } from "@/lib/checkout";
import { trackMetaCart, trackMetaWishlist } from "@/lib/meta-pixel";

export const Route = createFileRoute("/loja")({
  head: () => ({
    meta: [{ title: "Kit Corre Rosa | Outubro Rosa" }],
    links: [{ rel: "preload", as: "image", href: productImages[0]!.src }],
  }),
  component: CampaignStore,
});

function CampaignStore() {
  const navigate = useNavigate();
  const router = useRouter();
  useEffect(() => {
    void router.preloadRoute({ to: "/checkout" });
  }, [router]);
  const [carouselRef, carousel] = useEmblaCarousel({ loop: true, duration: 28 });
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);
  const [sizesOpen, setSizesOpen] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const [favorite, setFavorite] = useState(false);
  const dots = useRef<HTMLDivElement>(null);
  const onSelect = useCallback(() => {
    if (carousel) setActive(carousel.selectedScrollSnap());
  }, [carousel]);
  useEffect(() => {
    if (!carousel) return;
    carousel.on("select", onSelect).on("reInit", onSelect);
    const pause = () => setPaused(true);
    carousel.on("pointerDown", pause);
    return () => {
      carousel.off("select", onSelect).off("reInit", onSelect).off("pointerDown", pause);
    };
  }, [carousel, onSelect]);
  useEffect(() => {
    if (!carousel || paused || window.matchMedia("(prefers-reduced-motion: reduce)").matches)
      return;
    const timer = window.setInterval(() => {
      if (!document.hidden && !dots.current?.contains(document.activeElement))
        carousel.scrollNext();
    }, 4500);
    return () => window.clearInterval(timer);
  }, [carousel, paused]);
  const selectPhoto = (index: number) => {
    setPaused(true);
    carousel?.scrollTo(index);
  };
  const buy = () => setSizesOpen(true);

  return (
    <CampaignFrame
      shop
      banner={<CampaignCountdown />}
      footer={<StoreFooter onSizeGuide={() => setGuideOpen(true)} />}
    >
      <section className="store-product-heading">
        <button
          className="store-favorite"
          aria-label={favorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
          aria-pressed={favorite}
          onClick={() => {
            if (!favorite) trackMetaWishlist();
            setFavorite((previous) => !previous);
          }}
        >
          <Heart size={23} fill={favorite ? "currentColor" : "none"} />
        </button>
        <h1>
          <img
            src="/campaign/loja-header-v2.webp"
            alt={kit.title}
            width="478"
            height="123"
            fetchPriority="high"
          />
        </h1>
        <div className="store-price">
          <del>{currency(kit.originalPrice)}</del>
          <strong>{currency(kit.price)}</strong>
        </div>
      </section>
      <section
        className="store-gallery"
        aria-label="Galeria do Kit Corre Rosa"
        aria-roledescription="carrossel"
      >
        <div className="store-gallery-viewport" ref={carouselRef}>
          <div className="store-gallery-track">
            {productImages.map((image, index) => (
              <div
                className="store-gallery-slide"
                key={image.src}
                role="group"
                aria-label={index + 1 + " de " + productImages.length}
                aria-roledescription="slide"
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  width="800"
                  height="800"
                  loading={index === 0 ? "eager" : "lazy"}
                  fetchPriority={index === 0 ? "high" : "auto"}
                />
              </div>
            ))}
          </div>
        </div>
        <button
          className="store-gallery-arrow is-prev"
          aria-label="Foto anterior"
          onClick={() => {
            setPaused(true);
            carousel?.scrollPrev();
          }}
        >
          <ChevronLeft size={21} />
        </button>
        <button
          className="store-gallery-arrow is-next"
          aria-label="Próxima foto"
          onClick={() => {
            setPaused(true);
            carousel?.scrollNext();
          }}
        >
          <ChevronRight size={21} />
        </button>
        <button
          className="store-gallery-pause"
          aria-label={paused ? "Reproduzir galeria" : "Pausar galeria"}
          onClick={() => setPaused((previous) => !previous)}
        >
          {paused ? <Play size={15} /> : <Pause size={15} />}
        </button>
        <div className="store-gallery-dots" ref={dots} role="group" aria-label="Escolher foto">
          {productImages.map((image, index) => (
            <button
              key={image.src}
              aria-label={"Ir para imagem " + (index + 1)}
              aria-pressed={active === index}
              onClick={() => selectPhoto(index)}
            >
              <span />
            </button>
          ))}
        </div>
      </section>
      <section className="store-actions">
        <button
          className="campaign-button campaign-button--dark campaign-button--pulse"
          onClick={buy}
        >
          RESGATAR AGORA
        </button>
        <button className="campaign-text-button store-measures" onClick={() => setGuideOpen(true)}>
          <Ruler size={18} /> TABELA DE MEDIDAS
        </button>
      </section>
      <div className="store-benefits">
        <p>
          <span className="store-pix-symbol" aria-hidden="true">
            ❖
          </span>{" "}
          Pague no PIX e economize
        </p>
        <p>
          <RefreshCw size={20} aria-hidden="true" /> A 1ª troca é por nossa conta
        </p>
      </div>
      <section className="store-story">
        <h2>
          <img
            src="/campaign/corre-da-causa.webp"
            alt="O corre da causa"
            width="493"
            height="150"
            loading="lazy"
          />
        </h2>
        <div className="store-story-copy">
          <p>
            O Outubro Rosa coloca o cuidado em movimento. A Olympikus apresenta mais uma edição
            especial da Família Corre, unindo conforto, tecnologia e apoio à conscientização sobre o
            câncer de mama.
          </p>
          <p>
            O Corre Max 2 Outubro Rosa acompanha esse movimento. Conheça o tênis e complete seu
            corre com a regata e o shorts do kit.
          </p>
          <button className="campaign-button" onClick={buy}>
            RESGATAR AGORA
          </button>
        </div>
      </section>
      <img
        className="store-description-image"
        src="/campaign/loja-tenis-rosa-v2.webp"
        alt="Tênis rosa em destaque sobre laços rosa"
        width="1080"
        height="1080"
        loading="lazy"
        decoding="async"
      />
      <img
        className="store-description-image"
        src="/campaign/loja-texto-outubro-rosa.webp"
        alt="O Outubro Rosa conscientiza sobre a prevenção e o diagnóstico precoce do câncer de mama"
        width="482"
        height="423"
        loading="lazy"
        decoding="async"
      />
      <img
        className="store-description-image"
        src="/campaign/loja-tenis-elipses-v2.webp"
        alt="Edição rosa do tênis sobre elipses rosa"
        width="1080"
        height="1440"
        loading="lazy"
        decoding="async"
      />
      <img
        className="store-description-image"
        src="/campaign/santa-casa-texto-v2.webp"
        alt="A campanha oficial da Olympikus destina o lucro da edição Outubro Rosa à Santa Casa de Porto Alegre"
        width="1080"
        height="926"
        loading="lazy"
        decoding="async"
      />
      <div className="store-bottom-action">
        <button className="campaign-button campaign-button--pulse" onClick={buy}>
          COMPRAR AGORA
        </button>
      </div>
      <CustomerReviews />
      {sizesOpen && (
        <KitSizePicker
          open
          onClose={() => setSizesOpen(false)}
          initial={readSelection()}
          onComplete={() => {
            trackMetaCart();
            setSizesOpen(false);
            void navigate({ to: "/checkout", search: trackingSearch });
          }}
        />
      )}
      <SizeGuide open={guideOpen} onClose={() => setGuideOpen(false)} />
    </CampaignFrame>
  );
}
