import { trackingSearch, captureTracking } from "@/lib/tracking";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Check, LoaderCircle, PackageCheck } from "lucide-react";
import { PixPayment } from "@/components/pix-payment";
import { currency } from "@/data/campaign";
import { takeTrackingAccess } from "@/lib/tracking-access";
import { completeTrackingService, rememberTrackingService } from "@/lib/tracking-return";
import {
  createTrackingPix,
  createTrackingPublicPix,
  getTrackingOffer,
} from "@/lib/tracking.functions";
import { TrackingPayerFields, type TrackingPayer } from "@/components/tracking-test-fields";
import { digits, formatCpf, formatPhone, validateDetails } from "@/lib/checkout";
import type { PixCharge } from "@/lib/pix.functions";
import { trackMetaServicePayment } from "@/lib/meta-pixel";
import trackingCss from "../rastreamento.css?url";

export const Route = createFileRoute("/rastreamento")({
  validateSearch: (search: Record<string, unknown>): { preview?: boolean } =>
    search["preview"] === 1 || search["preview"] === "1" ? { preview: true } : {},
  head: () => ({
    meta: [{ title: "Consulta do pedido" }, { name: "robots", content: "noindex, nofollow" }],
    links: [{ rel: "stylesheet", href: trackingCss }],
  }),
  component: TrackingPage,
});

function TrackingPage() {
  const { preview } = Route.useSearch();
  return <Tracking key={preview ? "preview" : "live"} preview={Boolean(preview)} />;
}

function Tracking({ preview }: { preview: boolean }) {
  const loadOffer = useServerFn(getTrackingOffer);
  const createPix = useServerFn(createTrackingPix);
  const createPublicPix = useServerFn(createTrackingPublicPix);
  const access = useRef<string | null>(null);
  const initialized = useRef(false);
  const submitting = useRef(false);
  const heading = useRef<HTMLHeadingElement>(null);
  const [gate, setGate] = useState<"loading" | "ready" | "error">("ready");
  const [orderLinked, setOrderLinked] = useState(false);
  const [payer, setPayer] = useState<TrackingPayer>({ name: "", cpf: "", phone: "", email: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [paymentError, setPaymentError] = useState("");
  const [loading, setLoading] = useState(false);
  const [charge, setCharge] = useState<PixCharge | null>(null);
  const [approved, setApproved] = useState(false);
  const [verificationAttempt, setVerificationAttempt] = useState(0);

  useEffect(() => {
    if (preview) return;
    if (!initialized.current) {
      initialized.current = true;
      access.current = takeTrackingAccess();
    }
    const token = access.current;
    if (!token) return;
    let active = true;
    setGate("loading");
    void loadOffer({ data: { token } }).then(
      (offer) => {
        if (active) {
          setPayer({
            name: offer.customer.name,
            cpf: formatCpf(offer.customer.document),
            phone: formatPhone(offer.customer.phone),
            email: offer.customer.email,
          });
          setOrderLinked(true);
          setGate("ready");
        }
      },
      () => {
        if (active) setGate("error");
      },
    );
    return () => {
      active = false;
    };
  }, [preview, loadOffer, verificationAttempt]);

  useEffect(() => {
    heading.current?.focus({ preventScroll: true });
  }, [gate, charge?.id, approved]);

  async function generatePix(event: FormEvent) {
    event.preventDefault();
    if (submitting.current || charge || gate !== "ready") return;
    const validation = validateDetails(payer);
    if (payer.email.trim().length > 160) validation["email"] = "Informe um e-mail válido.";
    setErrors(validation);
    if (Object.keys(validation).length) {
      document.getElementById("tracking-" + Object.keys(validation)[0])?.focus();
      return;
    }
    const customer = {
      name: payer.name.trim(),
      email: payer.email.trim(),
      phone: digits(payer.phone),
      document: digits(payer.cpf),
    };
    submitting.current = true;
    setLoading(true);
    setPaymentError("");
    try {
      const tracking = captureTracking();
      const result = orderLinked
        ? await createPix({ data: { token: access.current!, customer, tracking } })
        : await createPublicPix({
            data: {
              confirmRealCharge: true,
              mode: preview ? "test" : "service",
              customer,
              tracking,
            },
          });
      if (!result.ok) {
        setPaymentError(result.error);
        return;
      }
      result.charge.tracking ??= tracking;
      setPayer((previous) => ({ ...previous, email: customer.email }));
      setCharge(result.charge);
      if (!preview) {
        rememberTrackingService(result.charge.id, {
          amount: result.charge.amount,
          tracking: result.charge.tracking,
        });
        trackMetaServicePayment("AddPaymentInfo", result.charge);
      }
    } catch {
      setPaymentError("Não foi possível gerar o Pix agora. Tente novamente.");
    } finally {
      submitting.current = false;
      setLoading(false);
    }
  }

  return (
    <main className="campaign-shell tracking-page" aria-labelledby="tracking-title">
      <section className="tracking-card">
        {gate === "loading" ? (
          <div className="tracking-state" role="status">
            <LoaderCircle className="checkout-spinner" size={30} aria-hidden="true" />
            <h1 id="tracking-title" ref={heading} tabIndex={-1}>
              Confirmando seu pedido…
            </h1>
          </div>
        ) : gate === "error" ? (
          <div className="tracking-state">
            <h1 id="tracking-title" ref={heading} tabIndex={-1}>
              Não foi possível confirmar o acesso
            </h1>
            <p role="alert">Tente novamente para consultar o pagamento do seu pedido.</p>
            <button
              className="campaign-button"
              type="button"
              onClick={() => setVerificationAttempt((value) => value + 1)}
            >
              TENTAR NOVAMENTE
            </button>
            <Link to="/loja" search={trackingSearch} replace className="campaign-text-button">
              Voltar à loja
            </Link>
          </div>
        ) : approved ? (
          <div className="tracking-state" role="status">
            <span className="tracking-icon">
              <Check size={26} aria-hidden="true" />
            </span>
            <h1 id="tracking-title" ref={heading} tabIndex={-1}>
              {preview ? "Pagamento de teste confirmado" : "Solicitação confirmada"}
            </h1>
            <p>O pagamento de {currency(charge!.amount / 100)} foi confirmado.</p>
            <p>
              {preview ? (
                "Este pagamento é apenas um teste e não contrata rastreamento nem está associado a um pedido."
              ) : (
                <>
                  O código de rastreio será enviado manualmente para <strong>{payer.email}</strong>{" "}
                  quando estiver disponível.
                </>
              )}
            </p>
            <Link to="/loja" search={trackingSearch} replace className="campaign-text-button">
              Voltar à loja
            </Link>
          </div>
        ) : (
          <>
            <header className="tracking-heading">
              <span className="tracking-icon">
                <PackageCheck size={26} aria-hidden="true" />
              </span>
              <div>
                <span className="tracking-eyebrow">
                  {preview ? "Teste de geração Pix" : orderLinked ? "Pedido pago" : "Rastreamento"}
                </span>
                <h1 id="tracking-title" ref={heading} tabIndex={-1}>
                  {charge
                    ? preview
                      ? "Pix de teste gerado"
                      : "Pague a consulta com Pix"
                    : "Consulta do pedido"}
                </h1>
              </div>
            </header>
            {!charge ? (
              <>
                <p className="tracking-description">
                  {preview
                    ? "Teste a emissão do QR Code e do Pix copia e cola. Será criada uma cobrança real de R$29,30, identificada como TESTE. Não é necessário pagar para conferir a geração."
                    : "Se quiser consultar seu pedido, pague a taxa de consulta."}
                </p>
                <div className="tracking-price">
                  <div>
                    <span>Taxa de consulta</span>
                    <small>Pagamento único via Pix</small>
                  </div>
                  <strong>{currency(29.3)}</strong>
                </div>
                <form onSubmit={(event) => void generatePix(event)} noValidate>
                  <TrackingPayerFields
                    payer={payer}
                    errors={errors}
                    disabled={loading}
                    onPayerChange={(field, value) => {
                      setPayer((previous) => ({ ...previous, [field]: value }));
                      setErrors((previous) => ({ ...previous, [field]: "" }));
                    }}
                  />
                  {paymentError && (
                    <p className="checkout-field-error tracking-payment-error" role="alert">
                      {paymentError}
                    </p>
                  )}
                  <button className="campaign-button" type="submit" disabled={loading}>
                    {loading && (
                      <LoaderCircle className="checkout-spinner" size={18} aria-hidden="true" />
                    )}
                    {loading
                      ? "GERANDO PIX…"
                      : preview
                        ? "GERAR PIX DE TESTE — R$29,30"
                        : "GERAR PIX — R$29,30"}
                  </button>
                </form>
              </>
            ) : (
              <>
                <p className="tracking-description">
                  {preview ? "E-mail deste teste: " : "E-mail para envio do código: "}
                  <strong>{payer.email}</strong>
                </p>
                <PixPayment
                  key={charge.id}
                  charge={charge}
                  onApproved={(paid) => {
                    if (!preview) {
                      trackMetaServicePayment("Purchase", paid);
                      completeTrackingService(paid.id);
                    }
                    setApproved(true);
                  }}
                  onRetry={() => {
                    setCharge(null);
                    setPaymentError("");
                  }}
                />
              </>
            )}
          </>
        )}
      </section>
    </main>
  );
}
