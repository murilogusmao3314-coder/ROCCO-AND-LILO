import { createFileRoute } from "@tanstack/react-router";
import { CampaignQuiz } from "@/components/campaign-quiz";

export const Route = createFileRoute("/quiz")({
  head: () => ({ meta: [{ title: "Quiz Outubro Rosa | Um corre por todas" }] }),
  component: CampaignQuiz,
});
