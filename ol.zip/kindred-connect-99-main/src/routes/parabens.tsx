import { trackingSearch } from "@/lib/tracking";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { CampaignFrame } from "@/components/campaign-frame";

export const Route = createFileRoute("/parabens")({
  head: () => ({
    meta: [{ title: "Parabéns | Kit Corre Rosa" }],
    links: [{ rel: "preload", as: "image", href: "/campaign/parabens-titulo.webp" }],
  }),
  component: Congratulations,
});

function Congratulations() {
  const navigate = useNavigate();
  const router = useRouter();
  const sectionRef = useRef<HTMLElement>(null);
  const celebrationRef = useRef<HTMLDivElement>(null);
  const confettiRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<HTMLSpanElement>(null);
  const [seconds, setSeconds] = useState(5);

  useEffect(() => {
    void router.preloadRoute({ to: "/loja", search: trackingSearch }).catch(() => undefined);

    // Start after hydration. The fill, countdown and navigation share one clock.
    const startedAt = performance.now();
    let frame = 0;
    let redirect = 0;
    let previousSeconds = 5;
    const tick = () => {
      const elapsed = Math.max(0, performance.now() - startedAt);
      const progress = Math.min(elapsed / 5000, 1);
      if (fillRef.current) fillRef.current.style.transform = `scaleX(${progress})`;
      const remaining = Math.max(0, Math.ceil((5000 - elapsed) / 1000));
      if (remaining !== previousSeconds) {
        previousSeconds = remaining;
        setSeconds(remaining);
      }
      if (progress < 1) {
        frame = window.requestAnimationFrame(tick);
      } else {
        // Give the browser time to paint the completed bar and 0s before leaving.
        redirect = window.setTimeout(
          () => void navigate({ to: "/loja", search: trackingSearch, replace: true }),
          180,
        );
      }
    };
    frame = window.requestAnimationFrame(tick);
    return () => {
      window.cancelAnimationFrame(frame);
      window.clearTimeout(redirect);
    };
  }, [navigate, router]);

  useEffect(() => {
    if (!celebrationRef.current || !confettiRef.current) return;
    // Always celebrate on entry; reduce the travel rather than requiring a click.
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const shake = reducedMotion ? 1 : 6;
    const tilt = reducedMotion ? 0 : 0.4;
    const animations: Animation[] = [];
    const celebration = celebrationRef.current;
    // Native browser animations start on mount, rather than during server rendering.
    if (typeof celebration.animate !== "function") return;
    animations.push(
      celebration.animate(
        [
          {
            opacity: 0,
            transform: `translateY(${reducedMotion ? 4 : 16}px) scale(0.98)`,
            offset: 0,
          },
          { opacity: 1, transform: "translateX(0)", offset: 0.45 },
          { transform: `translateX(${-shake}px) rotate(${-tilt}deg)`, offset: 0.56 },
          { transform: `translateX(${shake}px) rotate(${tilt}deg)`, offset: 0.67 },
          { transform: `translateX(${(-shake * 2) / 3}px)`, offset: 0.78 },
          { transform: `translateX(${shake / 2}px)`, offset: 0.89 },
          { opacity: 1, transform: "translateX(0)", offset: 1 },
        ],
        { duration: 1000, easing: "ease-out" },
      ),
    );
    const distance = Math.max(sectionRef.current?.clientHeight ?? 0, window.innerHeight) + 40;
    Array.from(confettiRef.current.children).forEach((particle, index) => {
      const drift = (((index * 17) % 100) - 50) * (reducedMotion ? 0.2 : 1);
      const rotation = (index % 2 ? -1 : 1) * (reducedMotion ? 90 : 720);
      animations.push(
        particle.animate(
          [
            { opacity: 1, transform: "translate3d(0, -20px, 0) rotate(0deg)", offset: 0 },
            { opacity: 1, offset: 0.85 },
            {
              opacity: 0,
              transform: `translate3d(${drift}px, ${distance}px, 0) rotate(${rotation}deg)`,
              offset: 1,
            },
          ],
          {
            duration: 2900 + (index % 5) * 250,
            delay: (index % 8) * 75,
            easing: "ease-in",
            fill: "both",
          },
        ),
      );
    });
    return () => animations.forEach((animation) => animation.cancel());
  }, []);

  return (
    <CampaignFrame compact footer={<></>}>
      <section ref={sectionRef} className="campaign-congratulations">
        <div ref={confettiRef} className="campaign-confetti" aria-hidden="true">
          {Array.from({ length: 48 }, (_, index) => (
            <i
              key={index}
              style={
                {
                  "--confetti-left": ((index * 37) % 100) + "%",
                  "--confetti-color": ["#e81461", "#ff80b0", "#dba735", "#229baf"][index % 4],
                } as CSSProperties
              }
            />
          ))}
        </div>
        <div ref={celebrationRef} className="campaign-celebration">
          <h1>
            <img
              src="/campaign/parabens-titulo.webp"
              alt="Parabéns!"
              width="1000"
              height="563"
              fetchPriority="high"
            />
          </h1>
          <h2>Você concluiu o desafio e desbloqueou o desconto no Kit Corre Rosa!</h2>
          <div className="campaign-redirect">
            <p role="status">
              <span>
                <Sparkles size={16} aria-hidden="true" /> REDIRECIONANDO PARA A LOJA
              </span>
              <small aria-hidden="true">{seconds}s</small>
            </p>
            <div
              className="campaign-redirect-track"
              role="progressbar"
              aria-label="Redirecionamento para a loja"
              aria-valuemin={0}
              aria-valuemax={5}
              aria-valuenow={5 - seconds}
              aria-valuetext={
                seconds ? `Redirecionando em ${seconds} segundos` : "Carregamento concluído"
              }
            >
              <span ref={fillRef} />
            </div>
          </div>
        </div>
      </section>
    </CampaignFrame>
  );
}
