import { useEffect, useRef } from "react";
import { useRouter, useRouterState } from "@tanstack/react-router";
import { buildUrlWithTracking, debugTracking } from "@/lib/tracking";
import { trackMetaPageView, trackMetaViewContent } from "@/lib/meta-pixel";

export function CampaignTracking() {
  const router = useRouter();
  const href = useRouterState({ select: (state) => state.location.href });
  const previousPath = useRef<string | undefined>(undefined);
  useEffect(() => {
    const current = router.state.location;
    debugTracking(current.pathname);
    const destination = buildUrlWithTracking(current.href);
    if (destination !== current.href)
      void router.navigate({ href: destination, replace: true }).catch(() => {});
    if (previousPath.current === current.pathname) return;
    // The bootstrap already fires the initial PageView on every direct entry.
    if (previousPath.current !== undefined) trackMetaPageView();
    previousPath.current = current.pathname;
    if (current.pathname === "/loja") trackMetaViewContent();
  }, [href, router]);
  return null;
}
