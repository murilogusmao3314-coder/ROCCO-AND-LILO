import { trackingSearch } from "@/lib/tracking";
import { useEffect, useRef } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { getPixStatus } from "@/lib/pix.functions";
import { trackMetaOrderPayment, trackMetaServicePayment } from "@/lib/meta-pixel";
import {
  checkTrackingReturn,
  clearTrackingReturn,
  readTrackingReturn,
  type TrackingReturnDecision,
  type TrackingReturnRecord,
} from "@/lib/tracking-return";

export function TrackingReturn() {
  const router = useRouter();
  const getStatus = useServerFn(getPixStatus);
  const visit = useRef<{
    href: string;
    record: TrackingReturnRecord;
    result: Promise<TrackingReturnDecision>;
  } | null>(null);
  const started = useRef(false);

  useEffect(() => {
    if (!started.current) {
      started.current = true;
      const location = router.state.location;
      const record = readTrackingReturn();
      if (record && location.pathname !== "/rastreamento")
        visit.current = {
          href: location.href,
          record,
          result: checkTrackingReturn(record, async (id) => {
            const result = await getStatus({ data: { id } });
            if (result.status === "approved") {
              if (id === record.orderId && record.orderPurchase) {
                const purchase = record.orderPurchase;
                trackMetaOrderPayment(
                  "Purchase",
                  { id, amount: purchase.amount, tracking: purchase.tracking },
                  purchase.offers ?? {},
                  purchase.shipping ?? "free",
                );
              } else if (id === record.serviceId && record.servicePurchase) {
                const purchase = record.servicePurchase;
                trackMetaServicePayment("Purchase", {
                  id, amount: purchase.amount, tracking: purchase.tracking,
                });
              }
            }
            return result;
          }),
        };
    }
    const initial = visit.current;
    if (!initial) return;
    let active = true;
    void initial.result.then((decision) => {
      if (!active) return;
      const current = readTrackingReturn();
      if (
        current?.orderId !== initial.record.orderId ||
        current.serviceId !== initial.record.serviceId
      )
        return;
      if (decision === "completed" || decision === "failed") {
        clearTrackingReturn(initial.record);
      } else if (decision === "tracking" && router.state.location.href === initial.href) {
        void router
          .navigate({ to: "/rastreamento", search: trackingSearch, replace: true })
          .catch(() => {});
      }
    });
    return () => {
      active = false;
    };
  }, [getStatus, router]);

  return null;
}
