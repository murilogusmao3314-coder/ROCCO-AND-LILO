import { trackingSearch } from "@/lib/tracking";
import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useRouter } from "@tanstack/react-router";
import { ArrowLeft, Check, RotateCcw, X } from "lucide-react";
import { CampaignFrame } from "@/components/campaign-frame";
import { CampaignModal } from "@/components/campaign-modal";
import { questions } from "@/data/campaign";

const storageKey = "outubro-rosa-quiz-v1";
type Progress = { step: number; answers: (number | null)[]; failed: number[][] };
type Feedback = "correct" | "wrong" | null;
const initialProgress = (): Progress => ({
  step: 0,
  answers: questions.map(() => null),
  failed: questions.map(() => []),
});

function readProgress(): Progress {
  try {
    const raw: unknown = JSON.parse(sessionStorage.getItem(storageKey) || "null");
    if (typeof raw !== "object" || !raw) return initialProgress();
    const value = raw as Partial<Progress>;
    if (
      typeof value.step !== "number" ||
      !Number.isInteger(value.step) ||
      value.step < 0 ||
      value.step > questions.length ||
      !Array.isArray(value.answers) ||
      value.answers.length !== questions.length
    )
      return initialProgress();
    if (
      !value.answers.every(
        (answer, index) =>
          answer === null ||
          (Number.isInteger(answer) && answer >= 0 && answer < questions[index]!.options.length),
      )
    )
      return initialProgress();
    if (
      !questions
        .slice(0, value.step)
        .every((question, index) => value.answers![index] === question.correct)
    )
      return initialProgress();
    const failed =
      value.failed ??
      value.answers.map((answer, index) =>
        answer !== null && answer !== questions[index]!.correct ? [answer] : [],
      );
    if (
      !Array.isArray(failed) ||
      failed.length !== questions.length ||
      !failed.every(
        (attempts, index) =>
          Array.isArray(attempts) &&
          attempts.every(
            (answer) =>
              Number.isInteger(answer) &&
              answer >= 0 &&
              answer < questions[index]!.options.length &&
              answer !== questions[index]!.correct,
          ),
      )
    )
      return initialProgress();
    return { step: value.step, answers: value.answers, failed };
  } catch {
    return initialProgress();
  }
}

export function CampaignQuiz() {
  const navigate = useNavigate();
  const router = useRouter();
  useEffect(() => {
    void router.preloadRoute({ to: "/parabens" });
  }, [router]);
  const [progress, setProgress] = useState<Progress>(initialProgress);
  const [restored, setRestored] = useState(false);
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [feedbackExplanation, setFeedbackExplanation] = useState<string>(questions[0].explanation);
  const lastFeedback = useRef<Feedback>("correct");
  const heading = useRef<HTMLHeadingElement>(null);
  const closing = useRef(false);
  useEffect(() => {
    const next = questions[progress.step + 1];
    if (next) {
      const image = new Image();
      image.src = next.image;
    }
  }, [progress.step]);

  useEffect(() => {
    const saved = readProgress();
    setProgress(saved);
    setRestored(true);
    if (saved.step === questions.length) {
      void navigate({ to: "/parabens", search: trackingSearch, replace: true });
    } else if (saved.answers[saved.step] === questions[saved.step]!.correct) {
      setFeedbackExplanation(questions[saved.step]!.explanation);
      setFeedback("correct");
    }
  }, [navigate]);

  useEffect(() => {
    if (!restored) return;
    try {
      sessionStorage.setItem(storageKey, JSON.stringify(progress));
    } catch {
      /* Storage is optional. */
    }
  }, [progress, restored]);

  useEffect(() => {
    closing.current = false;
    if (restored) heading.current?.focus({ preventScroll: true });
  }, [progress.step, restored]);

  const closeFeedback = useCallback(() => {
    if (!feedback || closing.current) return;
    closing.current = true;
    setFeedback(null);
    if (feedback === "wrong") {
      closing.current = false;
      requestAnimationFrame(() => heading.current?.focus({ preventScroll: true }));
      return;
    }
    const next = progress.step + 1;
    setProgress((previous) => ({ ...previous, step: next }));
    if (next >= questions.length) void navigate({ to: "/parabens", search: trackingSearch });
  }, [feedback, progress.step, navigate]);

  useEffect(() => {
    if (!feedback) return;
    const timer = window.setTimeout(closeFeedback, 1700);
    return () => window.clearTimeout(timer);
  }, [feedback, progress.step, closeFeedback]);

  const restart = () => {
    setFeedback(null);
    setProgress(initialProgress());
    closing.current = false;
  };
  const question = questions[Math.min(progress.step, questions.length - 1)]!;
  const selected = progress.answers[progress.step] ?? null;
  const feedbackType = feedback ?? lastFeedback.current;
  const failed = progress.failed[Math.min(progress.step, questions.length - 1)]!;
  const choose = (answer: number) => {
    if (feedback || progress.step >= questions.length || failed.includes(answer)) return;
    closing.current = false;
    setProgress((previous) => ({
      ...previous,
      answers: previous.answers.map((value, index) => (index === previous.step ? answer : value)),
      failed: previous.failed.map((attempts, index) =>
        index === previous.step && answer !== question.correct ? [...attempts, answer] : attempts,
      ),
    }));
    lastFeedback.current = answer === question.correct ? "correct" : "wrong";
    setFeedbackExplanation(question.explanation);
    setFeedback(answer === question.correct ? "correct" : "wrong");
  };

  return (
    <CampaignFrame compact>
      <section className="campaign-quiz">
        <div className="campaign-quiz-meta">
          <p className="campaign-eyebrow">
            PERGUNTA {Math.min(progress.step + 1, questions.length)}{" "}
            <span>DE {questions.length}</span>
          </p>
          <button className="campaign-reset" onClick={restart} aria-label="Reiniciar quiz">
            <RotateCcw size={18} />
          </button>
        </div>
        <div
          className="campaign-progress"
          role="progressbar"
          aria-label="Perguntas concluídas"
          aria-valuemin={0}
          aria-valuemax={questions.length}
          aria-valuenow={progress.step}
        >
          <span style={{ width: (progress.step / questions.length) * 100 + "%" }} />
        </div>
        <div className="campaign-question" key={progress.step}>
          <img
            className="campaign-question-image"
            src={question.image}
            alt={question.alt}
            width="1000"
            height="750"
            fetchPriority="high"
          />
          <h1 className="campaign-question-title" ref={heading} tabIndex={-1}>
            {question.title}
          </h1>
          <div className="campaign-options" role="group" aria-label="Escolha uma resposta">
            {question.options.map((option, index) => (
              <button
                key={option}
                className={
                  "campaign-option" +
                  (failed.includes(index)
                    ? " is-incorrect"
                    : selected === index && feedback === "correct"
                      ? " is-correct"
                      : "")
                }
                onClick={() => choose(index)}
                disabled={feedback !== null || failed.includes(index)}
                aria-pressed={selected === index}
              >
                <span className="campaign-option-text">{option}</span>
                {failed.includes(index) ? (
                  <X size={20} aria-hidden="true" />
                ) : selected === index && feedback === "correct" ? (
                  <Check size={20} aria-hidden="true" />
                ) : null}
              </button>
            ))}
          </div>
        </div>
        {progress.step > 0 && (
          <button
            className="campaign-text-button"
            onClick={() => {
              setFeedback(null);
              setProgress((previous) => ({
                ...previous,
                step: previous.step - 1,
                answers: previous.answers.map((value, index) =>
                  index === previous.step - 1 ? null : value,
                ),
              }));
            }}
          >
            <ArrowLeft size={16} aria-hidden="true" /> Pergunta anterior
          </button>
        )}
      </section>
      <CampaignModal
        open={feedback !== null}
        onClose={closeFeedback}
        title={feedbackType === "wrong" ? "Ops, tente novamente!" : "Resposta correta!"}
        description={
          feedbackType === "wrong"
            ? "Não foi dessa vez. Escolha outra alternativa."
            : feedbackExplanation
        }
        className={"quiz-feedback-dialog " + (feedbackType === "wrong" ? "is-wrong" : "is-correct")}
      >
        <span className="quiz-feedback-icon" aria-hidden="true">
          {feedbackType === "wrong" ? (
            <X size={42} strokeWidth={3} />
          ) : (
            <Check size={42} strokeWidth={3} />
          )}
        </span>
        <button className="campaign-button" onClick={closeFeedback}>
          {feedbackType === "wrong" ? "TENTAR NOVAMENTE" : "CONTINUAR"}
        </button>
        <p className="quiz-feedback-caption">
          {feedbackType === "wrong" ? "Você pode tentar de novo." : "Avançando automaticamente…"}
        </p>
        {feedback === "correct" && <span className="quiz-feedback-timer" />}
      </CampaignModal>
    </CampaignFrame>
  );
}
