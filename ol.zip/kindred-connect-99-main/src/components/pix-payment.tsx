import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Check, Copy, LoaderCircle } from "lucide-react";
import { getPixStatus, type PixCharge } from "@/lib/pix.functions";
import { pixQrSource } from "@/lib/pix-qr";
import { currency } from "@/data/campaign";

export function PixPayment({
  charge,
  onRetry,
  onApproved,
}: {
  charge: PixCharge;
  onRetry: () => void;
  onApproved?: (charge: PixCharge) => void;
}) {
  const checkStatus = useServerFn(getPixStatus);
  const [status, setStatus] = useState("pending");
  const [qr, setQr] = useState({ code: "", source: "", error: false });
  const [copyStatus, setCopyStatus] = useState<"idle" | "copying" | "copied" | "error">("idle");
  const codeField = useRef<HTMLTextAreaElement>(null);
  const notifiedApproval = useRef<string | null>(null);
  useEffect(() => {
    if (status === "approved" && onApproved && notifiedApproval.current !== charge.id) {
      notifiedApproval.current = charge.id;
      onApproved(charge);
    }
  }, [status, charge, onApproved]);

  useEffect(() => {
    let active = true;
    void pixQrSource(charge.qrCode).then(
      (source) => {
        if (active) setQr({ code: charge.qrCode, source, error: false });
      },
      () => {
        if (active) setQr({ code: charge.qrCode, source: "", error: true });
      },
    );
    return () => {
      active = false;
    };
  }, [charge.qrCode]);

  useEffect(() => {
    if (status === "approved" || status === "failed") return;
    let active = true;
    let timer = 0;
    const poll = async () => {
      let finished = false;
      try {
        const result = await checkStatus({ data: { id: charge.id } });
        if (!active) return;
        setStatus(result.status);
        finished = result.status === "approved" || result.status === "failed";
      } catch {
        // A transient status error must not interrupt the available payment code.
      }
      if (active && !finished) timer = window.setTimeout(() => void poll(), 5000);
    };
    timer = window.setTimeout(() => void poll(), 5000);
    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [charge.id, checkStatus, status]);

  async function copyCode() {
    setCopyStatus("copying");
    try {
      if (!navigator.clipboard?.writeText) throw new Error("Cópia automática indisponível.");
      await navigator.clipboard.writeText(charge.qrCode);
      setCopyStatus("copied");
    } catch {
      setCopyStatus("error");
      codeField.current?.focus();
      codeField.current?.select();
    }
  }

  if (status === "approved")
    return (
      <div className="checkout-pix-confirmed" role="status">
        <Check size={28} aria-hidden="true" />
        <h2>Pagamento confirmado!</h2>
        <p>Seu pagamento Pix foi aprovado.</p>
      </div>
    );
  if (status === "failed")
    return (
      <div className="checkout-pix" role="alert">
        <h2>Este Pix expirou ou foi recusado</h2>
        <p>Gere um novo código para continuar com seu pedido.</p>
        <button type="button" className="campaign-button" onClick={onRetry}>
          GERAR NOVO PIX
        </button>
      </div>
    );

  const qrReady = qr.code === charge.qrCode && Boolean(qr.source);
  const qrError = qr.code === charge.qrCode && qr.error;
  return (
    <section className="checkout-pix" aria-label="Pagamento via Pix">
      <div className="checkout-pix-heading">
        <span>Valor a pagar</span>
        <strong>{currency(charge.amount / 100)}</strong>
        <p>Escaneie o QR Code ou use o Pix copia e cola.</p>
      </div>
      <div className="checkout-pix-qr" aria-busy={!qrReady && !qrError}>
        {qrReady ? (
          <img
            src={qr.source}
            alt="QR Code Pix"
            width="264"
            height="264"
            onError={() => setQr({ code: charge.qrCode, source: "", error: true })}
          />
        ) : qrError ? (
          <p role="status">Não foi possível exibir o QR Code. Use o código copia e cola abaixo.</p>
        ) : (
          <p role="status">
            <LoaderCircle className="checkout-spinner" size={24} aria-hidden="true" /> Preparando QR
            Code…
          </p>
        )}
      </div>
      <label className="checkout-pix-code">
        <span>Pix copia e cola</span>
        <textarea
          ref={codeField}
          readOnly
          value={charge.qrCode}
          rows={3}
          spellCheck={false}
          onFocus={(event) => event.currentTarget.select()}
        />
      </label>
      <button
        type="button"
        className="campaign-button"
        disabled={copyStatus === "copying"}
        onClick={() => void copyCode()}
      >
        {copyStatus === "copied" ? (
          <Check size={19} aria-hidden="true" />
        ) : (
          <Copy size={19} aria-hidden="true" />
        )}
        {copyStatus === "copying"
          ? "COPIANDO…"
          : copyStatus === "copied"
            ? "CÓDIGO COPIADO"
            : "COPIAR CÓDIGO PIX"}
      </button>
      <p className="checkout-pix-copy-feedback" role="status">
        {copyStatus === "error"
          ? "Selecione o código acima e copie manualmente para colar no aplicativo do banco."
          : copyStatus === "copied"
            ? "Código copiado. Agora cole no aplicativo do seu banco."
            : ""}
      </p>
      <p className="checkout-pix-pending" role="status">
        <LoaderCircle size={16} className="checkout-spinner" aria-hidden="true" /> Aguardando
        pagamento
      </p>
      <section className="checkout-pix-tutorial" aria-labelledby="pix-tutorial-title">
        <h2 id="pix-tutorial-title">Como pagar com o copia e cola</h2>
        <ol>
          <li>
            Toque em <strong>Copiar código Pix</strong> acima.
          </li>
          <li>
            Abra o aplicativo do seu banco e escolha <strong>Pix → Pix copia e cola</strong>.
          </li>
          <li>Cole o código, confira o valor e o destinatário e confirme o pagamento.</li>
          <li>Volte para esta página para acompanhar a confirmação.</li>
        </ol>
      </section>
    </section>
  );
}
