import { useEffect, useState } from "react";
import { Clock3 } from "lucide-react";
import { countdownDeadline, countdownLabel, countdownSeconds } from "@/lib/campaign-countdown";

export function CampaignCountdown() {
  const [seconds, setSeconds] = useState<number | null>(null);
  useEffect(() => {
    let deadline = countdownDeadline();
    const update = () => {
      if (Date.now() >= deadline) deadline = countdownDeadline();
      setSeconds(countdownSeconds(deadline));
    };
    update();
    const timer = window.setInterval(update, 1000);
    document.addEventListener("visibilitychange", update);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", update);
    };
  }, []);
  return (
    <div className={"campaign-countdown" + (seconds === 0 ? " is-expired" : "")}>
      <Clock3 size={14} aria-hidden="true" />
      <span>{seconds === 0 ? "TEMPO ENCERRADO" : "KIT CORRE ROSA · TEMPO RESTANTE"}</span>
      <strong role="timer" aria-label="Tempo restante" aria-live="off" aria-busy={seconds === null}>
        {seconds === null ? "--:--" : countdownLabel(seconds)}
      </strong>
    </div>
  );
}
