import type { ReactNode } from "react";
import { campaignImages } from "@/data/campaign";

export function CampaignFrame({
  children,
  compact = false,
  shop = false,
  footer,
  banner,
}: {
  children: ReactNode;
  compact?: boolean;
  shop?: boolean;
  footer?: ReactNode;
  banner?: ReactNode;
}) {
  return (
    <div
      className={`campaign-shell${compact ? " campaign-shell--compact" : ""}${shop ? " campaign-shell--shop" : ""}`}
    >
      <a className="campaign-skip" href="#conteudo">
        Pular para o conteúdo
      </a>
      {banner}
      <header className="campaign-header">
        <img src={campaignImages.logo} alt="Olympikus" width="120" height="60" />
      </header>
      <main id="conteudo" className="campaign-main">
        {children}
      </main>
      {footer ?? <footer className="campaign-footer">© 2026 Olympikus. Um corre por todas.</footer>}
    </div>
  );
}
