import { useEffect, useRef, useState } from "react";
import { CampaignModal } from "@/components/campaign-modal";
import { clothingSizes, shoeSizes } from "@/data/campaign";
import { selectionStorageKey, validSelection, type KitSelection } from "@/lib/checkout";

export function KitSizePicker({
  open,
  onClose,
  onComplete,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onComplete: (value: KitSelection) => void;
  initial?: KitSelection | null;
}) {
  const [selection, setSelection] = useState<KitSelection>(
    initial ?? { shoe: "", shirt: "", shorts: "" },
  );
  const wasOpen = useRef(false);
  useEffect(() => {
    if (open && !wasOpen.current) setSelection(initial ?? { shoe: "", shirt: "", shorts: "" });
    wasOpen.current = open;
  }, [open, initial]);
  return (
    <CampaignModal
      open={open}
      onClose={onClose}
      title="ESCOLHA OS TAMANHOS"
      description="Selecione o tamanho de cada peça do seu kit."
      className="kit-size-dialog"
    >
      {(
        [
          { field: "shoe", label: "TAMANHO DO TÊNIS", sizes: shoeSizes },
          { field: "shirt", label: "TAMANHO DA REGATA", sizes: clothingSizes },
          { field: "shorts", label: "TAMANHO DO SHORTS", sizes: clothingSizes },
        ] as const
      ).map((group) => (
        <fieldset className="kit-size-group" key={group.field}>
          <legend>{group.label}</legend>
          <div className="kit-size-options">
            {group.sizes.map((size) => (
              <button
                key={size}
                type="button"
                aria-label={group.label + " " + size}
                aria-pressed={selection[group.field] === size}
                onClick={() => setSelection((previous) => ({ ...previous, [group.field]: size }))}
              >
                {size}
              </button>
            ))}
          </div>
        </fieldset>
      ))}
      <button
        className="campaign-button"
        disabled={!validSelection(selection)}
        onClick={() => {
          try {
            sessionStorage.setItem(selectionStorageKey, JSON.stringify(selection));
          } catch {
            /* Checkout receives the selection in memory too. */
          }
          onComplete(selection);
        }}
      >
        CONTINUAR
      </button>
    </CampaignModal>
  );
}

export function SizeGuide({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <CampaignModal
      open={open}
      onClose={onClose}
      title="TABELA DE MEDIDAS"
      description="Medidas em centímetros. Confira antes de escolher."
      className="kit-size-dialog"
    >
      <section className="size-guide">
        <h3>CAMISETA / REGATA</h3>
        <table>
          <thead>
            <tr>
              <th>Tam.</th>
              <th>Busto</th>
              <th>Compr.</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["P", "82–86", "58–60"],
              ["M", "88–92", "60–62"],
              ["G", "94–98", "62–64"],
            ].map((row) => (
              <tr key={row[0]}>
                {row.map((cell, index) =>
                  index === 0 ? (
                    <th key={index} scope="row">
                      {cell}
                    </th>
                  ) : (
                    <td key={index}>{cell}</td>
                  ),
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      <section className="size-guide">
        <h3>SHORTS</h3>
        <table>
          <thead>
            <tr>
              <th>Tam.</th>
              <th>Cintura</th>
              <th>Quadril</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["P", "66–70", "90–94"],
              ["M", "72–76", "96–100"],
              ["G", "78–82", "102–106"],
            ].map((row) => (
              <tr key={row[0]}>
                {row.map((cell, index) =>
                  index === 0 ? (
                    <th key={index} scope="row">
                      {cell}
                    </th>
                  ) : (
                    <td key={index}>{cell}</td>
                  ),
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      <section className="size-guide">
        <h3>TÊNIS</h3>
        <table>
          <thead>
            <tr>
              <th>BR</th>
              <th>CM</th>
              <th>US</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["34", "22,0", "4,5"],
              ["35", "22,5", "5"],
              ["36", "23,0", "5,5"],
              ["37", "23,5", "6"],
              ["38", "24,0", "6,5"],
              ["39", "24,5", "7"],
              ["40", "25,0", "7,5"],
            ].map((row) => (
              <tr key={row[0]}>
                {row.map((cell, index) =>
                  index === 0 ? (
                    <th key={index} scope="row">
                      {cell}
                    </th>
                  ) : (
                    <td key={index}>{cell}</td>
                  ),
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </CampaignModal>
  );
}
