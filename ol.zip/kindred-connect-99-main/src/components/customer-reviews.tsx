import review1 from "@/assets/review-cliente-1.webp.asset.json";
import review2 from "@/assets/review-cliente-2.webp.asset.json";
import review3 from "@/assets/review-cliente-3.webp.asset.json";

// CDN URLs are relative ("/__l5e/..."), which only resolves on Lovable hosting.
// Prefix the published origin so the images also load on external deploys (e.g. Netlify).
const CDN_ORIGIN = "https://olympikusoutubrorosa.lovable.app";
const cdnUrl = (path: string) => (path.startsWith("/") ? CDN_ORIGIN + path : path);

const reviews = [
  {
    text: "Confesso que fiquei com medo do tamanho, mas serviu certinho. O short não fica apertando e a blusa ficou bem confortável. O tênis também me surpreendeu, achei bem macio. Gostei bastante da compra.",
    image: cdnUrl(review1.url),
    alt: "Cliente sorrindo com o kit Corre Rosa e a caixa do tênis na rua",
  },
  {
    text: "Pra falar a verdade eu achei que podia ser golpe e comprei meio insegura kkk, mas chegou tudo certinho. Veio bem embalado, o conjunto é lindo e o tênis super confortável. No fim valeu muito a pena.",
    image: cdnUrl(review2.url),
    alt: "Cliente ao lado da caixa do tênis e do kit Corre Rosa embalado",
  },
  {
    text: "A Olympikus caprichou demais nessa promoção kkk. Achei que pelo valor ia vir algo mais simples, mas o conjunto é lindo e o tênis muito confortável. Valeu muito a pena.",
    image: cdnUrl(review3.url),
    alt: "Cliente no espelho usando o look rosa com o tênis do kit",
  },
];

function ReviewCards({ hidden }: { hidden?: boolean }) {
  return (
    <div className="store-reviews-group" aria-hidden={hidden ? true : undefined}>
      {reviews.map((review) => (
        <figure className="store-reviews-card" key={review.image}>
          <blockquote>{review.text}</blockquote>
          <img src={review.image} alt={hidden ? "" : review.alt} width="240" height="300" loading="lazy" decoding="async" />
        </figure>
      ))}
    </div>
  );
}

export function CustomerReviews() {
  return (
    <section className="store-reviews" aria-label="Avaliações dos nossos clientes">
      <h2>AVALIAÇÕES DOS NOSSOS CLIENTES</h2>
      <div className="store-reviews-viewport">
        <div className="store-reviews-track">
          <ReviewCards />
          <ReviewCards hidden />
        </div>
        <span className="store-reviews-edge is-left" aria-hidden="true" />
        <span className="store-reviews-edge is-right" aria-hidden="true" />
      </div>
    </section>
  );
}
