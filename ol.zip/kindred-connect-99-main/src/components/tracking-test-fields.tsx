import { formatCpf, formatPhone, type PersonalDetails } from "@/lib/checkout";

export type TrackingPayer = PersonalDetails;

export function TrackingPayerFields({
  payer,
  errors,
  disabled,
  onPayerChange,
}: {
  payer: TrackingPayer;
  errors: Record<string, string>;
  disabled: boolean;
  onPayerChange: (field: keyof TrackingPayer, value: string) => void;
}) {
  const fields = [
    {
      key: "name",
      label: "Nome completo",
      autoComplete: "name",
      maxLength: 120,
      placeholder: "Seu nome e sobrenome",
    },
    { key: "cpf", label: "CPF", autoComplete: "off", maxLength: 14, placeholder: "000.000.000-00" },
    {
      key: "phone",
      label: "Celular",
      autoComplete: "tel",
      maxLength: 16,
      placeholder: "(00) 00000-0000",
    },
    {
      key: "email",
      label: "E-mail para receber o código",
      autoComplete: "email",
      maxLength: 160,
      placeholder: "voce@exemplo.com",
    },
  ] as const;
  return (
    <fieldset className="tracking-payer-fields" disabled={disabled}>
      <legend>Seus dados</legend>
      {fields.map(({ key, label, autoComplete, maxLength, placeholder }) => (
        <div
          key={key}
          className={
            key === "name" || key === "email"
              ? "tracking-field tracking-field--wide"
              : "tracking-field"
          }
        >
          <label className="checkout-field" htmlFor={"tracking-" + key}>
            <span>{label}</span>
            <input
              id={"tracking-" + key}
              type={key === "email" ? "email" : key === "phone" ? "tel" : "text"}
              autoComplete={autoComplete}
              maxLength={maxLength}
              inputMode={
                key === "cpf"
                  ? "numeric"
                  : key === "phone"
                    ? "tel"
                    : key === "email"
                      ? "email"
                      : "text"
              }
              spellCheck={key === "name" ? undefined : false}
              placeholder={placeholder}
              value={payer[key]}
              onChange={(event) => {
                const value = event.target.value;
                onPayerChange(
                  key,
                  key === "cpf" ? formatCpf(value) : key === "phone" ? formatPhone(value) : value,
                );
              }}
              aria-invalid={Boolean(errors[key])}
              aria-describedby={errors[key] ? "tracking-error-" + key : undefined}
              required
            />
          </label>
          {errors[key] && (
            <p id={"tracking-error-" + key} className="checkout-field-error">
              {errors[key]}
            </p>
          )}
        </div>
      ))}
    </fieldset>
  );
}
