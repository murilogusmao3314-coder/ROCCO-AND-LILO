import { trackingSearch } from "@/lib/tracking";
import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Plus, ShieldCheck } from "lucide-react";
import { officialCampaignUrl, preventionUrl } from "@/data/campaign";

export function StoreFooter({ onSizeGuide }: { onSizeGuide: () => void }) {
  return (
    <footer className="store-footer">
      <div className="store-social">
        <a
          href="https://www.facebook.com/Olympikus/"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Facebook da Olympikus"
        >
          <Facebook size={24} />
        </a>
        <a
          href="https://www.instagram.com/olympikus/"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Instagram da Olympikus"
        >
          <Instagram size={24} />
        </a>
      </div>
      <details>
        <summary>
          INSTITUCIONAL <Plus size={18} aria-hidden="true" />
        </summary>
        <div className="store-footer-links">
          <a href={officialCampaignUrl} target="_blank" rel="noopener noreferrer">
            Sobre a campanha Outubro Rosa
          </a>
          <a
            href="https://www.olympikus.com.br/politica-de-privacidade"
            target="_blank"
            rel="noopener noreferrer"
          >
            Privacidade no site da Olympikus
          </a>
        </div>
      </details>
      <details>
        <summary>
          AJUDA <Plus size={18} aria-hidden="true" />
        </summary>
        <div className="store-footer-links">
          <button onClick={onSizeGuide}>Tabela de medidas</button>
          <Link to="/checkout" search={trackingSearch} preload="intent">
            Revisar meu kit e entrega
          </Link>
        </div>
      </details>
      <details>
        <summary>
          CORRE JUNTO BRASIL <Plus size={18} aria-hidden="true" />
        </summary>
        <div className="store-footer-links">
          <a href={preventionUrl} target="_blank" rel="noopener noreferrer">
            Informações de prevenção — INCA
          </a>
          <Link
            to="/quiz"
            search={trackingSearch}
            onClick={() => {
              try {
                sessionStorage.removeItem("outubro-rosa-quiz-v1");
              } catch {
                /* Storage is optional. */
              }
            }}
          >
            Refazer o desafio
          </Link>
        </div>
      </details>
      <div className="store-payments">
        <h3>PAGAMENTO</h3>
        <div className="store-payment-logos">
          <span>VISA</span>
          <span className="store-amex">
            AMERICAN
            <br />
            EXPRESS
          </span>
          {["hipercard", "elo", "mastercard", "pix"].map((name) => (
            <img
              key={name}
              src={"/campaign/pay-" + name + "-white.webp"}
              alt={name}
              width="52"
              height="35"
              loading="lazy"
            />
          ))}
        </div>
        <p>Pagamento via Pix. Cartões indisponíveis neste checkout.</p>
      </div>
      <div className="store-footer-legal">
        <p>© 2026 Olympikus. Um corre por todas.</p>
        <p>
          Campanha Outubro Rosa. A informação institucional sobre a marca e a causa está disponível
          no site da Olympikus.
        </p>
        <div className="store-footer-note">
          <ShieldCheck size={20} aria-hidden="true" />
          <span>Revise os itens, tamanhos e endereço antes do pagamento.</span>
        </div>
      </div>
    </footer>
  );
}
