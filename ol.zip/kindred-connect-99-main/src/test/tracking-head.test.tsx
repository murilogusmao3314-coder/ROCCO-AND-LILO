import { renderToStaticMarkup } from "react-dom/server";
import type { ComponentType, ReactNode } from "react";
import { expect, it, vi } from "vitest";
import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "@/routeTree.gen";
import { Route } from "@/routes/__root";
import { metaPixelBootstrap, metaPixelId } from "@/lib/meta-pixel";

vi.mock("@tanstack/react-router", async (original) => ({
  ...(await original<typeof import("@tanstack/react-router")>()),
  HeadContent: () => null, Scripts: () => null,
}));

it("loads the new Meta pixel, keeps the UTM script after origin recovery and never loads the previous pixel", () => {
  const Shell = Reflect.get(Route.options, "shellComponent") as ComponentType<{children: ReactNode}>;
  const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
  for (const path of ["/", "/quiz", "/parabens", "/loja", "/checkout", "/rastreamento"]) {
    expect(router.matchRoutes(path).at(-1)?.fullPath).toBe(path);
    const html = renderToStaticMarkup(<Shell><main>{path}</main></Shell>);
    expect(html.indexOf('id="campaign-attribution-persistent"')).toBeLessThan(
      html.indexOf('id="meta-pixel-bootstrap"'),
    );
    expect(html.indexOf('id="meta-pixel-bootstrap"')).toBeLessThan(
      html.indexOf('id="utmify-utm-script"'),
    );
    expect(html).toContain("connect.facebook.net/en_US/fbevents.js");
    expect(html).toContain('src="https://cdn.utmify.com.br/scripts/utms/latest.js"');
    expect(html).toContain("noscript=1");
    expect(html).toContain(metaPixelId);
    expect(html).not.toContain("3547034528836798");
    expect(html).not.toContain("6ac258b27c754bfba67dd94c");
    expect(html).toContain('id="utmify-pixel-config"');
    expect(html).toContain('6ace976f8708e36bd87c56a5');
    expect(html).toContain('id="utmify-pixel-loader"');
    expect(html).toContain('src="https://cdn.utmify.com.br/scripts/pixel/pixel.js"');
    expect(html.indexOf('id="utmify-pixel-config"')).toBeLessThan(
      html.indexOf('id="utmify-pixel-loader"'),
    );
  }
  expect(metaPixelBootstrap).toContain("trackSingle");
});
