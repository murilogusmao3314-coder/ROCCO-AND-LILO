import { act, cleanup, fireEvent, render, screen, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { Route } from "@/routes/checkout";
import { checkoutTotals, validCpf, selectionStorageKey } from "@/lib/checkout";
import { createPixCharge, getPixStatus } from "@/lib/pix.functions";
import { takeTrackingAccess } from "@/lib/tracking-access";
import { readTrackingReturn, trackingReturnKey } from "@/lib/tracking-return";

vi.mock("@/lib/pix.functions", () => ({
  createPixCharge: vi.fn(),
  getPixStatus: vi.fn(),
}));
vi.mock("@tanstack/react-start", () => ({ useServerFn: (fn: unknown) => fn }));
const { navigate } = vi.hoisted(() => ({ navigate: vi.fn() }));

vi.mock("@tanstack/react-router", () => ({
  useNavigate: () => navigate,
  createFileRoute: () => (options: { component: React.ComponentType }) => ({
    options,
  }),
  Link: ({
    to,
    children,
    search: _search,
    ...props
  }: {
    to: string;
    children: React.ReactNode;
    search?: unknown;
  }) => (
    <a href={to} {...props}>
      {children}
    </a>
  ),
}));

beforeEach(() => {
  vi.useFakeTimers();
  navigate.mockReset();
  vi.mocked(createPixCharge).mockReset();
  vi.mocked(getPixStatus).mockReset().mockResolvedValue({ status: "pending" });
  sessionStorage.clear();
  localStorage.removeItem(trackingReturnKey);
  takeTrackingAccess();
  sessionStorage.setItem(
    selectionStorageKey,
    JSON.stringify({ shoe: "36", shirt: "M", shorts: "P" }),
  );
  vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("offline")));
});
afterEach(() => {
  cleanup();
  takeTrackingAccess();
  localStorage.clear();
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

function finishTransition() {
  act(() => vi.advanceTimersByTime(180));
}
function continueCheckout() {
  fireEvent.click(screen.getByRole("button", { name: "CONTINUAR" }));
  finishTransition();
}
function fillPersonalDetails() {
  for (const [label, value] of Object.entries({
    "NOME COMPLETO": "Pessoa Teste",
    TELEFONE: "11987654321",
    "E-MAIL": "teste@example.com",
    CPF: "52998224725",
  }))
    fireEvent.change(screen.getByLabelText(label), { target: { value } });
}
function fillAddress() {
  for (const [label, value] of Object.entries({
    CEP: "01001000",
    "RUA / AVENIDA": "Rua de Teste",
    NÚMERO: "10",
    BAIRRO: "Centro",
    CIDADE: "São Paulo",
    UF: "SP",
  }))
    fireEvent.change(screen.getByLabelText(label), { target: { value } });
}

describe("Checkout", () => {
  it("reports InitiateCheckout on direct checkout mount, before any Pix is created", () => {
    const fbq = vi.fn();
    vi.stubGlobal("fbq", fbq);
    const Component = Route.options.component as React.ComponentType;
    const page = render(<Component />);
    expect(fbq).toHaveBeenCalledExactlyOnceWith(
      "trackSingle", "1418898839713148", "InitiateCheckout",
      expect.objectContaining({ value: 97.9, currency: "BRL" }),
    );
    expect(createPixCharge).not.toHaveBeenCalled();
    page.rerender(<Component />);
    expect(fbq).toHaveBeenCalledOnce();
  });

  it("retries the checkout IC when the Meta SDK is initialized after hydration", () => {
    const Component = Route.options.component as React.ComponentType;
    const page = render(<Component />);
    const fbq = vi.fn();
    vi.stubGlobal("fbq", fbq);
    act(() => vi.advanceTimersByTime(500));
    expect(fbq).toHaveBeenCalledExactlyOnceWith(
      "trackSingle", "1418898839713148", "InitiateCheckout",
      expect.objectContaining({ value: 97.9, currency: "BRL" }),
    );
    page.rerender(<Component />);
    act(() => vi.advanceTimersByTime(2500));
    expect(fbq).toHaveBeenCalledOnce();
  });

  it("continues to tracking after approval even when the optional order handoff is unavailable", async () => {
    vi.mocked(createPixCharge).mockResolvedValue({
      id: "ORDER-WITHOUT-HANDOFF",
      qrCode: "000201TEST-PIX-PAYLOAD",
      qrImage: "",
      amount: 9790,
      expiresAt: "",
    });
    const Component = Route.options.component as React.ComponentType;
    render(<Component />);
    fillPersonalDetails();
    continueCheckout();
    fillAddress();
    continueCheckout();
    continueCheckout();
    await act(async () => fireEvent.click(screen.getByRole("button", { name: "GERAR PIX" })));
    expect(navigate).not.toHaveBeenCalled();
    expect(readTrackingReturn()).toMatchObject({ orderId: "ORDER-WITHOUT-HANDOFF" });
    vi.mocked(getPixStatus).mockResolvedValue({ status: "approved" });
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5000);
    });
    expect(navigate).toHaveBeenCalledExactlyOnceWith({
      to: "/rastreamento",
      search: expect.any(Function),
      replace: true,
    });
    expect(takeTrackingAccess()).toBeNull();
    expect(readTrackingReturn()).toMatchObject({ orderId: "ORDER-WITHOUT-HANDOFF" });
  });
  it("opens tracking on live approval and saves the order for the separate return handler", async () => {
    vi.mocked(createPixCharge).mockResolvedValue({
      id: "ORDER-WITH-TRACKING",
      qrCode: "000201TEST-PIX-PAYLOAD",
      qrImage: "",
      amount: 9790,
      expiresAt: "",
      trackingAccess: "protected-access-token",
    });
    const Component = Route.options.component as React.ComponentType;
    const page = render(<Component />);
    fillPersonalDetails();
    continueCheckout();
    fillAddress();
    continueCheckout();
    continueCheckout();
    await act(async () => fireEvent.click(screen.getByRole("button", { name: "GERAR PIX" })));
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5000);
    });
    expect(navigate).not.toHaveBeenCalled();
    expect(takeTrackingAccess()).toBeNull();
    vi.mocked(getPixStatus).mockResolvedValue({ status: "approved" });
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5000);
    });
    expect(navigate).toHaveBeenCalledExactlyOnceWith({
      to: "/rastreamento",
      search: expect.any(Function),
      replace: true,
    });
    expect(takeTrackingAccess()).toBe("protected-access-token");
    expect(readTrackingReturn()).toMatchObject({ orderId: "ORDER-WITH-TRACKING" });
    await act(async () => {
      await vi.advanceTimersByTimeAsync(10000);
    });
    expect(navigate).toHaveBeenCalledOnce();
    page.unmount();
    navigate.mockClear();
    render(<Component />);
    await act(async () => {
      await vi.advanceTimersByTimeAsync(10000);
    });
    expect(navigate).not.toHaveBeenCalled();
  });
  it("emits AddPaymentInfo for created Pix and Purchase only after verified approval", async () => {
    const fbq = vi.fn();
    vi.stubGlobal("fbq", fbq);
    vi.mocked(createPixCharge).mockResolvedValue({
      id: "TEST-TRACKING-APPROVED",
      qrCode: "000201TEST-PIX-PAYLOAD",
      qrImage: "",
      amount: 9790,
      expiresAt: "",
    });
    const Component = Route.options.component as React.ComponentType;
    render(<Component />);
    fillPersonalDetails();
    continueCheckout();
    fillAddress();
    continueCheckout();
    continueCheckout();
    await act(async () => fireEvent.click(screen.getByRole("button", { name: "GERAR PIX" })));
    expect(readTrackingReturn()).toMatchObject({
      orderId: "TEST-TRACKING-APPROVED",
      orderPurchase: { amount: 9790 },
    });
    expect(fbq).toHaveBeenNthCalledWith(
      1, "trackSingle", "1418898839713148", "InitiateCheckout",
      expect.objectContaining({ value: 97.9, currency: "BRL" }),
    );
    expect(fbq).toHaveBeenNthCalledWith(
      2, "trackSingle", "1418898839713148", "AddPaymentInfo",
      expect.objectContaining({ value: 97.9, currency: "BRL" }),
      { eventID: "corre-rosa:AddPaymentInfo:TEST-TRACKING-APPROVED" },
    );
    vi.mocked(getPixStatus).mockResolvedValue({ status: "approved" });
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5000);
    });
    expect(navigate).toHaveBeenCalledExactlyOnceWith({
      to: "/rastreamento",
      search: expect.any(Function),
      replace: true,
    });
    expect(fbq).toHaveBeenLastCalledWith(
      "trackSingle", "1418898839713148", "Purchase",
      expect.objectContaining({ value: 97.9, currency: "BRL" }),
      { eventID: "corre-rosa:Purchase:TEST-TRACKING-APPROVED" },
    );
    expect(fbq).toHaveBeenCalledTimes(3);
  });
  it("shows only Pix payment content after generation and restores editing only when retrying", async () => {
    window.history.replaceState(
      null,
      "",
      "/checkout?utm_source=FB&utm_campaign=Nome%7C123456789012345678&utm_content=001",
    );
    vi.mocked(createPixCharge).mockResolvedValue({
      id: "test-charge",
      qrCode: "000201TEST-PIX-PAYLOAD",
      qrImage: "",
      amount: 9790,
      expiresAt: "",
    });
    const Component = Route.options.component as React.ComponentType;
    render(<Component />);
    fillPersonalDetails();
    continueCheckout();
    fillAddress();
    continueCheckout();
    continueCheckout();
    expect(screen.getByRole("region", { name: "Dados e entrega" })).toBeInTheDocument();
    await act(async () => fireEvent.click(screen.getByRole("button", { name: "GERAR PIX" })));
    await act(async () => {
      await vi.dynamicImportSettled();
    });
    expect(createPixCharge).toHaveBeenCalledOnce();
    expect(createPixCharge).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          tracking: expect.objectContaining({
            utm_source: "FB",
            utm_campaign: "Nome|123456789012345678",
            utm_content: "001",
          }),
        }),
      }),
    );
    expect(screen.getByRole("heading", { name: "PAGUE COM PIX" })).toHaveFocus();
    expect(screen.getByRole("img", { name: "QR Code Pix" })).toHaveAttribute(
      "src",
      expect.stringContaining("data:image/svg+xml"),
    );
    expect(screen.getByLabelText("Pix copia e cola")).toHaveValue("000201TEST-PIX-PAYLOAD");
    expect(
      screen.getByRole("heading", { name: "Como pagar com o copia e cola" }),
    ).toBeInTheDocument();
    expect(screen.queryByRole("region", { name: "Dados e entrega" })).not.toBeInTheDocument();
    expect(
      screen.queryByRole("button", {
        name: /Editar dados|Editar endereço|Voltar|Alterar tamanhos/,
      }),
    ).not.toBeInTheDocument();
    expect(screen.queryByText("Pessoa Teste")).not.toBeInTheDocument();
    expect(screen.queryByText("teste@example.com")).not.toBeInTheDocument();
    expect(screen.queryByText("Cartão de crédito")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "GERAR PIX" })).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Resumo do pedido/ })).toBeInTheDocument();
    expect(screen.getByRole("timer")).toBeInTheDocument();
    vi.mocked(getPixStatus).mockResolvedValue({ status: "failed" });
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5000);
    });
    fireEvent.click(screen.getByRole("button", { name: "GERAR NOVO PIX" }));
    expect(screen.getByRole("region", { name: "Dados e entrega" })).toHaveTextContent(
      "Pessoa Teste",
    );
    expect(screen.getByRole("button", { name: "GERAR PIX" })).toBeEnabled();
  });
  it("keeps the kit sizes when its animated popup is closed and reopened", () => {
    sessionStorage.clear();
    const Component = Route.options.component as React.ComponentType;
    render(<Component />);
    const dialog = screen.getByRole("dialog", { name: "ESCOLHA OS TAMANHOS" });
    expect(within(dialog).getByRole("button", { name: "CONTINUAR" })).toBeDisabled();
    for (const name of ["TAMANHO DO TÊNIS 38", "TAMANHO DA REGATA M", "TAMANHO DO SHORTS G"])
      fireEvent.click(within(dialog).getByRole("button", { name }));
    fireEvent.click(within(dialog).getByRole("button", { name: "CONTINUAR" }));
    fireEvent.click(screen.getByRole("button", { name: /Resumo do pedido/ }));
    fireEvent.click(screen.getByRole("button", { name: "Alterar tamanhos" }));
    const reopened = screen.getByRole("dialog", {
      name: "ESCOLHA OS TAMANHOS",
    });
    for (const name of ["TAMANHO DO TÊNIS 38", "TAMANHO DA REGATA M", "TAMANHO DO SHORTS G"])
      expect(within(reopened).getByRole("button", { name })).toHaveAttribute(
        "aria-pressed",
        "true",
      );
    fireEvent.click(within(reopened).getByRole("button", { name: "Fechar" }));
    expect(screen.getByText("Tênis 38 · Regata M · Shorts G")).toBeInTheDocument();
  });
  it("calculates optional extras and shipping without rounding errors", () => {
    expect(checkoutTotals({}, "free").total).toBe(97.9);
    expect(checkoutTotals({ socks: "34 a 38", visor: "" }, "express").total).toBe(156.15);
    expect(validCpf("111.111.111-11")).toBe(false);
    expect(validCpf("529.982.247-25")).toBe(true);
  });

  it("validates fields and preserves the draft across checkout steps", () => {
    const Component = Route.options.component as React.ComponentType;
    render(<Component />);
    fireEvent.click(screen.getByRole("button", { name: "CONTINUAR" }));
    expect(screen.getByText("Informe nome e sobrenome.")).toBeInTheDocument();
    fillPersonalDetails();
    continueCheckout();
    expect(screen.getByRole("heading", { name: "ENDEREÇO DE ENTREGA" })).toBeInTheDocument();
    const correios = screen.getByRole("radio", { name: /Correios/ }).closest("label")!;
    const correiosLogo = correios.querySelector("img")!;
    expect(correiosLogo).toHaveAttribute("src", "/campaign/correios.webp");
    expect(correiosLogo).toHaveAttribute("width", "48");
    fireEvent.error(correiosLogo);
    expect(correios.querySelector("img")).toBeNull();
    expect(correios.querySelector("svg")).toBeInTheDocument();
    expect(within(correios).getByRole("radio")).toBeEnabled();
    expect(correios).toHaveTextContent("Correios");
    fillAddress();
    continueCheckout();
    expect(screen.getByRole("heading", { name: "OFERTAS PARA SEU CORRE" })).toBeInTheDocument();
    expect(
      screen.getAllByRole("checkbox").every((checkbox) => !(checkbox as HTMLInputElement).checked),
    ).toBe(true);
    continueCheckout();
    expect(screen.getByRole("heading", { name: "PAGAMENTO" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "GERAR PIX" })).toBeEnabled();
    fireEvent.click(screen.getByRole("button", { name: "Editar dados" }));
    finishTransition();
    expect(screen.getByLabelText("NOME COMPLETO")).toHaveValue("Pessoa Teste");
    expect(sessionStorage.getItem("customer-cpf")).toBeNull();
  });

  it("opens sock size dialogs from either control and only adds confirmed sizes", () => {
    const Component = Route.options.component as React.ComponentType;
    render(<Component />);
    fillPersonalDetails();
    continueCheckout();
    fillAddress();
    continueCheckout();
    const checkboxes = screen.getAllByRole("checkbox");
    fireEvent.click(checkboxes[0]!);
    expect(screen.getByRole("dialog", { name: "ESCOLHA O TAMANHO DAS MEIAS" })).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Fechar" }));
    expect(checkboxes[0]).not.toBeChecked();
    fireEvent.click(
      screen.getByRole("button", {
        name: "Selecionar tamanho: Kit com 6 Meias Unissex",
      }),
    );
    fireEvent.click(
      within(screen.getByRole("dialog")).getByRole("button", {
        name: "34 a 38",
      }),
    );
    expect(checkboxes[0]).toBeChecked();
    expect(
      screen.getByRole("button", {
        name: "Selecionar tamanho: Kit com 6 Meias Unissex",
      }),
    ).toHaveTextContent("34 a 38");
    fireEvent.click(checkboxes[2]!);
    fireEvent.click(
      within(screen.getByRole("dialog")).getByRole("button", {
        name: "39 a 44",
      }),
    );
    expect(checkboxes[2]).toBeChecked();
    expect(screen.getByRole("button", { name: /Resumo do pedido/ })).toHaveTextContent(/137,70/);
    fireEvent.click(
      screen.getByRole("button", {
        name: "Selecionar tamanho: Kit com 6 Meias Unissex",
      }),
    );
    expect(
      within(screen.getByRole("dialog")).getByRole("button", {
        name: "34 a 38",
      }),
    ).toHaveAttribute("aria-pressed", "true");
    fireEvent.click(
      within(screen.getByRole("dialog")).getByRole("button", {
        name: "39 a 44",
      }),
    );
    fireEvent.click(checkboxes[0]!);
    expect(checkboxes[0]).not.toBeChecked();
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Resumo do pedido/ })).toHaveTextContent(/117,80/);
    continueCheckout();
    fireEvent.click(screen.getByRole("button", { name: "Voltar" }));
    finishTransition();
    expect(
      screen.getByRole("button", {
        name: "Selecionar tamanho: Kit com 6 Meias Coloridas",
      }),
    ).toHaveTextContent("39 a 44");
  });

  it("keeps one top summary collapsed on arrival at every stage through payment", () => {
    const Component = Route.options.component as React.ComponentType;
    render(<Component />);
    const toggle = screen.getByRole("button", { name: /Resumo do pedido/ });
    const expectCollapsed = () => {
      expect(toggle).toHaveAttribute("aria-expanded", "false");
      expect(screen.queryByRole("region", { name: "Resumo do pedido" })).not.toBeInTheDocument();
      expect(screen.getAllByRole("button", { name: /Resumo do pedido/ })).toHaveLength(1);
    };
    const openSummary = () => {
      fireEvent.click(toggle);
      expect(toggle).toHaveAttribute("aria-expanded", "true");
      return screen.getByRole("region", { name: "Resumo do pedido" });
    };
    expectCollapsed();
    const summary = openSummary();
    expect(within(summary).getByText("Qtd: 1")).toBeInTheDocument();
    expect(within(summary).getByText("Tênis 36 · Regata M · Shorts P")).toBeInTheDocument();
    expect(within(summary).getByText("Subtotal")).toBeInTheDocument();
    fireEvent.click(toggle);
    expectCollapsed();
    openSummary();
    fillPersonalDetails();
    continueCheckout();
    expectCollapsed();
    openSummary();
    fillAddress();
    continueCheckout();
    expectCollapsed();
    openSummary();
    continueCheckout();
    expectCollapsed();
    openSummary();
    const review = screen.getByRole("region", { name: "Dados e entrega" });
    expect(within(review).getByRole("button", { name: "Editar dados" })).toBeInTheDocument();
    expect(within(review).getByRole("button", { name: "Editar endereço" })).toBeInTheDocument();
    expect(within(review).queryByText(/Subtotal|Frete|Total|SEU KIT/)).not.toBeInTheDocument();
    expect(screen.getAllByText("Subtotal")).toHaveLength(1);
    expect(screen.getAllByText("Frete", { exact: true })).toHaveLength(1);
    expect(screen.getAllByText("Total", { exact: true })).toHaveLength(1);
  });

  it("updates the summary with shipping and extras and preserves data when editing", () => {
    const Component = Route.options.component as React.ComponentType;
    render(<Component />);
    fillPersonalDetails();
    continueCheckout();
    fillAddress();
    fireEvent.click(screen.getByRole("radio", { name: /Correios/ }));
    continueCheckout();
    const toggle = screen.getByRole("button", { name: /Resumo do pedido/ });
    expect(toggle).toHaveTextContent(/106,35/);
    fireEvent.click(toggle);
    const summary = screen.getByRole("region", { name: "Resumo do pedido" });
    expect(within(summary).getByText(/8,45/)).toBeInTheDocument();
    fireEvent.click(screen.getAllByRole("checkbox")[1]!);
    expect(toggle).toHaveTextContent(/136,25/);
    expect(within(summary).getByText("Viseira Olympikus Run")).toBeInTheDocument();
    fireEvent.click(screen.getAllByRole("checkbox")[1]!);
    expect(toggle).toHaveTextContent(/106,35/);
    expect(within(summary).queryByText("Viseira Olympikus Run")).not.toBeInTheDocument();
    continueCheckout();
    fireEvent.click(screen.getByRole("button", { name: "Editar endereço" }));
    finishTransition();
    expect(screen.getByLabelText("RUA / AVENIDA")).toHaveValue("Rua de Teste");
    expect(screen.getByRole("radio", { name: /Correios/ })).toBeChecked();
    continueCheckout();
    continueCheckout();
    fireEvent.click(screen.getByRole("button", { name: "Editar dados" }));
    finishTransition();
    expect(screen.getByLabelText("NOME COMPLETO")).toHaveValue("Pessoa Teste");
    expect(screen.getByLabelText("TELEFONE")).toHaveValue("(11) 98765-4321");
    expect(screen.getByLabelText("CPF")).toHaveValue("529.982.247-25");
    expect(toggle).toHaveTextContent(/106,35/);
  });
});
