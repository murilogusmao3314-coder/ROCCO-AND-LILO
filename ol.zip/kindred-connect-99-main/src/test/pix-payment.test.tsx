import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { PixPayment } from "@/components/pix-payment";
import * as qr from "@/lib/pix-qr";
import type { PixCharge } from "@/lib/pix.functions";

const { checkStatus } = vi.hoisted(() => ({ checkStatus: vi.fn() }));
vi.mock("@/lib/pix.functions", () => ({ getPixStatus: checkStatus }));
vi.mock("@tanstack/react-start", () => ({ useServerFn: (fn: unknown) => fn }));
const charge: PixCharge = {
  id: "test-charge",
  qrCode: "000201TEST-PIX-PAYLOAD",
  qrImage: "",
  amount: 9790,
  expiresAt: "",
};
const originalClipboard = Object.getOwnPropertyDescriptor(navigator, "clipboard");
const writeText = vi.fn();
beforeEach(() => {
  checkStatus.mockReset().mockResolvedValue({ status: "pending" });
  writeText.mockReset().mockResolvedValue(undefined);
  Object.defineProperty(navigator, "clipboard", { configurable: true, value: { writeText } });
});
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.useRealTimers();
  if (originalClipboard) Object.defineProperty(navigator, "clipboard", originalClipboard);
  else Reflect.deleteProperty(navigator, "clipboard");
});

it.each(["", "unusable-base64", "https://invalid.example/qr.png"])(
  "generates a local QR from the Pix payload with gateway image %s",
  async (qrImage) => {
    render(<PixPayment charge={{ ...charge, qrImage }} onRetry={vi.fn()} />);
    const image = await screen.findByRole("img", { name: "QR Code Pix" });
    const source = image.getAttribute("src")!;
    expect(source).toMatch(/^data:image\/svg\+xml;charset=utf-8,/);
    expect(decodeURIComponent(source.split(",")[1]!)).toContain("<path");
    expect(screen.getByLabelText("Pix copia e cola")).toHaveValue(charge.qrCode);
    expect(
      screen.getByRole("heading", { name: "Como pagar com o copia e cola" }),
    ).toBeInTheDocument();
  },
);

it("confirms copying only after the clipboard succeeds", async () => {
  let finishCopy!: () => void;
  writeText.mockReturnValue(
    new Promise<void>((resolve) => {
      finishCopy = resolve;
    }),
  );
  render(<PixPayment charge={charge} onRetry={vi.fn()} />);
  fireEvent.click(screen.getByRole("button", { name: "COPIAR CÓDIGO PIX" }));
  expect(screen.getByRole("button", { name: "COPIANDO…" })).toBeDisabled();
  expect(writeText).toHaveBeenCalledExactlyOnceWith(charge.qrCode);
  await act(async () => finishCopy());
  expect(screen.getByRole("button", { name: "CÓDIGO COPIADO" })).toBeEnabled();
});

it("selects the full payload for manual copying when clipboard permission is denied", async () => {
  writeText.mockRejectedValue(new Error("permission denied"));
  render(<PixPayment charge={charge} onRetry={vi.fn()} />);
  fireEvent.click(screen.getByRole("button", { name: "COPIAR CÓDIGO PIX" }));
  await screen.findByText(/copie manualmente/);
  expect(screen.queryByRole("button", { name: "CÓDIGO COPIADO" })).not.toBeInTheDocument();
  const field = screen.getByLabelText("Pix copia e cola") as HTMLTextAreaElement;
  expect(field).toHaveFocus();
  expect(field.selectionStart).toBe(0);
  expect(field.selectionEnd).toBe(charge.qrCode.length);
});

it("retains copy-and-paste payment if QR encoding or image display fails", async () => {
  vi.spyOn(qr, "pixQrSource").mockRejectedValue(new Error("encoding failed"));
  render(<PixPayment charge={charge} onRetry={vi.fn()} />);
  await screen.findByText(/Não foi possível exibir o QR Code/);
  expect(screen.getByLabelText("Pix copia e cola")).toHaveValue(charge.qrCode);
  expect(screen.getByRole("button", { name: "COPIAR CÓDIGO PIX" })).toBeEnabled();
});

it("keeps one status request in flight, stops after approval and cancels pending work", async () => {
  vi.useFakeTimers();
  let finishStatus!: (result: { status: string }) => void;
  checkStatus.mockReturnValue(
    new Promise((resolve) => {
      finishStatus = resolve;
    }),
  );
  const onApproved = vi.fn();
  const page = render(<PixPayment charge={charge} onRetry={vi.fn()} onApproved={onApproved} />);
  expect(onApproved).not.toHaveBeenCalled();
  await act(async () => {
    await vi.advanceTimersByTimeAsync(15000);
  });
  expect(checkStatus).toHaveBeenCalledOnce();
  await act(async () => finishStatus({ status: "approved" }));
  expect(screen.getByText("Pagamento confirmado!")).toBeInTheDocument();
  expect(onApproved).toHaveBeenCalledExactlyOnceWith(charge);
  expect(screen.queryByLabelText("Pix copia e cola")).not.toBeInTheDocument();
  await act(async () => {
    await vi.advanceTimersByTimeAsync(10000);
  });
  expect(checkStatus).toHaveBeenCalledOnce();
  expect(onApproved).toHaveBeenCalledOnce();
  page.unmount();
  expect(vi.getTimerCount()).toBe(0);
});

it("does not poll after leaving the payment screen", async () => {
  vi.useFakeTimers();
  const page = render(<PixPayment charge={charge} onRetry={vi.fn()} />);
  page.unmount();
  await act(async () => {
    await vi.advanceTimersByTimeAsync(10000);
  });
  expect(checkStatus).not.toHaveBeenCalled();
  expect(vi.getTimerCount()).toBe(0);
});

it("keeps a readable fallback if the generated image cannot be displayed", async () => {
  render(<PixPayment charge={charge} onRetry={vi.fn()} />);
  fireEvent.error(await screen.findByRole("img", { name: "QR Code Pix" }));
  await waitFor(() =>
    expect(screen.getByText(/Não foi possível exibir o QR Code/)).toBeInTheDocument(),
  );
  expect(screen.getByLabelText("Pix copia e cola")).toHaveValue(charge.qrCode);
});
