import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { CampaignQuiz } from "@/components/campaign-quiz";
import { questions } from "@/data/campaign";

const { navigate, router } = vi.hoisted(() => ({
  navigate: vi.fn(),
  router: { preloadRoute: vi.fn().mockResolvedValue(undefined) },
}));
vi.mock("@tanstack/react-router", () => ({
  Link: ({
    to,
    children,
    search: _search,
    ...props
  }: {
    to: string;
    children: React.ReactNode;
    search?: unknown;
  }) => (
    <a href={to} {...props}>
      {children}
    </a>
  ),
  useNavigate: () => navigate,
  useRouter: () => router,
}));
beforeEach(() => {
  vi.useFakeTimers();
  sessionStorage.clear();
  navigate.mockClear();
});
afterEach(() => {
  cleanup();
  vi.clearAllTimers();
  vi.useRealTimers();
});

describe("Quiz feedback and automatic progression", () => {
  it("renders immediately and allows another try after an error popup", () => {
    const view = render(<CampaignQuiz />);
    expect(screen.getByRole("heading", { name: questions[0].title })).toBeInTheDocument();
    expect(screen.queryByText(/Preparando o quiz/)).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /A competição entre atletas/ }));
    expect(screen.getByRole("dialog", { name: /Ops, tente novamente/ })).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "TENTAR NOVAMENTE" }));
    expect(screen.getByRole("heading", { name: questions[0].title })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /A conscientização/ })).toBeEnabled();
    expect(screen.getByRole("button", { name: /A competição entre atletas/ })).toBeDisabled();
    expect(screen.getByRole("button", { name: /A competição entre atletas/ })).toHaveClass(
      "is-incorrect",
    );
    view.unmount();
    render(<CampaignQuiz />);
    expect(screen.getByRole("button", { name: /A competição entre atletas/ })).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: /As tendências de moda/ }));
    act(() => vi.advanceTimersByTime(1700));
    expect(screen.getByRole("button", { name: /As tendências de moda/ })).toBeDisabled();
    expect(screen.getByRole("button", { name: /A competição entre atletas/ })).toHaveClass(
      "is-incorrect",
    );
  });

  it("advances automatically and goes to the congratulations page at the end", () => {
    render(<CampaignQuiz />);
    for (const question of questions) {
      fireEvent.click(
        screen.getByRole("button", { name: new RegExp(question.options[question.correct]) }),
      );
      expect(screen.getByRole("dialog")).toBeInTheDocument();
      expect(screen.getByText(question.explanation)).toBeInTheDocument();
      act(() => vi.advanceTimersByTime(1700));
    }
    expect(navigate).toHaveBeenCalledWith({ to: "/parabens", search: expect.any(Function) });
  });

  it("closing a success popup advances once and restores progress", () => {
    const view = render(<CampaignQuiz />);
    fireEvent.click(screen.getByRole("button", { name: /A conscientização/ }));
    fireEvent.click(screen.getByRole("button", { name: "Fechar" }));
    act(() => vi.advanceTimersByTime(1800));
    expect(screen.getByRole("heading", { name: questions[1].title })).toBeInTheDocument();
    view.unmount();
    render(<CampaignQuiz />);
    expect(screen.getByRole("heading", { name: questions[1].title })).toBeInTheDocument();
  });

  it("ignores malformed stored progress", () => {
    sessionStorage.setItem(
      "outubro-rosa-quiz-v1",
      JSON.stringify({ step: 5, answers: [0, 0, 0, 0, 0] }),
    );
    render(<CampaignQuiz />);
    expect(screen.getByRole("heading", { name: questions[0].title })).toBeInTheDocument();
    expect(navigate).not.toHaveBeenCalled();
  });
});
