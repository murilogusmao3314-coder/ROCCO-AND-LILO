import { webcrypto } from "node:crypto";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { createPixCharge } from "@/lib/pix.functions";
import {
  createTrackingPix,
  createTrackingPublicPix,
  getTrackingOffer,
} from "@/lib/tracking.functions";
import { openTrackingAccess, sealTrackingAccess } from "@/lib/tracking-access.server";

// Execute the real validators and handlers, with only the RPC transport stubbed.
vi.mock("@tanstack/react-start", () => ({
  createServerFn: () => ({
    inputValidator: (validate: (data: unknown) => unknown) => ({
      handler:
        (handle: (input: { data: unknown }) => unknown) =>
        async ({ data }: { data: unknown }) =>
          handle({ data: validate(data) }),
    }),
  }),
}));

const customer = {
  name: "Pessoa Teste",
  email: "original@example.com",
  phone: "11987654321",
  document: "52998224725",
};
const address = {
  street: "Rua Teste",
  number: "10",
  complement: "",
  neighborhood: "Centro",
  city: "São Paulo",
  state: "SP",
  zipcode: "01001000",
};
const gateway = vi.fn();
beforeEach(() => {
  vi.stubGlobal("crypto", webcrypto);
  vi.stubEnv("PINGUPAG_API_KEY", "test-key-not-a-live-credential");
  gateway.mockReset();
  vi.stubGlobal("fetch", gateway);
});
afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  vi.useRealTimers();
  vi.restoreAllMocks();
});
function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}
async function access() {
  return sealTrackingAccess({ chargeId: "ORDER-PAID-123", customer, address });
}

it("encrypts the order context and rejects altered or expired access", async () => {
  const token = await access();
  expect(token).not.toContain(customer.email);
  expect(token).not.toContain(customer.document);
  expect(await openTrackingAccess(token)).toMatchObject({ chargeId: "ORDER-PAID-123", customer });
  const pieces = token.split(".");
  const encrypted = pieces[2]!;
  pieces[2] = (encrypted[0] === "A" ? "B" : "A") + encrypted.slice(1);
  await expect(openTrackingAccess(pieces.join("."))).rejects.toThrow("Acesso");
  vi.useFakeTimers();
  vi.setSystemTime(Date.now() + 25 * 60 * 60 * 1000);
  await expect(openTrackingAccess(token)).rejects.toThrow("Acesso");
});

it("preserves sale metadata from checkout through the encrypted handoff and both UTMify order registrations", async () => {
  vi.stubEnv("UTMIFY_DIRECT_ENABLED", "true");
  vi.stubEnv("UTMIFY_QUEUE_ORIGIN", "https://queue.example");
  const tracking = {
    utm_source: "teste",
    utm_medium: "paid",
    utm_campaign: "teste|19000000000000000001",
    utm_content: "criativo1",
    utm_term: "feed",
    src: "ads",
    sck: "001",
    fbclid: "FB-CLICK",
    gclid: "GOOGLE-CLICK",
    ttclid: "TIKTOK-CLICK",
    xcod: "code",
  };
  const queued: Record<string, unknown>[] = [];
  let transaction = 0;
  gateway.mockImplementation(async (url, options) => {
    if (String(url).includes("/.netlify/functions/utmify-order")) {
      queued.push(JSON.parse(options.body).order);
      expect(options.headers["X-Order-Signature"]).toMatch(/^[a-f0-9]{64}$/);
      return json({}, 202);
    }
    if (String(url).includes("get_transaction")) return json({ status: "approved" });
    return json({
      transaction_id: ++transaction === 1 ? "META-MAIN" : "META-SERVICE",
      qr_code: "000201MOCK",
    });
  });
  const charge = await createPixCharge({
    data: {
      customer,
      address,
      offers: { socks: "34 a 38" },
      shipping: "free",
      tracking: { ...tracking, _fbp: "fb.1.100.123", _fbc: "fb.1.100.FB-CLICK", email: "never propagate" },
    },
  });
  expect(charge.tracking).toEqual(tracking);
  expect(charge.tracking).not.toHaveProperty("_fbp");
  expect(charge.tracking).not.toHaveProperty("_fbc");
  const token = charge.trackingAccess!;
  expect((await openTrackingAccess(token)).tracking).toEqual(tracking);
  const result = await createTrackingPix({
    data: { token, customer, tracking: { utm_campaign: "a later ad" } },
  });
  expect(result.ok).toBe(true);
  if (!result.ok) throw new Error(result.error);
  expect(result.charge.tracking).toEqual(tracking);
  expect(queued).toHaveLength(2);
  expect(queued[0]).toMatchObject({
    orderId: "META-MAIN",
    commission: { totalPriceInCents: 11780 },
    trackingParameters: {
      utm_source: "teste",
      utm_campaign: tracking.utm_campaign,
      utm_content: "criativo1",
      src: "ads",
      sck: "001",
    },
  });
  expect(queued[1]).toMatchObject({
    orderId: "META-SERVICE",
    commission: { totalPriceInCents: 2930 },
    products: [{ id: "rastreamento-opcional", priceInCents: 2930 }],
    trackingParameters: { utm_campaign: tracking.utm_campaign, utm_content: "criativo1" },
  });
  expect(queued[0]?.["trackingParameters"]).not.toHaveProperty("_fbp");
  expect(queued[0]?.["trackingParameters"]).not.toHaveProperty("email");
});

it("keeps preview test Pix out of UTMify sales even when direct sending is enabled", async () => {
  vi.stubEnv("UTMIFY_DIRECT_ENABLED", "true");
  gateway.mockResolvedValue(json({ transaction_id: "PREVIEW-ONLY", qr_code: "000201MOCK" }));
  const result = await createTrackingPublicPix({
    data: { confirmRealCharge: true, mode: "test", customer, tracking: { utm_campaign: "teste" } },
  });
  expect(result.ok).toBe(true);
  expect(gateway).toHaveBeenCalledOnce();
  expect(String(gateway.mock.calls[0]?.[0])).toContain("/transaction");
});

it.each(["pending", "failed", "anything-else"])(
  "refuses the offer and charge when the original payment is %s",
  async (status) => {
    const token = await access();
    gateway.mockImplementation(async () => json({ status }));
    await expect(getTrackingOffer({ data: { token } })).rejects.toThrow("ainda não foi confirmado");
    await expect(createTrackingPix({ data: { token, customer } })).rejects.toThrow(
      "ainda não foi confirmado",
    );
    expect(gateway).toHaveBeenCalledTimes(2);
    expect(
      gateway.mock.calls.every((call) =>
        String(call[0]).includes("get_transaction&id=ORDER-PAID-123"),
      ),
    ).toBe(true);
  },
);

it("verifies the paid parent again and charges exactly 2930 cents with the delivery email and order reference", async () => {
  const token = await access();
  gateway.mockResolvedValueOnce(json({ status: "approved" }));
  expect(await getTrackingOffer({ data: { token } })).toEqual({ customer });
  gateway
    .mockResolvedValueOnce(json({ status: "approved" }))
    .mockResolvedValueOnce(
      json({ transaction_id: "TRACKING-123", qr_code: "000201PIX", expires_at: "" }),
    );
  const result = await createTrackingPix({
    data: { token, customer: { ...customer, email: "  entrega@example.com  " } },
  });
  expect(result.ok).toBe(true);
  if (!result.ok) throw new Error(result.error);
  const charge = result.charge;
  const payload = JSON.parse(gateway.mock.calls[2]![1].body);
  expect(payload).toMatchObject({
    amount: 2930,
    customer: { ...customer, email: "entrega@example.com" },
    address,
  });
  expect(payload.description).toContain("ORDER-PAID-123");
  expect(payload.reference).toMatch(/^RASTREIO-/);
  expect(charge).toMatchObject({ id: "TRACKING-123", amount: 2930, qrCode: "000201PIX" });
  expect(charge.trackingAccess).toBeUndefined();
});

it("rejects invalid email, fabricated access and gateway errors without exposing a payment code", async () => {
  const token = await access();
  await expect(
    createTrackingPix({ data: { token, customer: { ...customer, email: "bad-email" } } }),
  ).rejects.toThrow();
  await expect(getTrackingOffer({ data: { token: "v1.fake.fake" } })).rejects.toThrow();
  expect(gateway).not.toHaveBeenCalled();
  gateway
    .mockResolvedValueOnce(json({ status: "approved" }))
    .mockResolvedValueOnce(json({ error: "unavailable" }, 502));
  expect(await createTrackingPix({ data: { token, customer } })).toEqual({
    ok: false,
    error: "O gateway Pix está indisponível no momento. Tente novamente.",
  });
});

it("keeps the original charge amount and includes a protected handoff without exposing credentials", async () => {
  gateway.mockResolvedValueOnce(
    json({ transaction_id: "ORDER-PAID-123", qr_code: "000201ORIGINAL" }),
  );
  const charge = await createPixCharge({
    data: { offers: {}, shipping: "free", customer, address },
  });
  expect(charge.amount).toBe(9790);
  expect(await openTrackingAccess(charge.trackingAccess!)).toMatchObject({
    chargeId: charge.id,
    customer,
    address,
  });
  expect(JSON.stringify(charge)).not.toContain("test-key-not-a-live-credential");
});

it("preserves an already-created original Pix if the optional handoff cannot be issued", async () => {
  gateway.mockResolvedValueOnce(
    json({ transaction_id: "unsupported/id", qr_code: "000201ORIGINAL" }),
  );
  vi.spyOn(console, "error").mockImplementation(() => {});
  const charge = await createPixCharge({
    data: { offers: {}, shipping: "free", customer, address },
  });
  expect(charge).toMatchObject({ id: "unsupported/id", qrCode: "000201ORIGINAL", amount: 9790 });
  expect(charge.trackingAccess).toBeUndefined();
});

it("creates exactly a 2930-cent test charge on this project's preview without pretending the original order is approved", async () => {
  gateway.mockResolvedValueOnce(json({ transaction_id: "TEST-123", qr_code: "000201PIX" }));
  const input = {
    confirmRealCharge: true as const,
    mode: "test" as const,
    customer,
    amount: 1,
  };
  const result = await createTrackingPublicPix({ data: input });
  expect(gateway).toHaveBeenCalledOnce();
  expect(gateway.mock.calls[0]![0]).toContain("/transaction");
  const payload = JSON.parse(gateway.mock.calls[0]![1].body);
  expect(payload).toMatchObject({ amount: 2930, customer });
  expect(payload).not.toHaveProperty("address");
  expect(payload.description).toContain("TESTE");
  expect(payload.description).toContain("sem pedido");
  expect(payload.reference).toMatch(/^TESTE-RASTREIO-/);
  expect(result).toMatchObject({
    ok: true,
    charge: { id: "TEST-123", qrCode: "000201PIX", amount: 2930 },
  });
  expect(JSON.stringify(result)).not.toContain("trackingAccess");
});

it("creates a public service charge without requiring a parent payment or a specific hostname", async () => {
  gateway.mockResolvedValueOnce(json({ transaction_id: "DIRECT-123", qr_code: "000201PIX" }));
  const result = await createTrackingPublicPix({
    data: { confirmRealCharge: true, mode: "service", customer, amount: 1 } as never,
  });
  expect(result).toMatchObject({ ok: true, charge: { id: "DIRECT-123", amount: 2930 } });
  expect(gateway).toHaveBeenCalledOnce();
  const payload = JSON.parse(gateway.mock.calls[0]![1].body);
  expect(payload).toMatchObject({ amount: 2930, customer });
  expect(payload).not.toHaveProperty("address");
  expect(payload.description).toBe("Rastreamento opcional — solicitação pelo site");
  expect(payload.reference).toMatch(/^RASTREIO-/);
  expect(payload.description).not.toContain("TESTE");
});

it("requires explicit real-charge confirmation and valid customer details before contacting the gateway", async () => {
  await expect(
    createTrackingPublicPix({
      data: { confirmRealCharge: false, mode: "test", customer },
    } as never),
  ).rejects.toThrow();
  await expect(
    createTrackingPublicPix({
      data: {
        confirmRealCharge: true,
        mode: "test",
        customer: { ...customer, document: "11111111111" },
      },
    }),
  ).rejects.toThrow();
  expect(gateway).not.toHaveBeenCalled();
});

it("accepts null optional gateway metadata without discarding a valid Pix", async () => {
  gateway.mockResolvedValueOnce(
    json({
      transaction_id: 12345,
      qr_code: "000201PIX",
      qr_code_base64: null,
      expires_at: null,
    }),
  );
  expect(
    await createTrackingPublicPix({
      data: { confirmRealCharge: true, mode: "test", customer },
    }),
  ).toEqual({
    ok: true,
    charge: {
      id: "12345",
      qrCode: "000201PIX",
      qrImage: "",
      amount: 2930,
      expiresAt: "",
      tracking: {},
    },
  });
});

it.each([
  [401, "O gateway recusou a configuração do Pix. Entre em contato com o atendimento."],
  [403, "O gateway recusou a configuração do Pix. Entre em contato com o atendimento."],
  [400, "O gateway não aceitou os dados da cobrança. Confira seus dados e tente novamente."],
  [422, "O gateway não aceitou os dados da cobrança. Confira seus dados e tente novamente."],
  [429, "Aguarde alguns instantes antes de gerar outro Pix."],
  [502, "O gateway Pix está indisponível no momento. Tente novamente."],
])("returns a safe actionable error for gateway HTTP %s", async (status, error) => {
  const log = vi.spyOn(console, "error").mockImplementation(() => {});
  gateway.mockResolvedValueOnce(json({ secret: "DO-NOT-EXPOSE", customer }, status as number));
  const result = await createTrackingPublicPix({
    data: { confirmRealCharge: true, mode: "service", customer },
  });
  expect(result).toEqual({ ok: false, error });
  expect(JSON.stringify(result)).not.toContain("DO-NOT-EXPOSE");
  expect(JSON.stringify(log.mock.calls)).not.toContain(customer.document);
});

it("returns a configuration error before making requests when the server key is missing", async () => {
  vi.stubEnv("PINGUPAG_API_KEY", "");
  expect(
    await createTrackingPublicPix({
      data: { confirmRealCharge: true, mode: "test", customer },
    }),
  ).toEqual({
    ok: false,
    error: "Pagamento Pix ainda não configurado. Entre em contato com o atendimento.",
  });
  expect(gateway).not.toHaveBeenCalled();
});

it("handles network failures and incomplete successful responses without exposing raw gateway content", async () => {
  vi.spyOn(console, "error").mockImplementation(() => {});
  gateway.mockRejectedValueOnce(new Error("private-network-message"));
  expect(
    await createTrackingPublicPix({
      data: { confirmRealCharge: true, mode: "test", customer },
    }),
  ).toEqual({
    ok: false,
    error: "O gateway Pix está indisponível no momento. Tente novamente.",
  });
  gateway.mockResolvedValueOnce(json({ transaction_id: "123", qr_code: "" }));
  expect(
    await createTrackingPublicPix({
      data: { confirmRealCharge: true, mode: "test", customer },
    }),
  ).toEqual({
    ok: false,
    error: "O gateway não retornou um código Pix válido. Tente novamente.",
  });
});
