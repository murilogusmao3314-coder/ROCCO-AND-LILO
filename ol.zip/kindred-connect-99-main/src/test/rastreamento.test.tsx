import { StrictMode } from "react";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { Route } from "@/routes/rastreamento";
import { handOffTrackingAccess, takeTrackingAccess } from "@/lib/tracking-access";
import { readTrackingReturn, rememberTrackingOrder } from "@/lib/tracking-return";

const { navigate, loadOffer, createPix, createPublicPix, getStatus, search } = vi.hoisted(() => ({
  navigate: vi.fn(),
  loadOffer: vi.fn(),
  createPix: vi.fn(),
  createPublicPix: vi.fn(),
  getStatus: vi.fn(),
  search: vi.fn(),
}));
vi.mock("@/lib/tracking.functions", () => ({
  getTrackingOffer: loadOffer,
  createTrackingPix: createPix,
  createTrackingPublicPix: createPublicPix,
}));
vi.mock("@/lib/pix.functions", () => ({ getPixStatus: getStatus }));
vi.mock("@tanstack/react-start", () => ({ useServerFn: (fn: unknown) => fn }));
vi.mock("@tanstack/react-router", () => ({
  createFileRoute: () => (options: { component: React.ComponentType }) => ({
    options,
    useSearch: search,
  }),
  useNavigate: () => navigate,
  Link: ({
    to,
    children,
    replace: _replace,
    search: _search,
    ...props
  }: {
    to: string;
    children: React.ReactNode;
    replace?: boolean;
    search?: unknown;
  }) => (
    <a href={to} {...props}>
      {children}
    </a>
  ),
}));
const Component = Route.options.component as React.ComponentType;
const charge = {
  id: "TRACKING-PAID-123",
  qrCode: "000201TEST-PIX",
  qrImage: "",
  amount: 2930,
  expiresAt: "",
};
beforeEach(() => {
  search.mockReset().mockReturnValue({});
  takeTrackingAccess();
  sessionStorage.clear();
  navigate.mockReset();
  loadOffer.mockReset().mockResolvedValue({
    customer: {
      name: "Pessoa Original",
      phone: "11987654321",
      document: "52998224725",
      email: "original@example.com",
    },
  });
  createPix.mockReset().mockResolvedValue({ ok: true, charge });
  createPublicPix
    .mockReset()
    .mockResolvedValue({ ok: true, charge: { ...charge, id: "TESTE-PIX-123" } });
  getStatus.mockReset().mockResolvedValue({ status: "pending" });
});
afterEach(() => {
  cleanup();
  takeTrackingAccess();
  sessionStorage.clear();
  localStorage.clear();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

async function showOffer() {
  handOffTrackingAccess("protected-token");
  const page = render(<Component />);
  await screen.findByRole("button", { name: "GERAR PIX — R$29,30" });
  return page;
}

function fillPublicPayer() {
  for (const [label, value] of Object.entries({
    "Nome completo": "Pessoa Teste",
    Celular: "11987654321",
    CPF: "52998224725",
    "E-mail para receber o código": "entrega@example.com",
  }))
    fireEvent.change(screen.getByLabelText(new RegExp("^" + label)), { target: { value } });
}

it("opens the public service form on a direct visit without calling payment endpoints", () => {
  render(<Component />);
  expect(screen.getByText("Rastreamento")).toBeInTheDocument();
  expect(screen.getByText("Seus dados")).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "GERAR PIX — R$29,30" })).toBeEnabled();
  expect(screen.getAllByRole("textbox")).toHaveLength(4);
  expect(
    screen.getByText("Se quiser consultar seu pedido, pague a taxa de consulta."),
  ).toBeInTheDocument();
  expect(screen.queryByLabelText("CEP")).not.toBeInTheDocument();
  expect(
    screen.queryByText("Confira o endereço antes de pagar. O envio é feito manualmente."),
  ).not.toBeInTheDocument();
  expect(
    screen.queryByText("Seu pedido será entregue mesmo se você não contratar este serviço."),
  ).not.toBeInTheDocument();
  expect(screen.queryByRole("link", { name: "Continuar sem contratar" })).not.toBeInTheDocument();
  expect(screen.queryByText("Pedido pago")).not.toBeInTheDocument();
  expect(navigate).not.toHaveBeenCalled();
  expect(loadOffer).not.toHaveBeenCalled();
  expect(createPix).not.toHaveBeenCalled();
  expect(createPublicPix).not.toHaveBeenCalled();
});

it("validates public payer data, shows a specific gateway error and allows generating a real QR on retry", async () => {
  render(<Component />);
  fireEvent.change(screen.getByLabelText("E-mail para receber o código"), {
    target: { value: "entrega@example.com" },
  });
  fireEvent.submit(screen.getByLabelText("E-mail para receber o código").closest("form")!);
  expect(createPublicPix).not.toHaveBeenCalled();
  expect(screen.getByRole("textbox", { name: /^Nome completo/ })).toHaveFocus();
  fillPublicPayer();
  createPublicPix.mockResolvedValueOnce({
    ok: false,
    error: "O gateway recusou a configuração do Pix. Entre em contato com o atendimento.",
  });
  await act(async () =>
    fireEvent.click(screen.getByRole("button", { name: "GERAR PIX — R$29,30" })),
  );
  expect(screen.getByRole("alert")).toHaveTextContent("O gateway recusou a configuração do Pix");
  expect(screen.getByRole("button", { name: "GERAR PIX — R$29,30" })).toBeEnabled();
  expect(screen.queryByLabelText("Pix copia e cola")).not.toBeInTheDocument();
  await act(async () =>
    fireEvent.click(screen.getByRole("button", { name: "GERAR PIX — R$29,30" })),
  );
  await act(async () => {
    await vi.dynamicImportSettled();
  });
  expect(createPublicPix).toHaveBeenLastCalledWith({
    data: {
      confirmRealCharge: true,
      tracking: {},
      mode: "service",
      customer: {
        name: "Pessoa Teste",
        email: "entrega@example.com",
        phone: "11987654321",
        document: "52998224725",
      },
    },
  });
  expect(createPix).not.toHaveBeenCalled();
  expect(loadOffer).not.toHaveBeenCalled();
  expect(screen.getByRole("heading", { name: "Pague a consulta com Pix" })).toBeInTheDocument();
  expect(screen.getByLabelText("Pix copia e cola")).toHaveValue(charge.qrCode);
  expect(screen.queryByText("Pedido pago")).not.toBeInTheDocument();
});

it("shows the real-charge test form without consuming approval access or calling payment endpoints on entry", () => {
  search.mockReturnValue({ preview: true });
  handOffTrackingAccess("protected-token");
  render(<Component />);
  expect(screen.getByText("Teste de geração Pix")).toBeInTheDocument();
  expect(screen.getByText(/Será criada uma cobrança real/)).toBeInTheDocument();
  expect(screen.getByRole("heading", { name: "Consulta do pedido" })).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "GERAR PIX DE TESTE — R$29,30" })).toBeEnabled();
  fireEvent.change(screen.getByLabelText("E-mail para receber o código"), {
    target: { value: "preview@example.com" },
  });
  fireEvent.submit(screen.getByLabelText("E-mail para receber o código").closest("form")!);
  expect(navigate).not.toHaveBeenCalled();
  expect(loadOffer).not.toHaveBeenCalled();
  expect(createPix).not.toHaveBeenCalled();
  expect(createPublicPix).not.toHaveBeenCalled();
  expect(getStatus).not.toHaveBeenCalled();
  expect(takeTrackingAccess()).toBe("protected-token");
});

it("switches from test to the public service form when the preview flag is removed", () => {
  search.mockReturnValue({ preview: true });
  const page = render(<Component />);
  expect(screen.getByRole("button", { name: "GERAR PIX DE TESTE — R$29,30" })).toBeEnabled();
  search.mockReturnValue({});
  page.rerender(<Component />);
  expect(navigate).not.toHaveBeenCalled();
  expect(screen.getByRole("button", { name: "GERAR PIX — R$29,30" })).toBeEnabled();
  expect(screen.getByText("Seus dados")).toBeInTheDocument();
  expect(createPix).not.toHaveBeenCalled();
});

it("generates a separate test Pix with entered payer data without reporting advertising conversions", async () => {
  rememberTrackingOrder("ORDER-123");
  search.mockReturnValue({ preview: true });
  render(<Component />);
  for (const [label, value] of Object.entries({
    "Nome completo": "Pessoa Teste",
    Celular: "11987654321",
    CPF: "52998224725",
    "E-mail para receber o código": "teste@example.com",
  }))
    fireEvent.change(screen.getByLabelText(label), { target: { value } });
  vi.useFakeTimers();
  await act(async () =>
    fireEvent.click(screen.getByRole("button", { name: "GERAR PIX DE TESTE — R$29,30" })),
  );
  await act(async () => {
    await vi.dynamicImportSettled();
  });
  expect(createPublicPix).toHaveBeenCalledExactlyOnceWith({
    data: {
      confirmRealCharge: true,
      tracking: {},
      mode: "test",
      customer: {
        name: "Pessoa Teste",
        email: "teste@example.com",
        phone: "11987654321",
        document: "52998224725",
      },
    },
  });
  expect(createPix).not.toHaveBeenCalled();
  expect(screen.getByRole("heading", { name: "Pix de teste gerado" })).toBeInTheDocument();
  expect(screen.getByLabelText("Pix copia e cola")).toHaveValue(charge.qrCode);
  expect(screen.getByRole("img", { name: "QR Code Pix" })).toHaveAttribute(
    "src",
    expect.stringContaining("data:image/svg+xml"),
  );
  getStatus.mockResolvedValue({ status: "approved" });
  await act(async () => {
    await vi.advanceTimersByTimeAsync(5000);
  });
  expect(
    screen.getByRole("heading", { name: "Pagamento de teste confirmado" }),
  ).toBeInTheDocument();
  expect(screen.getByText(/não contrata rastreamento/)).toBeInTheDocument();
  expect(readTrackingReturn()).toMatchObject({ orderId: "ORDER-123" });
});

it("consumes the paid handoff once and shows the public form on a later visit", async () => {
  handOffTrackingAccess("protected-token");
  const page = render(
    <StrictMode>
      <Component />
    </StrictMode>,
  );
  await screen.findByRole("button", { name: "GERAR PIX — R$29,30" });
  expect(screen.queryByRole("link", { name: "Continuar sem contratar" })).not.toBeInTheDocument();
  expect(screen.getByLabelText("Nome completo")).toHaveValue("Pessoa Original");
  expect(screen.getByLabelText("CPF")).toHaveValue("529.982.247-25");
  expect(screen.getByLabelText("Celular")).toHaveValue("(11) 98765-4321");
  expect(screen.getAllByRole("textbox")).toHaveLength(4);
  expect(takeTrackingAccess()).toBeNull();
  page.unmount();
  render(<Component />);
  expect(navigate).not.toHaveBeenCalled();
  expect(screen.getByRole("button", { name: "GERAR PIX — R$29,30" })).toBeEnabled();
  expect(screen.getByText("Seus dados")).toBeInTheDocument();
});

it("does not show the offer when server verification fails, and allows a safe retry", async () => {
  handOffTrackingAccess("protected-token");
  loadOffer.mockRejectedValueOnce(new Error("pending"));
  render(<Component />);
  await screen.findByRole("heading", { name: "Não foi possível confirmar o acesso" });
  expect(screen.queryByRole("button", { name: "GERAR PIX — R$29,30" })).not.toBeInTheDocument();
  expect(createPix).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole("button", { name: "TENTAR NOVAMENTE" }));
  await screen.findByRole("button", { name: "GERAR PIX — R$29,30" });
});

it("validates the recipient and prevents duplicate submissions while showing gateway failures", async () => {
  await showOffer();
  const email = screen.getByLabelText("E-mail para receber o código");
  fireEvent.change(email, { target: { value: "invalid" } });
  fireEvent.click(screen.getByRole("button", { name: "GERAR PIX — R$29,30" }));
  expect(email).toHaveAttribute("aria-invalid", "true");
  expect(email).toHaveAccessibleDescription("Informe um e-mail válido.");
  expect(createPix).not.toHaveBeenCalled();
  fireEvent.change(email, { target: { value: "entrega@example.com" } });
  let reject!: (reason: Error) => void;
  createPix.mockReturnValue(
    new Promise((_resolve, fail) => {
      reject = fail;
    }),
  );
  const form = email.closest("form")!;
  fireEvent.submit(form);
  fireEvent.submit(form);
  expect(createPix).toHaveBeenCalledExactlyOnceWith({
    data: {
      token: "protected-token",
      tracking: {},
      customer: {
        name: "Pessoa Original",
        email: "entrega@example.com",
        phone: "11987654321",
        document: "52998224725",
      },
    },
  });
  expect(screen.getByRole("button", { name: "GERANDO PIX…" })).toBeDisabled();
  await act(async () => reject(new Error("offline")));
  expect(screen.getByRole("alert")).toHaveTextContent("Não foi possível gerar o Pix");
  expect(screen.getByRole("button", { name: "GERAR PIX — R$29,30" })).toBeEnabled();
});

it("shows a real QR and confirms manual delivery only after the additional Pix is approved", async () => {
  rememberTrackingOrder("ORDER-123");
  await showOffer();
  const fbq = vi.fn();
  vi.stubGlobal("fbq", fbq);
  fireEvent.change(screen.getByLabelText("E-mail para receber o código"), {
    target: { value: "entrega@example.com" },
  });
  vi.useFakeTimers();
  await act(async () =>
    fireEvent.click(screen.getByRole("button", { name: "GERAR PIX — R$29,30" })),
  );
  await act(async () => {
    await vi.dynamicImportSettled();
  });
  expect(screen.getByLabelText("Pix copia e cola")).toHaveValue(charge.qrCode);
  expect(readTrackingReturn()).toMatchObject({ orderId: "ORDER-123", serviceId: charge.id });
  expect(screen.getByRole("img", { name: "QR Code Pix" })).toHaveAttribute(
    "src",
    expect.stringContaining("data:image/svg+xml"),
  );
  expect(screen.queryByRole("heading", { name: "Solicitação confirmada" })).not.toBeInTheDocument();
  expect(fbq).toHaveBeenCalledWith("trackSingle", "1418898839713148", "AddPaymentInfo",
    expect.objectContaining({ value: 29.3 }), { eventID: "corre-rosa:AddPaymentInfo:TRACKING-PAID-123" });
  getStatus.mockResolvedValue({ status: "approved" });
  await act(async () => {
    await vi.advanceTimersByTimeAsync(5000);
  });
  expect(screen.getByRole("heading", { name: "Solicitação confirmada" })).toHaveFocus();
  expect(screen.getByText(/O código de rastreio será enviado manualmente/)).toHaveTextContent(
    "entrega@example.com",
  );
  expect(fbq).toHaveBeenCalledWith("trackSingle", "1418898839713148", "Purchase",
    expect.objectContaining({ value: 29.3 }), { eventID: "corre-rosa:Purchase:TRACKING-PAID-123" });
  expect(navigate).not.toHaveBeenCalled();
  expect(readTrackingReturn()).toBeNull();
});

it("expires an unused handoff and falls back to memory when browser storage is restricted", () => {
  handOffTrackingAccess("expired-token");
  vi.useFakeTimers();
  vi.advanceTimersByTime(60_001);
  expect(takeTrackingAccess()).toBeNull();
  vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
    throw new Error("blocked");
  });
  vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
    throw new Error("blocked");
  });
  handOffTrackingAccess("memory-token");
  expect(takeTrackingAccess()).toBe("memory-token");
  expect(takeTrackingAccess()).toBeNull();
});
