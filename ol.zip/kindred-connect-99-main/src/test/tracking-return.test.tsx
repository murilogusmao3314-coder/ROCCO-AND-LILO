import { StrictMode } from "react";
import { act, cleanup, render, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { TrackingReturn } from "@/components/tracking-return";
import {
  checkTrackingReturn,
  clearTrackingReturn,
  completeTrackingService,
  readTrackingReturn,
  rememberTrackingOrder,
  rememberTrackingService,
  trackingReturnKey,
} from "@/lib/tracking-return";

const { getStatus, router } = vi.hoisted(() => ({
  getStatus: vi.fn(),
  router: {
    state: { location: { pathname: "/", href: "/?utm_source=facebook" } },
    navigate: vi.fn(),
  },
}));
vi.mock("@/lib/pix.functions", () => ({ getPixStatus: getStatus }));
vi.mock("@tanstack/react-start", () => ({ useServerFn: (fn: unknown) => fn }));
vi.mock("@tanstack/react-router", () => ({ useRouter: () => router }));

beforeEach(() => {
  localStorage.clear();
  router.state.location = { pathname: "/", href: "/?utm_source=facebook" };
  router.navigate.mockReset().mockResolvedValue(undefined);
  getStatus.mockReset().mockResolvedValue({ status: "pending" });
  vi.stubGlobal("fbq", vi.fn());
});
afterEach(() => {
  cleanup();
  localStorage.clear();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

it.each(["pending", "failed", "approved"])(
  "tracks returning purchases only for approved Pingu orders (%s)",
  async (status) => {
    const id = "RETURN-SNAPSHOT-" + status;
    rememberTrackingOrder(id, {
      amount: 11780,
      offers: { socks: "34 a 38" },
      shipping: "free",
      tracking: { utm_source: "teste", utm_campaign: "teste", utm_content: "criativo1" },
    });
    getStatus.mockResolvedValue({ status });
    render(<TrackingReturn />);
    await act(async () => {
      await vi.dynamicImportSettled();
    });
    expect(getStatus).toHaveBeenCalledExactlyOnceWith({ data: { id } });
    if (status === "approved") {
      expect(router.navigate).toHaveBeenCalledExactlyOnceWith({
        to: "/rastreamento",
        search: expect.any(Function),
        replace: true,
      });
    } else {
      expect(router.navigate).not.toHaveBeenCalled();
    }
    if (status === "approved") {
      expect(window.fbq).toHaveBeenCalledExactlyOnceWith(
        "trackSingle", "1418898839713148", "Purchase",
        expect.objectContaining({ value: 117.8, utm_campaign: "teste" }),
        { eventID: "corre-rosa:Purchase:" + id },
      );
    } else expect(window.fbq).not.toHaveBeenCalled();
    if (status === "failed") expect(readTrackingReturn()).toBeNull();
    else expect(readTrackingReturn()).toMatchObject({ orderId: id });
  },
);

it("does no payment work for visitors without a saved order or on the public tracking page", () => {
  const page = render(<TrackingReturn />);
  expect(getStatus).not.toHaveBeenCalled();
  page.unmount();
  rememberTrackingOrder("ORDER-123");
  router.state.location = { pathname: "/rastreamento", href: "/rastreamento?preview=1" };
  render(<TrackingReturn />);
  expect(getStatus).not.toHaveBeenCalled();
  expect(router.navigate).not.toHaveBeenCalled();
});

it("verifies saved orders and redirects on every fresh visit, without duplicating the request in StrictMode", async () => {
  rememberTrackingOrder("ORDER-123");
  getStatus.mockResolvedValue({ status: "approved" });
  const page = render(
    <StrictMode>
      <TrackingReturn />
    </StrictMode>,
  );
  await waitFor(() =>
    expect(router.navigate).toHaveBeenCalledExactlyOnceWith({
      to: "/rastreamento",
      search: expect.any(Function),
      replace: true,
    }),
  );
  expect(getStatus).toHaveBeenCalledExactlyOnceWith({ data: { id: "ORDER-123" } });
  page.rerender(
    <StrictMode>
      <TrackingReturn />
    </StrictMode>,
  );
  expect(router.navigate).toHaveBeenCalledOnce();
  page.unmount();
  router.navigate.mockClear();
  render(<TrackingReturn />);
  await waitFor(() => expect(router.navigate).toHaveBeenCalledOnce());
  expect(getStatus).toHaveBeenCalledTimes(2);
});

it.each(["pending", "failed", "unknown"])(
  "never trusts local storage as approval when the gateway reports %s",
  async (status) => {
    rememberTrackingOrder("ORDER-123");
    getStatus.mockResolvedValue({ status });
    await act(async () => {
      render(<TrackingReturn />);
    });
    expect(router.navigate).not.toHaveBeenCalled();
    expect(readTrackingReturn()).toEqual(status === "failed" ? null : { orderId: "ORDER-123" });
  },
);

it("detects service approval even if the site was closed before confirmation and stops future redirects", async () => {
  rememberTrackingOrder("ORDER-123");
  rememberTrackingService("SERVICE-123");
  getStatus.mockResolvedValue({ status: "approved" });
  const page = render(<TrackingReturn />);
  await waitFor(() => expect(readTrackingReturn()).toBeNull());
  expect(getStatus).toHaveBeenCalledExactlyOnceWith({ data: { id: "SERVICE-123" } });
  expect(router.navigate).not.toHaveBeenCalled();
  page.unmount();
  getStatus.mockClear();
  render(<TrackingReturn />);
  expect(getStatus).not.toHaveBeenCalled();
});

it("still redirects a paid order when its separate service Pix remains pending", async () => {
  rememberTrackingOrder("ORDER-123");
  rememberTrackingService("SERVICE-123");
  getStatus
    .mockResolvedValueOnce({ status: "pending" })
    .mockResolvedValueOnce({ status: "approved" });
  render(<TrackingReturn />);
  await waitFor(() => expect(router.navigate).toHaveBeenCalledOnce());
  expect(getStatus.mock.calls).toEqual([
    [{ data: { id: "SERVICE-123" } }],
    [{ data: { id: "ORDER-123" } }],
  ]);
  expect(readTrackingReturn()).toEqual({ orderId: "ORDER-123", serviceId: "SERVICE-123" });
});

it("does not trap SPA navigation after continuing without the optional service", async () => {
  rememberTrackingOrder("ORDER-123");
  getStatus.mockResolvedValue({ status: "approved" });
  const page = render(<TrackingReturn />);
  await waitFor(() => expect(router.navigate).toHaveBeenCalledOnce());
  router.state.location = { pathname: "/loja", href: "/loja?utm_source=facebook" };
  page.rerender(<TrackingReturn />);
  expect(router.navigate).toHaveBeenCalledOnce();
  expect(getStatus).toHaveBeenCalledOnce();
});

it("does not override navigation or a newer order while waiting for the gateway", async () => {
  rememberTrackingOrder("ORDER-123");
  let resolve!: (value: { status: string }) => void;
  getStatus.mockReturnValue(
    new Promise((done) => {
      resolve = done;
    }),
  );
  const page = render(<TrackingReturn />);
  router.state.location = { pathname: "/checkout", href: "/checkout" };
  await act(async () => resolve({ status: "approved" }));
  expect(router.navigate).not.toHaveBeenCalled();
  page.unmount();
  router.state.location = { pathname: "/", href: "/" };
  getStatus.mockReturnValue(
    new Promise((done) => {
      resolve = done;
    }),
  );
  render(<TrackingReturn />);
  rememberTrackingOrder("NEW-ORDER");
  await act(async () => resolve({ status: "approved" }));
  expect(router.navigate).not.toHaveBeenCalled();
  expect(readTrackingReturn()).toEqual({ orderId: "NEW-ORDER" });
});

it("leaves navigation and the saved order intact on a gateway failure", async () => {
  rememberTrackingOrder("ORDER-123");
  getStatus.mockRejectedValue(new Error("offline"));
  await act(async () => {
    render(<TrackingReturn />);
  });
  expect(router.navigate).not.toHaveBeenCalled();
  expect(readTrackingReturn()).toEqual({ orderId: "ORDER-123" });
});

it("stores only IDs, preserves an existing service, and clears only the matching completed service", () => {
  rememberTrackingOrder("ORDER-123");
  rememberTrackingService("SERVICE-123");
  rememberTrackingOrder("ORDER-123");
  expect(JSON.parse(localStorage.getItem(trackingReturnKey)!)).toEqual({
    orderId: "ORDER-123",
    serviceId: "SERVICE-123",
  });
  completeTrackingService("OTHER-SERVICE");
  expect(readTrackingReturn()).not.toBeNull();
  completeTrackingService("SERVICE-123");
  expect(readTrackingReturn()).toBeNull();
  rememberTrackingOrder("ORDER-NEW");
  clearTrackingReturn({ orderId: "ORDER-OLD" });
  expect(readTrackingReturn()).toEqual({ orderId: "ORDER-NEW" });
});

it("ignores malformed identifiers, malformed JSON and blocked browser storage without throwing", () => {
  for (const value of [
    "bad-json",
    '{"orderId":"https://other.example"}',
    '{"orderId":"ORDER-123","serviceId":123}',
  ]) {
    localStorage.setItem(trackingReturnKey, value);
    expect(readTrackingReturn()).toBeNull();
  }
  localStorage.clear();
  rememberTrackingOrder("unsupported/id");
  expect(readTrackingReturn()).toBeNull();
  vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
    throw new Error("blocked");
  });
  expect(() => rememberTrackingOrder("ORDER-123")).not.toThrow();
  vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
    throw new Error("blocked");
  });
  expect(readTrackingReturn()).toBeNull();
});

it("does not continue to the original payment after an unavailable service query", async () => {
  const status = vi.fn().mockRejectedValue(new Error("offline"));
  expect(
    await checkTrackingReturn({ orderId: "ORDER-123", serviceId: "SERVICE-123" }, status),
  ).toBe("none");
  expect(status).toHaveBeenCalledExactlyOnceWith("SERVICE-123");
});
