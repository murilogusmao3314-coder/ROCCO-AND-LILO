import { beforeEach, afterEach, expect, it, vi } from "vitest";

beforeEach(() => {
  vi.resetModules();
  localStorage.clear();
});
afterEach(() => {
  vi.unstubAllGlobals();
  localStorage.clear();
});

it("initializes only the new Meta ID once and tracks the first PageView", async () => {
  const { metaPixelBootstrap, metaPixelId } = await import("@/lib/meta-pixel");
  const existing = document.getElementById("meta-pixel-test-sdk");
  existing?.remove();
  vi.stubGlobal("fbq", vi.fn());
  Reflect.deleteProperty(window, "__correRosaMetaPixel");
  new Function(metaPixelBootstrap)();
  new Function(metaPixelBootstrap)();
  expect(window.fbq).toHaveBeenCalledTimes(2);
  expect(window.fbq).toHaveBeenNthCalledWith(1, "init", metaPixelId);
  expect(window.fbq).toHaveBeenNthCalledWith(2, "trackSingle", metaPixelId, "PageView");
  Reflect.deleteProperty(window, "__correRosaMetaPixel");
});

it("does not send transaction Purchase twice and uses the approved charge amount", async () => {
  const fbq = vi.fn();
  vi.stubGlobal("fbq", fbq);
  const { trackMetaOrderPayment } = await import("@/lib/meta-pixel");
  const charge = { id: "APPROVED-TEST-123", amount: 11780, tracking: { utm_campaign: "test" } };
  trackMetaOrderPayment("Purchase", charge, { socks: "34 a 38" }, "free");
  trackMetaOrderPayment("Purchase", charge, { socks: "34 a 38" }, "free");
  expect(fbq).toHaveBeenCalledExactlyOnceWith(
    "trackSingle", "1418898839713148", "Purchase",
    expect.objectContaining({ value: 117.8, currency: "BRL", utm_campaign: "test" }),
    { eventID: "corre-rosa:Purchase:APPROVED-TEST-123" },
  );
  expect(localStorage.getItem("corre-rosa-meta:1418898839713148:Purchase:APPROVED-TEST-123"))
    .toBe("sent");
});
