import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { buildUtmifyOrder } from "../lib/utmify-order";
import { enqueueUtmifyOrder } from "../lib/utmify-queue.server";

const order = buildUtmifyOrder({
  id: "queue-123",
  amount: 9790,
  customer: {
    name: "Cliente Teste",
    email: "test@example.com",
    phone: "11999999999",
    document: "52998224725",
    country: "BR",
  },
  offers: {},
  tracking: { utm_source: "facebook", utm_campaign: "campanha-123" },
  created: new Date("2026-10-12T10:00:00.000Z"),
});

beforeEach(() => {
  vi.stubEnv("UTMIFY_DIRECT_ENABLED", "true");
  vi.stubEnv("PINGUPAG_API_KEY", "test-gateway-key");
  vi.stubEnv("URL", "");
  vi.stubEnv("UTMIFY_QUEUE_ORIGIN", "");
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

it("uses the current Netlify site instead of a stale queue origin from the former account", async () => {
  vi.stubEnv("URL", "https://novo-site.netlify.app");
  vi.stubEnv("UTMIFY_QUEUE_ORIGIN", "https://conta-antiga.netlify.app");
  const request = vi.fn().mockResolvedValue(new Response(null, { status: 202 }));
  vi.stubGlobal("fetch", request);

  await enqueueUtmifyOrder(order);

  expect(request).toHaveBeenCalledOnce();
  const [url, options] = request.mock.calls[0]!;
  expect(String(url)).toBe("https://novo-site.netlify.app/.netlify/functions/utmify-order");
  expect(options.method).toBe("POST");
  expect(options.headers["X-Order-Signature"]).toMatch(/^[a-f0-9]{64}$/);
  expect(JSON.parse(options.body).order).toEqual(order);
});

it("allows an explicit HTTPS origin when not running inside Netlify", async () => {
  vi.stubEnv("UTMIFY_QUEUE_ORIGIN", "https://local-proxy.example");
  const request = vi.fn().mockResolvedValue(new Response(null, { status: 202 }));
  vi.stubGlobal("fetch", request);

  await enqueueUtmifyOrder(order);

  expect(request.mock.calls[0]![0].origin).toBe("https://local-proxy.example");
});

it("rejects HTML 200 fallbacks and unavailable queue functions instead of losing sales silently", async () => {
  vi.stubEnv("URL", "https://novo-site.netlify.app");
  for (const status of [200, 404, 503]) {
    const request = vi.fn().mockResolvedValue(new Response(null, { status }));
    vi.stubGlobal("fetch", request);
    await expect(enqueueUtmifyOrder(order)).rejects.toThrow(
      "Utmify queue unavailable: " + status,
    );
  }
});

it("fails clearly without a queue origin instead of posting to a previous site", async () => {
  const request = vi.fn();
  vi.stubGlobal("fetch", request);
  await expect(enqueueUtmifyOrder(order)).rejects.toThrow("Missing UTMify queue origin");
  expect(request).not.toHaveBeenCalled();
});

it("rejects insecure queue URLs before sending any order", async () => {
  vi.stubEnv("UTMIFY_QUEUE_ORIGIN", "http://wrong.example");
  const request = vi.fn();
  vi.stubGlobal("fetch", request);
  await expect(enqueueUtmifyOrder(order)).rejects.toThrow("Invalid queue origin");
  expect(request).not.toHaveBeenCalled();
});
