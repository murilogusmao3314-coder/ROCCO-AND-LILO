import { afterEach, beforeEach, expect, it, vi } from "vitest";
import {
  buildUrlWithTracking,
  captureTracking,
  debugTracking,
  getStoredTrackingParameters,
  trackingBootstrap,
  trackingCookieKey,
  trackingLifetime,
  trackingStorageKey,
} from "@/lib/tracking";
import {
  createMemoryHistory,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import {
  parseAttributionSearch,
  retainAttributionSearch,
  stringifyAttributionSearch,
  validateAttributionSearch,
} from "@/lib/campaign-attribution";
import { renderErrorPage } from "@/lib/error-page";

const entry = (path: string) => window.history.replaceState({ keep: true }, "", path);
const clearCookies = () => {
  for (const cookie of document.cookie.split(";"))
    document.cookie = cookie.split("=")[0] + "=; Path=/; Max-Age=0";
};
beforeEach(() => {
  localStorage.clear();
  sessionStorage.clear();
  clearCookies();
  entry("/");
  Reflect.deleteProperty(window, "__correRosaTrackingEntry");
});
afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
  localStorage.clear();
  sessionStorage.clear();
  clearCookies();
  entry("/");
});

it("captures supported attribution fields without old Meta pixel cookies", () => {
  const query = {
    utm_source: "teste",
    utm_medium: "paid social",
    utm_campaign: "19000000000000000001",
    utm_content: "criativo1 + ação & 10%",
    utm_term: "false",
    utm_id: "0001",
    fbclid: "FB-CLICK",
    gclid: "GOOGLE-CLICK",
    ttclid: "TIKTOK-CLICK",
    src: "ads",
    sck: "001|null",
    xcod: "code",
  };
  document.cookie = "_fbp=fb.1.100.123; Path=/";
  document.cookie = "_fbc=fb.1.100.FB-CLICK; Path=/";
  entry("/checkout?" + new URLSearchParams({ ...query, email: "private", token: "private" }));
  new Function(trackingBootstrap)();
  expect(captureTracking()).toEqual(query);
  const snapshot = JSON.parse(localStorage.getItem(trackingStorageKey)!);
  expect(snapshot.values).toEqual(query);
  expect(snapshot.expiresAt - Date.now()).toBeCloseTo(trackingLifetime, -2);
  expect(document.cookie).toContain(trackingCookieKey + "=");
  expect(JSON.stringify(snapshot)).not.toContain("private");
});

it("survives a closed tab and parameterless direct entries at every step without resetting expiration", () => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-10-09T10:00:00Z"));
  entry("/?utm_source=teste&utm_campaign=teste&utm_content=criativo1");
  const expected = captureTracking();
  const snapshot = localStorage.getItem(trackingStorageKey);
  sessionStorage.clear();
  vi.advanceTimersByTime(24 * 60 * 60 * 1000);
  for (const path of ["/quiz", "/parabens", "/loja", "/checkout", "/rastreamento"]) {
    entry(path + "?preview=1#pix");
    new Function(trackingBootstrap)();
    expect(captureTracking()).toEqual(expected);
    expect(window.location.hash).toBe("#pix");
    expect(new URLSearchParams(window.location.search).get("utm_content")).toBe("criativo1");
    expect(window.history.state).toEqual({ keep: true });
    expect(localStorage.getItem(trackingStorageKey)).toBe(snapshot);
  }
});

it("recovers the full cookie backup when local storage is missing, corrupted, or blocked", () => {
  entry("/quiz?utm_source=teste&utm_campaign=teste&utm_content=criativo1");
  const expected = captureTracking();
  entry("/checkout");
  localStorage.clear();
  expect(captureTracking()).toEqual(expected);
  localStorage.setItem(trackingStorageKey, "{bad");
  expect(captureTracking()).toEqual(expected);
  vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
    throw new Error("blocked");
  });
  vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
    throw new Error("blocked");
  });
  expect(captureTracking()).toEqual(expected);
  expect(buildUrlWithTracking("/checkout")).toContain("utm_content=criativo1");
});

it("backs up attribution larger than a single cookie without truncating IDs", () => {
  const fields = {
    utm_campaign: "ação".repeat(200),
    utm_content: "123".repeat(300),
    utm_term: "rosa".repeat(200),
  };
  entry("/loja?" + new URLSearchParams(fields));
  expect(captureTracking()).toEqual(fields);
  expect(
    Number(
      document.cookie
        .split("; ")
        .find((part) => part.startsWith(trackingCookieKey + "="))
        ?.split("=")[1],
    ),
  ).toBeGreaterThan(1);
  localStorage.clear();
  entry("/checkout");
  expect(captureTracking()).toEqual(fields);
});

it("uses the newer cookie snapshot when local storage can be read but rejects writes", () => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-10-09T10:00:00Z"));
  entry("/?utm_campaign=A&utm_content=creative-A");
  captureTracking();
  vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
    throw new Error("read only");
  });
  entry("/loja?utm_campaign=B&utm_content=creative-B");
  captureTracking();
  entry("/checkout");
  expect(captureTracking()).toEqual({ utm_campaign: "B", utm_content: "creative-B" });
});

it("expires after thirty days and does not resurrect the migrated session", () => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-10-09T10:00:00Z"));
  sessionStorage.setItem(
    "corre-rosa-attribution-session-v1",
    JSON.stringify({ utm_campaign: "old", token: "private" }),
  );
  expect(captureTracking()).toEqual({ utm_campaign: "old" });
  expect(sessionStorage.getItem("corre-rosa-attribution-session-v1")).toBeNull();
  vi.advanceTimersByTime(trackingLifetime + 1);
  expect(captureTracking()).toEqual({});
  expect(getStoredTrackingParameters()).toEqual({});
  expect(buildUrlWithTracking("/checkout")).toBe("/checkout");
});

it("preserves the snapshot on empty or invalid URLs and replaces it only on a new attribution", () => {
  entry("/?utm_campaign=A&utm_content=creative-A&fbclid=CLICK-A");
  captureTracking();
  entry("/quiz");
  expect(captureTracking()).toMatchObject({ utm_campaign: "A", utm_content: "creative-A" });
  entry("/checkout?utm_campaign=&utm_content=B&utm_content=C");
  expect(captureTracking()).toMatchObject({ utm_campaign: "A", utm_content: "creative-A" });
  entry("/loja?utm_campaign=B&utm_content=creative-B");
  expect(captureTracking()).toEqual({ utm_campaign: "B", utm_content: "creative-B" });
  entry("/checkout");
  expect(captureTracking()).toEqual({ utm_campaign: "B", utm_content: "creative-B" });
});

it("builds internal and external checkout URLs with existing queries and hashes intact and without forwarding cookie or personal data", () => {
  entry("/?utm_source=teste&utm_campaign=teste&utm_content=criativo1&email=private");
  document.cookie = "_fbp=fb.1.100.123; Path=/";
  captureTracking();
  const internal = new URL(
    buildUrlWithTracking("/checkout?shipping=express#pix"),
    window.location.href,
  );
  expect(internal.pathname).toBe("/checkout");
  expect(internal.hash).toBe("#pix");
  expect(Object.fromEntries(internal.searchParams)).toEqual({
    shipping: "express",
    utm_source: "teste",
    utm_campaign: "teste",
    utm_content: "criativo1",
  });
  const external = new URL(
    buildUrlWithTracking("https://checkout.example/pagar?product=1&utm_content=own#payment"),
  );
  expect(external.origin).toBe("https://checkout.example");
  expect(external.hash).toBe("#payment");
  expect(external.searchParams.get("utm_content")).toBe("own");
  expect(external.searchParams.get("utm_campaign")).toBe("teste");
  expect(external.searchParams.has("_fbp")).toBe(false);
  expect(external.searchParams.has("email")).toBe(false);
  expect(buildUrlWithTracking("#conteudo")).toBe("#conteudo");
});

it("adds persisted tracking to real router links and redirects even when the current URL has no query", async () => {
  entry("/quiz?utm_source=teste&utm_campaign=teste&utm_content=criativo1&fbclid=CLICK");
  captureTracking();
  entry("/");
  const root = createRootRoute({
    validateSearch: validateAttributionSearch,
    search: { middlewares: [retainAttributionSearch] },
  });
  const routes = ["/", "/quiz", "/parabens", "/loja", "/checkout", "/rastreamento"].map((path) =>
    createRoute({ getParentRoute: () => root, path }),
  );
  const router = createRouter({
    routeTree: root.addChildren(routes),
    history: createMemoryHistory({ initialEntries: ["/"] }),
    parseSearch: parseAttributionSearch,
    stringifySearch: stringifyAttributionSearch,
  });
  await router.load();
  for (const to of ["/quiz", "/parabens", "/loja", "/checkout", "/rastreamento"] as const) {
    expect(new URLSearchParams(router.buildLocation({ to }).searchStr).get("utm_content")).toBe(
      "criativo1",
    );
    await router.navigate({ to });
    expect(new URLSearchParams(router.state.location.searchStr).get("fbclid")).toBe("CLICK");
  }
});

it("logs the original entry and stored parameters per step without logging unrelated URL fields", () => {
  entry("/?utm_campaign=teste&utm_content=criativo1");
  captureTracking();
  entry("/quiz?email=private");
  new Function(trackingBootstrap)();
  const log = vi.spyOn(console, "log").mockImplementation(() => {});
  debugTracking("/quiz");
  expect(log).toHaveBeenCalledExactlyOnceWith("[Corre Rosa tracking]", {
    stage: "/quiz",
    received: {},
    saved: { utm_campaign: "teste", utm_content: "criativo1" },
  });
});

it("preserves attribution on the home link even if SSR fails before the normal funnel shell loads", () => {
  entry("/quiz?utm_campaign=teste&utm_content=criativo1&email=private");
  const page = document.createElement("div");
  page.innerHTML = renderErrorPage();
  document.body.appendChild(page);
  try {
    new Function(page.querySelector("script")!.textContent!)();
    const link = page.querySelector<HTMLAnchorElement>("#tracking-home")!;
    expect(new URL(link.href).pathname).toBe("/");
    expect(new URL(link.href).search).toBe("?utm_campaign=teste&utm_content=criativo1");
  } finally {
    page.remove();
  }
});
