import { act, cleanup, render, screen } from "@testing-library/react";
import { beforeEach, afterEach, expect, it, vi } from "vitest";
import { CampaignCountdown } from "@/components/campaign-countdown";
import { countdownStorageKey } from "@/lib/campaign-countdown";

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-10-04T02:00:00Z"));
  sessionStorage.clear();
});
afterEach(() => {
  cleanup();
  vi.clearAllTimers();
  vi.useRealTimers();
});

it("continues the same ten-minute timer across page mounts and restarts after expiry", () => {
  const page = render(<CampaignCountdown />);
  expect(screen.getByRole("timer")).toHaveTextContent("10:00");
  const deadline = sessionStorage.getItem(countdownStorageKey);
  act(() => vi.advanceTimersByTime(17000));
  expect(screen.getByRole("timer")).toHaveTextContent("09:43");
  page.unmount();
  render(<CampaignCountdown />);
  expect(screen.getByRole("timer")).toHaveTextContent("09:43");
  expect(sessionStorage.getItem(countdownStorageKey)).toBe(deadline);
  act(() => vi.advanceTimersByTime(583000));
  expect(screen.getByRole("timer")).toHaveTextContent("10:00");
  expect(screen.queryByText("TEMPO ENCERRADO")).not.toBeInTheDocument();
  expect(sessionStorage.getItem(countdownStorageKey)).not.toBe(deadline);
  cleanup();
  render(<CampaignCountdown />);
  expect(screen.getByRole("timer")).toHaveTextContent("10:00");
});

it("recovers from an invalid saved deadline", () => {
  sessionStorage.setItem(countdownStorageKey, "invalid");
  render(<CampaignCountdown />);
  expect(screen.getByRole("timer")).toHaveTextContent("10:00");
  act(() => vi.advanceTimersByTime(1000));
  expect(screen.getByRole("timer")).toHaveTextContent("09:59");
});
