import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { buildUtmifyOrder, checkoutTracking } from "../lib/utmify-order";

const { memory } = vi.hoisted(() => ({ memory: new Map<string, string>() }));
vi.mock("@netlify/blobs", () => ({
  getStore: () => ({
    get: async (key: string) => memory.get(key) ?? null,
    set: async (key: string, value: string) => {
      memory.set(key, value);
    },
    delete: async (key: string) => {
      memory.delete(key);
    },
  }),
}));
import { decryptOrder, encryptOrder, processOrder } from "../../netlify/lib/utmify-store";
import handler from "../../netlify/functions/utmify-order";
import { createHmac } from "node:crypto";

const makeOrder = () =>
  buildUtmifyOrder({
    id: "transaction-123",
    amount: 11780,
    customer: {
      name: "Cliente Teste",
      email: "test@example.com",
      phone: "11999999999",
      document: "00000000000",
      country: "BR",
    },
    offers: { socks: "34 a 38" },
    tracking: checkoutTracking(
      "?utm_source=FB&utm_campaign=Campanha%7C123456789012345678&utm_content=Anuncio%7C001",
    ),
    created: new Date(),
  });
beforeEach(() => {
  memory.clear();
  vi.stubEnv("PINGUPAG_API_KEY", "test-key");
  vi.stubEnv("UTMIFY_API_TOKEN", "test-token");
  vi.stubEnv("UTMIFY_DIRECT_ENABLED", "true");
});
afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

it("preserves opaque campaign IDs and rejects duplicated/oversized UTMs", () => {
  const result = checkoutTracking(
    "?utm_campaign=Nome%7C123456789012345678&utm_content=001&utm_source=FB&utm_source=other&utm_term=" +
      "x".repeat(1001),
  );
  expect(result).toMatchObject({
    utm_campaign: "Nome|123456789012345678",
    utm_content: "001",
    utm_source: null,
    utm_term: null,
  });
  expect(makeOrder()).toMatchObject({
    status: "waiting_payment",
    approvedDate: null,
    commission: { totalPriceInCents: 11780 },
    products: [
      { id: "corre-rosa-kit", priceInCents: 9790 },
      { id: "socks", priceInCents: 1990 },
    ],
  });
});

it("rejects unsigned, tampered and expired queue registrations", async () => {
  const body = JSON.stringify({
    order: makeOrder(),
    timestamp: Date.now() - 600000,
  });
  const signature = createHmac("sha256", "corre-rosa:utmify-queue:v1:test-key")
    .update(body)
    .digest("hex");
  expect((await handler(new Request("https://example.com", { method: "POST", body }))).status).toBe(
    401,
  );
  expect(
    (
      await handler(
        new Request("https://example.com", {
          method: "POST",
          headers: { "X-Order-Signature": signature },
          body,
        }),
      )
    ).status,
  ).toBe(400);
  expect(memory.size).toBe(0);
});

it("queues authenticated orders encrypted and updates the same order after gateway approval", async () => {
  const order = makeOrder();
  const body = JSON.stringify({ order, timestamp: Date.now() });
  const signature = createHmac("sha256", "corre-rosa:utmify-queue:v1:test-key")
    .update(body)
    .digest("hex");
  expect(
    (
      await handler(
        new Request("https://example.com", {
          method: "POST",
          headers: { "X-Order-Signature": signature },
          body,
        }),
      )
    ).status,
  ).toBe(202);
  const key = "orders/transaction-123";
  expect(memory.get(key)).not.toContain(order.customer.email);
  expect(decryptOrder(memory.get(key)!).order).toEqual(order);
  const fetchMock = vi
    .fn()
    .mockResolvedValueOnce(Response.json({ status: "pending" }))
    .mockResolvedValueOnce(Response.json({ ok: true }))
    .mockResolvedValueOnce(Response.json({ status: "pending" }))
    .mockResolvedValueOnce(Response.json({ status: "approved" }))
    .mockResolvedValueOnce(Response.json({ ok: true }));
  vi.stubGlobal("fetch", fetchMock);
  await processOrder(key);
  const waiting = JSON.parse(fetchMock.mock.calls[1]![1].body);
  expect(waiting.status).toBe("waiting_payment");
  await processOrder(key);
  expect(fetchMock).toHaveBeenCalledTimes(3);
  await processOrder(key);
  const paid = JSON.parse(fetchMock.mock.calls[4]![1].body);
  expect(paid).toMatchObject({
    orderId: waiting.orderId,
    createdAt: waiting.createdAt,
    status: "paid",
    trackingParameters: waiting.trackingParameters,
  });
  expect(paid.approvedDate).toBeTruthy();
  expect(memory.has(key)).toBe(false);
});

it("retains failed deliveries and approval timestamps for retries", async () => {
  const key = "orders/transaction-123";
  memory.set(key, encryptOrder({ order: makeOrder(), waitingSent: true, approvedDate: null }));
  const fetchMock = vi
    .fn()
    .mockResolvedValueOnce(Response.json({ status: "approved" }))
    .mockResolvedValueOnce(new Response(null, { status: 500 }))
    .mockResolvedValueOnce(Response.json({ status: "approved" }))
    .mockResolvedValueOnce(Response.json({ ok: true }));
  vi.stubGlobal("fetch", fetchMock);
  await expect(processOrder(key)).rejects.toThrow("UTMify delivery failed");
  const approved = decryptOrder(memory.get(key)!).approvedDate;
  await processOrder(key);
  expect(JSON.parse(fetchMock.mock.calls[3]![1].body).approvedDate).toBe(approved);
  expect(memory.has(key)).toBe(false);
});
