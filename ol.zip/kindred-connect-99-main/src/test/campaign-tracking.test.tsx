import { cleanup, render } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { CampaignTracking } from "@/components/campaign-tracking";
import { buildUrlWithTracking, captureTracking } from "@/lib/tracking";

const router = vi.hoisted(() => ({
  state: { location: { pathname: "/checkout", href: "/checkout" } },
  navigate: vi.fn().mockResolvedValue(undefined),
}));
vi.mock("@tanstack/react-router", () => ({
  useRouter: () => router,
  useRouterState: ({ select }: { select: (state: unknown) => unknown }) =>
    select({ location: router.state.location }),
}));

beforeEach(() => {
  router.navigate.mockReset().mockResolvedValue(undefined);
  router.state.location = { pathname: "/checkout", href: "/checkout" };
  localStorage.clear();
  window.history.replaceState(null, "", "/?utm_source=facebook&utm_campaign=teste");
  captureTracking();
  vi.stubGlobal("fbq", vi.fn());
});
afterEach(() => {
  cleanup(); vi.unstubAllGlobals(); localStorage.clear();
  window.history.replaceState(null, "", "/");
});

it("restores saved UTMs without firing duplicate checkout events from the global observer", () => {
  const view = render(<CampaignTracking />);
  expect(router.navigate).toHaveBeenCalledExactlyOnceWith({
    href: expect.stringContaining("utm_campaign=teste"), replace: true,
  });
  const href = router.navigate.mock.calls[0]?.[0].href as string;
  expect(new URL(href, window.location.href).searchParams.get("utm_source")).toBe("facebook");
  expect(window.fbq).not.toHaveBeenCalled();
  view.rerender(<CampaignTracking />);
  expect(window.fbq).not.toHaveBeenCalled();
});

it("sends a SPA PageView and ViewContent once per entry while keeping the query intact", () => {
  router.state.location.href = buildUrlWithTracking("/quiz");
  router.state.location.pathname = "/quiz";
  const view = render(<CampaignTracking />);
  expect(window.fbq).not.toHaveBeenCalled();
  router.state.location = { pathname: "/loja", href: buildUrlWithTracking("/loja") };
  view.rerender(<CampaignTracking />);
  expect(window.fbq).toHaveBeenCalledWith("trackSingle", "1418898839713148", "PageView", expect.any(Object));
  expect(window.fbq).toHaveBeenCalledWith("trackSingle", "1418898839713148", "ViewContent", expect.any(Object));
  expect(window.fbq).toHaveBeenCalledTimes(2);
  view.rerender(<CampaignTracking />);
  expect(window.fbq).toHaveBeenCalledTimes(2);
});

it("does not redirect when the current URL already contains restored attribution", () => {
  router.state.location.href = buildUrlWithTracking("/quiz");
  router.state.location.pathname = "/quiz";
  render(<CampaignTracking />);
  expect(router.navigate).not.toHaveBeenCalled();
});
