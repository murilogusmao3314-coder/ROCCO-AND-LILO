import { act, cleanup, render, screen } from "@testing-library/react";
import { beforeEach, afterEach, expect, it, vi } from "vitest";
import { Route } from "@/routes/parabens";
const { navigate, router } = vi.hoisted(() => ({
  navigate: vi.fn(),
  router: { preloadRoute: vi.fn().mockResolvedValue(undefined) },
}));
vi.mock("@tanstack/react-router", () => ({
  createFileRoute: () => (options: { component: React.ComponentType }) => ({ options }),
  useNavigate: () => navigate,
  useRouter: () => router,
}));
const animatedElements: Element[] = [];
const cancellations: ReturnType<typeof vi.fn>[] = [];
const originalAnimate = Object.getOwnPropertyDescriptor(Element.prototype, "animate");
const animate = vi.fn(function (this: Element) {
  animatedElements.push(this);
  const cancel = vi.fn();
  cancellations.push(cancel);
  return { cancel } as unknown as Animation;
});
beforeEach(() => {
  vi.useFakeTimers();
  navigate.mockClear();
  animate.mockClear();
  animatedElements.length = 0;
  cancellations.length = 0;
  Object.defineProperty(Element.prototype, "animate", { configurable: true, value: animate });
});
afterEach(() => {
  cleanup();
  if (originalAnimate) Object.defineProperty(Element.prototype, "animate", originalAnimate);
  else Reflect.deleteProperty(Element.prototype, "animate");
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.clearAllTimers();
  vi.useRealTimers();
});
it("shows congratulations and finishes the bar before redirecting to the store", () => {
  const Component = Route.options.component as React.ComponentType;
  render(<Component />);
  expect(screen.getByRole("heading", { name: "Parabéns!" })).toBeInTheDocument();
  expect(screen.getByRole("progressbar")).toHaveAttribute("aria-valuenow", "0");
  expect(screen.getByText(/REDIRECIONANDO PARA A LOJA/)).toBeInTheDocument();
  const fill = screen.getByRole("progressbar").firstElementChild as HTMLElement;
  act(() => vi.advanceTimersByTime(2500));
  expect(Number(fill.style.transform.match(/scaleX\((.+)\)/)?.[1])).toBeCloseTo(0.5, 2);
  expect(navigate).not.toHaveBeenCalled();
  expect(screen.getByText("3s")).toBeInTheDocument();
  act(() => vi.advanceTimersByTime(2510));
  expect(screen.getByRole("progressbar")).toHaveAttribute("aria-valuenow", "5");
  expect(screen.getByText("0s")).toBeInTheDocument();
  expect(fill.style.transform).toBe("scaleX(1)");
  expect(navigate).not.toHaveBeenCalled();
  act(() => vi.advanceTimersByTime(180));
  expect(navigate).toHaveBeenCalledExactlyOnceWith({
    to: "/loja",
    search: expect.any(Function),
    replace: true,
  });
});
it.each([
  ["desktop", 900],
  ["mobile", 740],
])("starts falling confetti and the entrance shake after mounting on %s", (_, height) => {
  vi.stubGlobal("innerHeight", height);
  const Component = Route.options.component as React.ComponentType;
  render(<Component />);
  expect(
    animatedElements.filter((element) => element.matches(".campaign-confetti i")),
  ).toHaveLength(48);
  expect(
    animatedElements.filter((element) => element.matches(".campaign-celebration")),
  ).toHaveLength(1);
  const entrance = animate.mock.calls[0] as unknown as [Keyframe[], KeyframeAnimationOptions];
  expect(entrance[0]).toEqual(
    expect.arrayContaining([
      expect.objectContaining({ transform: "translateX(-6px) rotate(-0.4deg)" }),
    ]),
  );
  const fall = animate.mock.calls[1] as unknown as [Keyframe[], KeyframeAnimationOptions];
  expect(fall[0][2]?.["transform"]).toContain(`, ${height + 40}px, 0)`);
  expect(fall[1]).toEqual(expect.objectContaining({ duration: 2900, fill: "both" }));
});
it("automatically celebrates with gentler motion when the PC requests reduced motion", () => {
  vi.spyOn(window, "matchMedia").mockReturnValue({ matches: true } as MediaQueryList);
  const Component = Route.options.component as React.ComponentType;
  const page = render(<Component />);
  expect(animate).toHaveBeenCalledTimes(49);
  expect(screen.queryByRole("button", { name: /animações|confetes/i })).not.toBeInTheDocument();
  const entrance = animate.mock.calls[0] as unknown as [Keyframe[], KeyframeAnimationOptions];
  expect(entrance[0]).toEqual(
    expect.arrayContaining([
      expect.objectContaining({ transform: "translateX(-1px) rotate(0deg)" }),
    ]),
  );
  const fall = animate.mock.calls[1] as unknown as [Keyframe[], KeyframeAnimationOptions];
  expect(fall[0][2]?.["transform"]).toContain("rotate(90deg)");
  expect(page.container.querySelector(".campaign-confetti")).toBeInTheDocument();
  act(() => vi.advanceTimersByTime(2500));
  const fill = screen.getByRole("progressbar").firstElementChild as HTMLElement;
  expect(Number(fill.style.transform.match(/scaleX\((.+)\)/)?.[1])).toBeCloseTo(0.5, 2);
  act(() => vi.advanceTimersByTime(2510));
  expect(fill.style.transform).toBe("scaleX(1)");
  act(() => vi.advanceTimersByTime(180));
  expect(navigate).toHaveBeenCalledExactlyOnceWith({
    to: "/loja",
    search: expect.any(Function),
    replace: true,
  });
});
it("cleans up the redirect when leaving the page", () => {
  const Component = Route.options.component as React.ComponentType;
  const page = render(<Component />);
  page.unmount();
  expect(cancellations).toHaveLength(49);
  expect(cancellations.every((cancel) => cancel.mock.calls.length === 1)).toBe(true);
  act(() => vi.advanceTimersByTime(6000));
  expect(navigate).not.toHaveBeenCalled();
});
it("cancels navigation when leaving while the completed bar is visible", () => {
  const Component = Route.options.component as React.ComponentType;
  const page = render(<Component />);
  act(() => vi.advanceTimersByTime(5010));
  expect(screen.getByText("0s")).toBeInTheDocument();
  page.unmount();
  act(() => vi.advanceTimersByTime(1000));
  expect(navigate).not.toHaveBeenCalled();
});
