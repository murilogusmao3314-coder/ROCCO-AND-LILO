import {
  createMemoryHistory,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import { trackingStorageKey } from "@/lib/tracking";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import {
  attributionSessionBootstrap,
  attributionSessionKey,
  parseAttributionSearch,
  retainAttributionSearch,
  stringifyAttributionSearch,
  validateAttributionSearch,
} from "@/lib/campaign-attribution";

function funnelRouter(entry: string) {
  const root = createRootRoute({
    validateSearch: validateAttributionSearch,
    search: { middlewares: [retainAttributionSearch] },
  });
  const routes = ["/", "/quiz", "/parabens", "/loja", "/checkout", "/rastreamento"].map((path) =>
    createRoute({ getParentRoute: () => root, path }),
  );
  return createRouter({
    routeTree: root.addChildren(routes),
    history: createMemoryHistory({ initialEntries: [entry] }),
    parseSearch: parseAttributionSearch,
    stringifySearch: stringifyAttributionSearch,
  });
}

it("preserves standard and custom UTMs through the entire funnel without forwarding personal fields", async () => {
  const expected = {
    utm_source: "FB",
    utm_medium: "paid social",
    utm_campaign: "19000000000000000001",
    utm_content: '"variante A"',
    utm_term: "false",
    utm_id: "000123",
    utm_custom: "kit rosa|ação + oferta & 10%",
    utm_payload: '["A","B"]',
    utm_campgain: "kkkk",
    fbclid: "TEST",
    sck: "null",
    src: "ads",
  };
  const query = new URLSearchParams({ ...expected, email: "private", token: "private" });
  const router = funnelRouter(`/?${query}`);
  await router.load();
  for (const to of ["/quiz", "/parabens", "/loja", "/checkout", "/rastreamento"] as const) {
    await router.navigate({ to });
    const query = new URLSearchParams(router.state.location.searchStr);
    for (const [key, value] of Object.entries(expected)) expect(query.get(key)).toBe(value);
    expect(query.has("email")).toBe(false);
    expect(query.has("token")).toBe(false);
  }
});

it("retains the user's direct store example in links, checkout reloads and the return to the store", async () => {
  const router = funnelRouter("/loja?utm_campgain=kkkk&utm_campaign=123&fbclid=CLICK");
  await router.load();
  const link = router.buildLocation({ to: "/checkout" });
  expect(new URLSearchParams(link.searchStr).get("utm_campgain")).toBe("kkkk");
  await router.navigate({ to: "/checkout" });
  const reloaded = funnelRouter(router.state.location.href);
  await reloaded.load();
  await reloaded.navigate({ to: "/loja" });
  expect(Object.fromEntries(new URLSearchParams(reloaded.state.location.searchStr))).toEqual({
    utm_campgain: "kkkk",
    utm_campaign: "123",
    fbclid: "CLICK",
  });
});

it("allows explicit attribution updates and removal without losing the remaining campaign", async () => {
  const router = funnelRouter("/loja?utm_campaign=old&utm_custom=keep&fbclid=CLICK");
  await router.load();
  await router.navigate({ to: "/checkout", search: { utm_campaign: "new", fbclid: undefined } });
  const query = new URLSearchParams(router.state.location.searchStr);
  expect(query.get("utm_campaign")).toBe("new");
  expect(query.get("utm_custom")).toBe("keep");
  expect(query.has("fbclid")).toBe(false);
});

it("keeps the router's normal parsing for other fields and rejects ambiguous repeated UTMs", () => {
  const parsed = parseAttributionSearch(
    "?utm_campaign=123&utm_custom=a&utm_custom=b&page=2&filter=%7B%22active%22%3Atrue%7D",
  );
  expect(parsed["utm_campaign"]).toBe("123");
  expect(parsed["page"]).toBe(2);
  expect(parsed["filter"]).toEqual({ active: true });
  expect(validateAttributionSearch(parsed)).toEqual({ utm_campaign: "123" });
  expect(
    parseAttributionSearch(
      stringifyAttributionSearch({ page: 2, filter: { active: true }, utm_campaign: "123" }),
    ),
  ).toEqual({ page: 2, filter: { active: true }, utm_campaign: "123" });
});

it("ignores malformed attribution values without throwing", () => {
  expect(
    validateAttributionSearch({
      utm_source: "FB",
      utm_campaign: { name: "bad" },
      utm_term: "x".repeat(1001),
      email: "private",
      fbclid: "",
    }),
  ).toEqual({ utm_source: "FB" });
});

const bootstrap = () => new Function(attributionSessionBootstrap)();
const entry = (path: string) => window.history.replaceState({ keep: true }, "", path);

beforeEach(() => {
  sessionStorage.clear();
  localStorage.clear();
  for (const cookie of document.cookie.split(";"))
    document.cookie = cookie.split("=")[0] + "=; Path=/; Max-Age=0";
  entry("/");
});
afterEach(() => {
  vi.restoreAllMocks();
  sessionStorage.clear();
  localStorage.clear();
  for (const cookie of document.cookie.split(";"))
    document.cookie = cookie.split("=")[0] + "=; Path=/; Max-Age=0";
  entry("/");
});

it("captures the ad persistently before SDK initialization and restores each direct funnel entry through Pix", async () => {
  const expected = {
    utm_source: "facebook",
    utm_campaign: "19000000000000000001",
    utm_content: "criativo A + ação & 10%",
    utm_term: "false",
    utm_id: "0000123",
    utm_custom: '["A","B"]',
    fbclid: "CLICK-A",
  };
  entry("/?" + new URLSearchParams({ ...expected, email: "private", token: "private" }));
  bootstrap();
  expect(JSON.parse(localStorage.getItem(trackingStorageKey)!).values).toEqual(expected);
  const historyLength = window.history.length;
  for (const path of ["/quiz", "/parabens", "/loja", "/checkout", "/rastreamento"]) {
    entry(path + "?preview=1#payment");
    bootstrap();
    expect(window.location.pathname).toBe(path);
    expect(window.location.hash).toBe("#payment");
    expect(window.history.state).toEqual({ keep: true });
    expect(window.history.length).toBe(historyLength);
    const query = new URLSearchParams(window.location.search);
    expect(query.get("preview")).toBe("1");
    for (const [key, value] of Object.entries(expected)) expect(query.get(key)).toBe(value);
    expect(query.has("email")).toBe(false);
    expect(query.has("token")).toBe(false);
    // The real router parsing/middleware receives the restored URL after a full reload.
    const router = funnelRouter(window.location.pathname + window.location.search);
    await router.load();
    const next = router.buildLocation({ to: "/checkout" });
    expect(validateAttributionSearch(parseAttributionSearch(next.searchStr))).toEqual(expected);
  }
});

it("replaces the previous ad without carrying over its creative or click ID", () => {
  entry("/?utm_source=facebook&utm_campaign=A&utm_content=creative-A&fbclid=CLICK-A");
  bootstrap();
  entry("/loja?utm_source=instagram&utm_campaign=B");
  bootstrap();
  expect(JSON.parse(localStorage.getItem(trackingStorageKey)!).values).toEqual({
    utm_source: "instagram",
    utm_campaign: "B",
  });
  entry("/checkout");
  bootstrap();
  expect(Object.fromEntries(new URLSearchParams(window.location.search))).toEqual({
    utm_source: "instagram",
    utm_campaign: "B",
  });
});

it("recovers missing fields of the same campaign and is idempotent", () => {
  entry("/quiz?utm_campaign=A&utm_content=creative-A&fbclid=CLICK-A");
  bootstrap();
  entry("/loja?utm_campaign=A");
  bootstrap();
  expect(new URLSearchParams(window.location.search).get("utm_content")).toBe("creative-A");
  const replace = vi.spyOn(window.history, "replaceState");
  bootstrap();
  expect(replace).not.toHaveBeenCalled();
});

it("does not overwrite explicit empty or ambiguous repeated query fields with saved values", () => {
  entry("/?utm_source=facebook&utm_content=A");
  bootstrap();
  entry("/checkout?utm_source=&utm_content=B&utm_content=C");
  bootstrap();
  expect(window.location.search).toBe("?utm_source=&utm_content=B&utm_content=C");
  expect(validateAttributionSearch(parseAttributionSearch(window.location.search))).toEqual({});
});

it("validates stored attribution and never restores personal or malformed values", () => {
  sessionStorage.setItem(
    attributionSessionKey,
    JSON.stringify({
      utm_source: "facebook",
      utm_campaign: 123,
      utm_content: "x".repeat(1001),
      email: "private",
    }),
  );
  entry("/checkout");
  bootstrap();
  expect(window.location.search).toBe("?utm_source=facebook");
  expect(JSON.parse(localStorage.getItem(trackingStorageKey)!).values).toEqual({
    utm_source: "facebook",
  });
});

it("does not invent attribution for organic visitors or corrupted storage", () => {
  bootstrap();
  expect(window.location.search).toBe("");
  expect(sessionStorage.getItem(attributionSessionKey)).toBeNull();
  for (const invalid of ["{bad", "null", '["facebook"]', '"facebook"']) {
    sessionStorage.setItem(attributionSessionKey, invalid);
    expect(bootstrap).not.toThrow();
    expect(window.location.search).toBe("");
  }
});

it("preserves the original URL and funnel navigation when session storage is blocked", async () => {
  for (const method of ["getItem", "setItem"] as const) {
    vi.spyOn(Storage.prototype, method).mockImplementation(() => {
      throw new Error("blocked");
    });
  }
  entry("/?utm_campaign=A&utm_content=creative-A");
  expect(bootstrap).not.toThrow();
  const router = funnelRouter(window.location.pathname + window.location.search);
  await router.load();
  await router.navigate({ to: "/checkout" });
  expect(new URLSearchParams(router.state.location.searchStr).get("utm_content")).toBe(
    "creative-A",
  );
});
