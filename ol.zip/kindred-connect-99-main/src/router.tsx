import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";
import { parseAttributionSearch, stringifyAttributionSearch } from "@/lib/campaign-attribution";

export const getRouter = () => {
  const queryClient = new QueryClient();

  const router = createRouter({
    routeTree,
    context: { queryClient },
    parseSearch: parseAttributionSearch,
    stringifySearch: stringifyAttributionSearch,
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
  });

  return router;
};
