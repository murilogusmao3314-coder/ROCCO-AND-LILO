export const officialCampaignUrl = "https://www.olympikus.com.br/edicao-especial-outubro-rosa";
export const preventionUrl =
  "https://www.gov.br/inca/pt-br/assuntos/gestor-e-profissional-de-saude/controle-do-cancer-de-mama/acoes/prevencao";
export const campaignImages = {
  logo: "/campaign/campinos-logo.webp",
  challenge: "/campaign/desafio-outubro-rosa.webp",
  headline: "/campaign/um-corre-por-todas.webp",
  ribbon: "/campaign/laco-outubro-rosa.webp",
};
export const productImages = [
  { src: "/campaign/loja-produto-v2.webp", alt: "Kit Corre Rosa completo: tênis, regata e shorts" },
  { src: "/campaign/tenis-galeria-v2.webp", alt: "Corre Max 2 Outubro Rosa, vista lateral" },
  { src: "/campaign/tenis-galeriaA-v2.webp", alt: "Detalhes do tênis rosa" },
  { src: "/campaign/tenis-galeriaB-v2.webp", alt: "Corre Max 2 Outubro Rosa, outra perspectiva" },
  { src: "/campaign/tenis-galeriaC-v2.webp", alt: "Acabamento da edição Outubro Rosa" },
  { src: "/campaign/tenis-galeriaD-v2.webp", alt: "Detalhes da edição rosa" },
  { src: "/campaign/tenis-galeriaE-v2.webp", alt: "Tênis rosa, vista adicional" },
  { src: "/campaign/regata-frente.webp", alt: "Regata rosa, frente" },
  { src: "/campaign/regata-lateral.webp", alt: "Regata rosa, lateral" },
  { src: "/campaign/regata-costas.webp", alt: "Regata rosa, costas" },
  { src: "/campaign/shorts-frente.webp", alt: "Shorts rosa, frente" },
  { src: "/campaign/shorts-lateral.webp", alt: "Shorts rosa, lateral" },
  { src: "/campaign/shorts-costas.webp", alt: "Shorts rosa, costas" },
];
export const kit = {
  title: "Tênis Olympikus Corre Max 2 CB Outubro Rosa + Kit Corre Rosa",
  price: 97.9,
  originalPrice: 549.9,
};
export const shoeSizes = Array.from({ length: 12 }, (_, index) => String(34 + index));
export const clothingSizes = ["P", "M", "G"] as const;
export const offers = [
  {
    id: "socks",
    title: "Kit com 6 Meias Unissex",
    image: "/campaign/meias-kit.webp",
    price: 19.9,
    originalPrice: 89.9,
    needsSize: true,
  },
  {
    id: "visor",
    title: "Viseira Olympikus Run",
    image: "/campaign/viseira-run.webp",
    price: 29.9,
    originalPrice: 59.9,
    needsSize: false,
  },
  {
    id: "colored-socks",
    title: "Kit com 6 Meias Coloridas",
    image: "/campaign/meias-coloridas.webp",
    price: 19.9,
    originalPrice: 89.9,
    needsSize: true,
  },
] as const;
export const shippingOptions = [
  { id: "free", title: "Frete Grátis", description: "Entrega de 7 a 10 dias", price: 0 },
  { id: "express", title: "Correios", description: "2 a 4 dias úteis", price: 8.45 },
] as const;
export const currency = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const questions = [
  {
    title: "O que o Outubro Rosa quer colocar em movimento?",
    image: "/campaign/pergunta1-outubro-rosa.webp",
    alt: "Laço rosa, símbolo de conscientização sobre o câncer de mama",
    options: [
      "A competição entre atletas",
      "A conscientização e o diagnóstico precoce do câncer de mama",
      "As tendências de moda",
      "Somente as corridas de rua",
    ],
    correct: 1,
    explanation:
      "A campanha chama atenção para o cuidado, a prevenção e a identificação precoce do câncer de mama.",
    source: preventionUrl,
  },
  {
    title: "Qual modelo recebe a edição Outubro Rosa de 2026?",
    image: "/campaign/tenis-rosa-fitinha.webp",
    alt: "Tênis Olympikus da edição Outubro Rosa",
    options: ["Corre Max 2", "Dynamic", "Challenger", "Veloz"],
    correct: 0,
    explanation: "O Corre Max 2 é o modelo apresentado na campanha oficial deste ano.",
    source: officialCampaignUrl,
  },
  {
    title: "Qual instituição é apoiada pelo lucro dessa edição?",
    image: "/campaign/pergunta3-profissional-rosa.webp",
    alt: "Profissional de saúde usando o laço rosa",
    options: [
      "Hospital Albert Einstein",
      "Hospital Sírio-Libanês",
      "Santa Casa de Porto Alegre",
      "Hospital das Clínicas de São Paulo",
    ],
    correct: 2,
    explanation:
      "Segundo a Olympikus, o lucro do Corre Max 2 Outubro Rosa é destinado à Santa Casa de Porto Alegre.",
    source: officialCampaignUrl,
  },
  {
    title: "Qual hábito ajuda a diminuir o risco de câncer de mama?",
    image: "/campaign/pergunta4-mulher-correndo.webp",
    alt: "Mulher praticando corrida em um parque",
    options: [
      "Manter uma rotina de atividade física",
      "Reduzir o tempo de sono",
      "Deixar de se movimentar",
      "Consumir mais bebidas alcoólicas",
    ],
    correct: 0,
    explanation:
      "O INCA orienta praticar atividade física, manter um peso saudável e evitar bebidas alcoólicas para ajudar a reduzir o risco.",
    source: preventionUrl,
  },
  {
    title: "Qual mensagem traduz esse movimento coletivo?",
    image: "/campaign/pergunta5-corrida-outubro-rosa.webp",
    alt: "Mulheres correndo juntas pelo Outubro Rosa",
    options: [
      "Correr para competir",
      "Um corre por todas",
      "Cada uma por si",
      "Só a velocidade importa",
    ],
    correct: 1,
    explanation:
      "Um corre por todas: cada passo também pode apoiar uma causa e ampliar uma mensagem de cuidado.",
    source: officialCampaignUrl,
  },
] as const;
