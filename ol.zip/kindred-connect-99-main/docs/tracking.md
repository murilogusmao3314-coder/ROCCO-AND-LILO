# Meta Pixel e atribuição do Corre Rosa

**Meta Pixel:** `1418898839713148`; carregado uma vez no head (`fbevents.js`). O bootstrap emite a primeira `PageView`; o React emite as seguintes apenas em mudanças de rota SPA. Há fallback `noscript` para `PageView`.

**Eventos:** `ViewContent` quando entra na loja; `InitiateCheckout` quando o componente de checkout monta, inclusive por link direto, com até 10 novas tentativas a cada 500 ms se o bootstrap Meta ainda não estiver pronto; `AddToWishlist` ao favoritar; `AddToCart` após confirmar os tamanhos; `AddPaymentInfo` somente após gerar um Pix válido; `Purchase` apenas quando o status da cobrança na Pingu é `approved`, inclusive na consulta de retorno e no serviço opcional de rastreamento. Preview e status pendente/recusado não geram Purchase.

Os eventos usam `trackSingle` direcionado ao ID novo, `BRL`, valores reais e itens selecionados. Para transações, `eventID=corre-rosa:<evento>:<id-da-transação>` e deduplicação em `localStorage` evitam repetição ao recarregar ou retornar. O site não envia dados do pagador nem o código Pix ao Meta.

**UTMify:** o código enviado pelo usuário foi decodificado e sua configuração `window.pixelId = "6ace976f8708e36bd87c56a5"` é carregada no `<head>` antes do SDK `https://cdn.utmify.com.br/scripts/pixel/pixel.js` (com `defer` para preservar a ordem). O script separado de UTMs `https://cdn.utmify.com.br/scripts/utms/latest.js` foi mantido. O ID da UTMify **não substitui** o Meta Pixel `1418898839713148`. O recebimento de pedidos na UTMify depende da integração servidor → API, das Functions na Netlify e do token da conta correto.

Os parâmetros `utm_*`, `fbclid`, `src`, `sck`, `xcod` e outros campos suportados continuam persistidos por até 30 dias, restaurados na URL e repassados do Quiz ao Checkout e ao Rastreamento, sem modificar o gateway da Pingu. A integração de vendas da UTMify é separada de Meta CAPI.

Após publicar, verificar Meta Pixel Helper/Network (apenas uma instalação), Testar Eventos (IC somente no checkout; Purchase apenas com Pix aprovado) e parâmetros UTM no link e em `data.tracking`. Conferir scripts adicionados externamente no Netlify/UTMify para não duplicar pixels.

**Limites:** Uma chamada `fbq` na aplicação não é confirmação de que a Meta recebeu o evento. Em produção, verificar `Testar eventos` no conjunto de dados da BM atual, carregamento real de `fbevents.js`, `pixel.js` e `utms/latest.js`, e integração do webhook/servidor para aprovações que ocorram com o navegador fechado. O `Purchase` existente depende da consulta do pagamento aprovado no navegador ou no retorno, não substitui a Meta Conversions API. Não assumir que vendas históricas serão importadas automaticamente.
