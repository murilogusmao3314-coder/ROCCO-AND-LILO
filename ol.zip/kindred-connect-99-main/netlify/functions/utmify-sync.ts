import { orderStore, processOrder } from "../lib/utmify-store";

export default async function handler(): Promise<void> {
  if (process.env["UTMIFY_DIRECT_ENABLED"] !== "true") return;
  const { blobs } = await orderStore().list({ prefix: "orders/" });
  // Bound concurrency; pending orders are queried independently of the browser.
  for (let index = 0; index < blobs.length; index += 5) {
    await Promise.all(
      blobs.slice(index, index + 5).map(async ({ key }) => {
        try {
          await processOrder(key);
        } catch {
          console.error("UTMify order retry pending", { key });
        }
      }),
    );
  }
}
export const config = { schedule: "*/2 * * * *" };
