import { createHmac, timingSafeEqual } from "node:crypto";
import { z } from "zod";
import { orderSchema } from "../../src/lib/utmify-order";
import { encryptOrder, orderStore } from "../lib/utmify-store";

export default async function handler(request: Request): Promise<Response> {
  if (request.method !== "POST") return new Response(null, { status: 405 });
  if (
    process.env["UTMIFY_DIRECT_ENABLED"] !== "true" ||
    !process.env["UTMIFY_API_TOKEN"] ||
    !process.env["PINGUPAG_API_KEY"]
  )
    return new Response(null, { status: 503 });
  const body = await request.text();
  if (body.length > 32000) return new Response(null, { status: 413 });
  const signature = request.headers.get("X-Order-Signature") ?? "";
  if (!/^[a-f0-9]{64}$/.test(signature)) return new Response(null, { status: 401 });
  const expected = createHmac(
    "sha256",
    "corre-rosa:utmify-queue:v1:" + process.env["PINGUPAG_API_KEY"],
  )
    .update(body)
    .digest();
  if (!timingSafeEqual(expected, Buffer.from(signature, "hex")))
    return new Response(null, { status: 401 });
  const input = z
    .object({ order: orderSchema, timestamp: z.number().int() })
    .safeParse(JSON.parse(body));
  if (
    !input.success ||
    Math.abs(Date.now() - input.data.timestamp) > 300000 ||
    input.data.order.status !== "waiting_payment"
  )
    return new Response(null, { status: 400 });
  const key = "orders/" + input.data.order.orderId;
  const store = orderStore();
  if (!(await store.get(key)))
    await store.set(
      key,
      encryptOrder({
        order: input.data.order,
        waitingSent: false,
        approvedDate: null,
      }),
    );
  return new Response(null, { status: 202 });
}
