import { getStore } from "@netlify/blobs";
import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import { orderSchema, utcDate, type UtmifyOrder } from "../../src/lib/utmify-order";

type QueuedOrder = {
  order: UtmifyOrder;
  waitingSent: boolean;
  approvedDate: string | null;
};
export const orderStore = () =>
  getStore({ name: "corre-rosa-utmify-orders", consistency: "strong" });
function encryptionKey() {
  const secret = process.env["PINGUPAG_API_KEY"];
  if (!secret) throw new Error("Missing gateway configuration");
  return createHash("sha256")
    .update("corre-rosa:utmify-storage:v1:" + secret)
    .digest();
}
export function encryptOrder(value: QueuedOrder): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(value), "utf8"), cipher.final()]);
  return [iv, cipher.getAuthTag(), encrypted]
    .map((buffer) => buffer.toString("base64url"))
    .join(".");
}
export function decryptOrder(value: string): QueuedOrder {
  const parts = value.split(".").map((part) => Buffer.from(part, "base64url"));
  if (parts.length !== 3) throw new Error("Invalid stored order");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), parts[0]!);
  decipher.setAuthTag(parts[1]!);
  const parsed = JSON.parse(
    Buffer.concat([decipher.update(parts[2]!), decipher.final()]).toString("utf8"),
  );
  return {
    order: orderSchema.parse(parsed.order),
    waitingSent: parsed.waitingSent === true,
    approvedDate: typeof parsed.approvedDate === "string" ? parsed.approvedDate : null,
  };
}

export async function processOrder(key: string): Promise<void> {
  const store = orderStore();
  const encrypted = await store.get(key, { type: "text" });
  if (!encrypted) return;
  const queued = decryptOrder(encrypted);
  const created = Date.parse(queued.order.createdAt.replace(" ", "T") + "Z");
  if (Date.now() - created > 6 * 24 * 60 * 60 * 1000) {
    console.error("UTMify order retention expired", {
      orderId: queued.order.orderId,
    });
    await store.delete(key);
    return;
  }
  const response = await fetch(
    "https://app.pingupag.com/gateway/v1/query?action=get_transaction&id=" +
      encodeURIComponent(queued.order.orderId),
    {
      headers: { "X-API-Key": process.env["PINGUPAG_API_KEY"]! },
      signal: AbortSignal.timeout(8000),
    },
  );
  if (!response.ok) throw new Error("Gateway query failed");
  const transaction: unknown = await response.json();
  const status =
    transaction && typeof transaction === "object" && "status" in transaction
      ? transaction.status
      : null;
  // Only gateway-confirmed approval can produce a paid order.
  if (status !== "approved" && status !== "pending" && status !== "failed")
    throw new Error("Unknown gateway status");
  if (status === "approved" && !queued.approvedDate) {
    queued.approvedDate = utcDate(new Date());
    // Persist before sending so retries retain identical timestamps.
    await store.set(key, encryptOrder(queued));
  }
  const paid = queued.approvedDate !== null;
  if (!paid && queued.waitingSent) {
    if (status === "failed") await store.delete(key);
    return;
  }
  const token = process.env["UTMIFY_API_TOKEN"];
  if (!token) throw new Error("Missing UTMify API token");
  const payload = {
    ...queued.order,
    status: paid ? "paid" : "waiting_payment",
    approvedDate: queued.approvedDate,
  };
  const result = await fetch("https://api.utmify.com.br/api-credentials/orders", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-api-token": token },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(8000),
  });
  if (!result.ok) {
    // Never log response bodies, customer details or API tokens.
    console.error("UTMify rejected order", {
      orderId: queued.order.orderId,
      status: result.status,
    });
    throw new Error("UTMify delivery failed");
  }
  if (paid || status === "failed") await store.delete(key);
  else await store.set(key, encryptOrder({ ...queued, waitingSent: true }));
}
